using Attachments.Core.Application;
using Microsoft.Extensions.Caching.Memory;

namespace Attachments.Api.Idempotency;

/// <summary>
/// IMemoryCache-backed implementation of the Core IIdempotencyCache used by AttachmentService
/// (X-Request-Id upload deduplication, 10-minute TTL set by the service).
/// Documented single-node limitation: in-process only — for multi-node deployments back this
/// abstraction with Redis/SQL instead of changing the Core contract.
/// </summary>
public sealed class MemoryCacheIdempotencyCache(IMemoryCache cache) : IIdempotencyCache
{
    public bool TryGet<TValue>(string key, out TValue? value)
    {
        if (cache.TryGetValue(key, out TValue? found))
        {
            value = found;
            return true;
        }

        value = default;
        return false;
    }

    public void Set<TValue>(string key, TValue value, TimeSpan ttl) =>
        cache.Set(key, value, ttl);
}
