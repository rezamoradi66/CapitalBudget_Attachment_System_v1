using System.Globalization;
using System.Security.Claims;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Api.Auth;

namespace Attachments.Api.Http;

/// <summary>Maps the authenticated principal (built by PrincipalFactory) to the Core UserContext.</summary>
public static class UserContextReader
{
    public static UserContext ToUserContext(this ClaimsPrincipal principal)
    {
        var id = int.TryParse(principal.FindFirstValue(ClaimTypes.NameIdentifier), out var parsedId)
            ? parsedId
            : 0;
        var username = principal.FindFirstValue(ClaimTypes.Name) ?? "";
        var unitId = TryGetNullableInt(principal, PrincipalFactory.ClaimUnitId);
        var managementId = TryGetNullableInt(principal, PrincipalFactory.ClaimManagementId);
        var roles = principal.FindAll(ClaimTypes.Role)
            .Select(claim => claim.Value)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        return new UserContext(id, username, unitId, managementId, roles);
    }

    public static ClientContext GetClientContext(this HttpContext httpContext) =>
        new(
            Ip: httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            UserAgent: httpContext.Request.Headers.UserAgent.ToString());

    private static int? TryGetNullableInt(ClaimsPrincipal principal, string claimType) =>
        int.TryParse(principal.FindFirstValue(claimType), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value)
            ? value
            : null;
}
