using System.Security.Claims;
using System.Text.Json;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Microsoft.AspNetCore.Http;

namespace Attachments.Api.Http;

/// <summary>
/// Writes RFC 7807 ProblemDetails bodies with the stable «errorCode» extension and Persian
/// professional title/detail. Used by the exception middleware, auth challenges and the
/// rate-limiter rejection path so every error has the same shape.
/// </summary>
public static class ProblemResults
{
    public const string ProblemContentType = "application/problem+json; charset=utf-8";

    public static async Task WriteAsync(
        HttpContext context, int statusCode, string errorCode, string? detail = null, string? title = null)
    {
        if (context.Response.HasStarted)
            return;

        context.Response.Clear();
        context.Response.StatusCode = statusCode;
        context.Response.ContentType = ProblemContentType;

        var payload = new Dictionary<string, object?>
        {
            ["type"] = $"https://cbm.capitalbudget/errors/{errorCode}",
            ["title"] = title ?? ErrorMessages.For(errorCode),
            ["status"] = statusCode,
            ["detail"] = detail ?? ErrorMessages.For(errorCode),
            ["errorCode"] = errorCode,
            ["instance"] = context.Request.Path.Value ?? "/"
        };

        await context.Response.WriteAsync(JsonSerializer.Serialize(payload, AttachmentsJson.Web));
    }
}
