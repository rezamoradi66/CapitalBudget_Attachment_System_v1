using Attachments.Api.Auth;
using Attachments.Api.Http;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Attachments.Api.Controllers;

/// <summary>
/// Attachment endpoints. Permission checks are delegated to Core.PermissionService via
/// AttachmentService (view → visible(owner), upload/delete → editable(owner)).
/// Every error is an RFC 7807 ProblemDetails with a stable errorCode + Persian title.
/// </summary>
[ApiController]
[Route("api/v1")]
public sealed class AttachmentsController(AttachmentService attachments) : ControllerBase
{
    // ---------------------------------------------------------------- by-code

    /// <summary>Resolves a request by its business Code (scoped to the caller); 404 when not visible.</summary>
    [HttpGet("requests/by-code/{code}")]
    [Authorize]
    public async Task<IActionResult> GetRequestByCode(string code, CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await attachments.GetRequestByCodeAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), code, cancellationToken)));

    // ---------------------------------------------------------------- request attachments

    [HttpGet("requests/{id:int}/attachments")]
    [Authorize]
    public async Task<IActionResult> ListRequestAttachments(int id, CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await attachments.ListAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), OwnerType.Request, id, cancellationToken)));

    [HttpPost("requests/{id:int}/attachments")]
    [Authorize]
    public async Task<IActionResult> UploadRequestAttachment(
        int id, IFormFile? file, [FromForm] string? displayName, CancellationToken cancellationToken) =>
        await UploadAsync(OwnerType.Request, id, file, displayName, cancellationToken);

    // ---------------------------------------------------------------- micro attachments

    [HttpGet("micros/{id:int}/attachments")]
    [Authorize]
    public async Task<IActionResult> ListMicroAttachments(int id, CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await attachments.ListAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), OwnerType.Micro, id, cancellationToken)));

    [HttpPost("micros/{id:int}/attachments")]
    [Authorize]
    public async Task<IActionResult> UploadMicroAttachment(
        int id, IFormFile? file, [FromForm] string? displayName, CancellationToken cancellationToken) =>
        await UploadAsync(OwnerType.Micro, id, file, displayName, cancellationToken);

    // ---------------------------------------------------------------- attachment item

    [HttpGet("attachments/{id:long}/info")]
    [Authorize]
    public async Task<IActionResult> GetAttachmentInfo(long id, CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await attachments.GetInfoAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), id, cancellationToken)));

    /// <summary>Streams the stored bytes (Content-Disposition: attachment, nosniff, no-store).</summary>
    [HttpGet("attachments/{id:long}")]
    [Authorize]
    public async Task<IActionResult> DownloadAttachment(long id, CancellationToken cancellationToken)
    {
        var download = await attachments.DownloadAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), id, cancellationToken);
        return File(download.Content, download.ContentType, download.DownloadName);
    }

    [HttpDelete("attachments/{id:long}")]
    [Authorize]
    public async Task<IActionResult> DeleteAttachment(long id, CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await attachments.DeleteAsync(
            HttpContext.GetClientContext(), HttpContext.User.ToUserContext(), id, cancellationToken)));

    // ---------------------------------------------------------------- helpers

    private async Task<IActionResult> UploadAsync(
        OwnerType ownerType, long ownerId, IFormFile? file, string? displayName, CancellationToken cancellationToken)
    {
        if (file is null)
            throw new ApiException(400, ErrorCodes.Validation, "فیلد «file» در درخواست الزامی است.");

        using var buffer = new MemoryStream();
        await file.CopyToAsync(buffer, cancellationToken);

        Request.Headers.TryGetValue("X-Request-Id", out var requestId);
        var idempotencyKey = requestId.Count > 0 ? requestId.ToString() : null;

        var meta = await attachments.UploadAsync(
            HttpContext.GetClientContext(),
            HttpContext.User.ToUserContext(),
            ownerType,
            ownerId,
            new UploadInput(file.FileName, displayName, buffer.ToArray(), idempotencyKey),
            cancellationToken);

        return CreatedAtAction(nameof(GetAttachmentInfo), new { id = meta.Id }, ApiEnvelope.Ok(meta));
    }
}
