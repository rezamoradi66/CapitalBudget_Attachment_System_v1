using System.Globalization;
using System.Security.Claims;
using Attachments.Core.Domain.Entities;

namespace Attachments.Api.Auth;

/// <summary>
/// Builds the ClaimsPrincipal stored in the CBM.Attach.Session cookie and rebuilt from the
/// database on every request by SessionPrincipalValidator (server-side session source of truth).
/// </summary>
public static class PrincipalFactory
{
    public const string ClaimSessionId = "cbm_session_id";
    public const string ClaimMustChangePassword = "cbm_must_change_password";
    public const string ClaimUnitId = "cbm_unit_id";
    public const string ClaimManagementId = "cbm_management_id";

    public static ClaimsPrincipal Build(User user, IReadOnlyCollection<string> roles, Guid sessionId)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString(CultureInfo.InvariantCulture)),
            new(ClaimTypes.Name, user.Username),
            new(ClaimSessionId, sessionId.ToString("D")),
            new(ClaimMustChangePassword, user.MustChangePassword ? "true" : "false")
        };

        if (user.UnitId is { } unitId)
            claims.Add(new Claim(ClaimUnitId, unitId.ToString(CultureInfo.InvariantCulture)));

        if (user.ManagementId is { } managementId)
            claims.Add(new Claim(ClaimManagementId, managementId.ToString(CultureInfo.InvariantCulture)));

        claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

        var identity = new ClaimsIdentity(claims, AuthSchemes.SessionCookie);
        return new ClaimsPrincipal(identity);
    }
}
