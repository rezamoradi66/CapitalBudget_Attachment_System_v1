namespace Attachments.Api.Auth;

/// <summary>Stable names for the authentication scheme and rate-limit policy.</summary>
public static class AuthSchemes
{
    /// <summary>Cookie scheme + cookie name for server-side sessions (dbo.AuthSessions).</summary>
    public const string SessionCookie = "CBM.Attach.Session";

    /// <summary>Fixed-window per-IP login rate limit policy (10/min default).</summary>
    public const string LoginRateLimitPolicy = "login";
}
