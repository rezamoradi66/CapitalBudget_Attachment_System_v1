using Attachments.Api.Auth;
using Attachments.Api.Http;
using Attachments.Core.Domain;

namespace Attachments.Api.Middleware;

/// <summary>
/// Hard gate for accounts flagged MustChangePassword: every endpoint except
/// /api/v1/auth/* (login, me, change-password, logout) and /health is answered with
/// 403 PASSWORD-CHANGE-REQUIRED until the password change succeeds.
/// The claim is rebuilt from the user row on each request (SessionPrincipalValidator),
/// so the block lifts immediately after a successful change.
/// </summary>
public sealed class PasswordChangeRequiredMiddleware(RequestDelegate next)
{
    private static readonly string[] AllowedPrefixes = ["/api/v1/auth", "/health"];

    public async Task InvokeAsync(HttpContext context)
    {
        var mustChange = string.Equals(
            context.User.FindFirst(PrincipalFactory.ClaimMustChangePassword)?.Value,
            "true",
            StringComparison.OrdinalIgnoreCase);

        if (mustChange && !AllowedPrefixes.Any(prefix => context.Request.Path.StartsWithSegments(prefix)))
        {
            await ProblemResults.WriteAsync(
                context,
                StatusCodes.Status403Forbidden,
                ErrorCodes.PasswordChangeRequired,
                ErrorMessages.For(ErrorCodes.PasswordChangeRequired));
            return;
        }

        await next(context);
    }
}
