using Attachments.Core.Domain;
using Attachments.Api.Http;
using Microsoft.Extensions.Logging;

namespace Attachments.Api.Middleware;

/// <summary>
/// Converts exceptions into RFC 7807 ProblemDetails:
///  - ApiException (thrown by Core services) → its status + stable errorCode + Persian message;
///  - anything else → 500 INTERNAL with a generic Persian message (no internals leaked).
/// Never logs file content, tokens or physical paths.
/// </summary>
public sealed class ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        {
            // Client disconnected — nothing to respond to.
        }
        catch (ApiException exception)
        {
            logger.LogWarning(
                "API failure {ErrorCode} ({StatusCode}) on {Method} {Path}",
                exception.ErrorCode, exception.StatusCode, context.Request.Method, context.Request.Path);
            await ProblemResults.WriteAsync(context, exception.StatusCode, exception.ErrorCode, exception.Message);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Unhandled failure on {Method} {Path}", context.Request.Method, context.Request.Path);
            await ProblemResults.WriteAsync(context, 500, ErrorCodes.Internal, ErrorMessages.For(ErrorCodes.Internal));
        }
    }
}
