using System.Security.Cryptography;
using System.Text.Json;
using Attachments.Core.Domain;
using Attachments.Core.Domain.Entities;
using Attachments.Core.Services;

namespace Attachments.Core.Application;

/// <summary>
/// Application service for attachment metadata + content operations.
/// Enforces (in order): ownership permissions → filename sanitization → size rules →
/// extension whitelist → binary signature → per-owner count limit → atomic persist
/// (metadata row + binary content in the same DB transaction).
/// </summary>
public sealed class AttachmentService(
    IAttachmentRepository repository,
    IAttachmentWriteSessionFactory writeSessionFactory,
    IAttachmentReadScopeFactory readScopeFactory,
    IAttachmentBinaryStore binaryStore,
    FileTypeDetector detector,
    PermissionService permissions,
    ISecurityEventWriter events,
    IIdempotencyCache idempotency,
    IClock clock,
    AttachmentLimits limits)
{
    // ---------------------------------------------------------------- by-code

    public async Task<RequestSummaryDto> GetRequestByCodeAsync(
        ClientContext client, UserContext user, string code, CancellationToken ct = default)
    {
        var request = await repository.FindRequestByCodeAsync(code, ct);
        if (request is null || !permissions.CanViewRequest(user, request.ToSnapshot()))
        {
            // Not visible → deliberately indistinguishable from "does not exist" (no enumeration).
            throw new NotFoundException("درخواستی با این کد یافت نشد یا به شما تعلق ندارد.");
        }

        var micros = await repository.ListMicrosAsync(request.Id, ct);
        return new RequestSummaryDto(
            request.Id, request.Code, request.Title, request.Status, request.BudKind,
            micros.Select(m => new MicroSummaryDto(m.Id, m.SeqNo, m.Title)).ToList());
    }

    // ---------------------------------------------------------------- list

    public async Task<List<AttachmentMetaDto>> ListAsync(
        ClientContext client, UserContext user, OwnerType ownerType, long ownerId, CancellationToken ct = default)
    {
        var (request, micro) = await ResolveOwnerAsync(ownerType, ownerId, ct);
        if (!IsVisible(user, request, micro))
            await DenyAsync(client, user, "list", ownerType, ownerId, null, null, ct);

        var items = await repository.ListAttachmentsByOwnerAsync((int)ownerType, ownerId, ct);
        return await ToDtosAsync(items, ct);
    }

    // ---------------------------------------------------------------- upload

    public async Task<AttachmentMetaDto> UploadAsync(
        ClientContext client, UserContext user, OwnerType ownerType, long ownerId, UploadInput input, CancellationToken ct = default)
    {
        // Idempotency: same X-Request-Id → same 201 result for 10 minutes.
        // NOTE (documented single-node limitation): this cache is in-process (IMemoryCache).
        // For multi-node deployments, back IIdempotencyCache with a distributed store (Redis/SQL).
        var idempotencyKey = string.IsNullOrWhiteSpace(input.IdempotencyKey)
            ? null
            : $"upload:{user.Id}:{input.IdempotencyKey.Trim()}";
        if (idempotencyKey is not null &&
            idempotency.TryGet<AttachmentMetaDto>(idempotencyKey, out var cached) &&
            cached is not null)
        {
            return cached;
        }

        var (request, micro) = await ResolveOwnerAsync(ownerType, ownerId, ct);
        var editable = IsEditable(user, request, micro);
        if (!editable)
            await DenyAsync(client, user, "upload", ownerType, ownerId, null, input.FileName, ct);

        var name = FileNameSanitizer.Sanitize(input.FileName); // 422 FILENAME-INVALID when unsanitizable

        string? displayName = null;
        if (!string.IsNullOrWhiteSpace(input.DisplayName))
            displayName = FileNameSanitizer.SanitizeOrNull(input.DisplayName);

        var bytes = input.Content ?? [];
        if (bytes.Length == 0)
            throw new FileRuleException(422, ErrorCodes.FileEmpty, ErrorMessages.For(ErrorCodes.FileEmpty));
        if (bytes.Length > limits.MaxFileSizeBytes)
            throw new FileRuleException(413, ErrorCodes.FileTooLarge,
                $"{ErrorMessages.For(ErrorCodes.FileTooLarge)} حداکثر حجم مجاز: {limits.MaxFileSizeBytes:N0} بایت.");

        detector.EnsureExtensionAllowed(name, limits.AllowedExtensions);
        detector.EnsureSignatureMatches(name, bytes);

        var existingCount = await repository.CountAttachmentsAsync((int)ownerType, ownerId, ct);
        if (existingCount >= limits.MaxFilesPerOwner)
            throw new FileRuleException(422, ErrorCodes.FileCountExceeded,
                $"{ErrorMessages.For(ErrorCodes.FileCountExceeded)} حداکثر {limits.MaxFilesPerOwner} پیوست برای هر مالک مجاز است.");

        var extension = FileTypeRules.NormalizeExtension(name);
        var now = clock.UtcNow;
        var attachment = new RequestAttachment
        {
            OwnerType = (int)ownerType,
            OwnerId = ownerId,
            RequestId = ownerType == OwnerType.Request ? (int)ownerId : micro!.RequestId,
            MicroId = ownerType == OwnerType.Micro ? (int)ownerId : null,
            OriginalName = name,
            DisplayName = displayName,
            Extension = extension,
            ContentType = FileTypeRules.ContentTypeFor(extension),
            SizeBytes = bytes.Length,
            Sha256 = Convert.ToHexString(SHA256.HashData(bytes)),
            Status = "active",
            UploadedById = user.Id,
            UploadedAt = now,
            UploadedAtJ = JalaliService.FormatDateFromUtc(now),   // Jalali date produced in the SAME save operation
            UploadedTimeJ = JalaliService.FormatTimeFromUtc(now)
        };

        await using (var session = writeSessionFactory.Create())
        {
            await session.CreateAsync(attachment, bytes, ct);
            await session.CommitAsync(ct);
        }

        var uploaderName = (await repository.GetUserDisplayNamesAsync([user.Id], ct)).GetValueOrDefault(user.Id);
        var dto = ToDto(attachment, uploaderName);

        await events.WriteAsync(EventTypes.AttachmentUpload, user.Id, user.Username, client.Ip, client.UserAgent,
            Json(new Dictionary<string, object?>
            {
                ["attachmentId"] = attachment.Id,
                ["ownerType"] = (int)ownerType,
                ["ownerId"] = ownerId,
                ["fileName"] = name,
                ["sizeBytes"] = bytes.Length,
                ["sha256"] = attachment.Sha256
            }), ct);

        if (idempotencyKey is not null)
            idempotency.Set(idempotencyKey, dto, TimeSpan.FromMinutes(10));

        return dto;
    }

    // ---------------------------------------------------------------- info / download

    public async Task<AttachmentMetaDto> GetInfoAsync(
        ClientContext client, UserContext user, long attachmentId, CancellationToken ct = default)
    {
        var attachment = await repository.FindAttachmentAsync(attachmentId, ct)
            ?? throw new NotFoundException("پیوست درخواستی یافت نشد.");
        await EnsureCanViewAsync(client, user, attachment, ct);
        return await ToDtoAsync(attachment, ct);
    }

    public async Task<AttachmentDownload> DownloadAsync(
        ClientContext client, UserContext user, long attachmentId, CancellationToken ct = default)
    {
        var attachment = await repository.FindAttachmentAsync(attachmentId, ct)
            ?? throw new NotFoundException("پیوست درخواستی یافت نشد.");
        await EnsureCanViewAsync(client, user, attachment, ct);

        byte[] content;
        await using (var scope = readScopeFactory.Create())
        {
            var storeContext = await scope.GetContextAsync(ct);
            await using var stream = await binaryStore.OpenReadAsync(storeContext, attachment.Id, ct);
            if (stream is null)
            {
                content = [];
            }
            else
            {
                using var memory = new MemoryStream();
                await stream.CopyToAsync(memory, ct);
                content = memory.ToArray();
            }
        }

        await events.WriteAsync(EventTypes.AttachmentDownload, user.Id, user.Username, client.Ip, client.UserAgent,
            Json(new Dictionary<string, object?>
            {
                ["attachmentId"] = attachment.Id,
                ["ownerType"] = attachment.OwnerType,
                ["ownerId"] = attachment.OwnerId,
                ["fileName"] = attachment.OriginalName,
                ["sizeBytes"] = attachment.SizeBytes
            }), ct);

        var dto = await ToDtoAsync(attachment, ct);
        var downloadName = string.IsNullOrWhiteSpace(attachment.DisplayName) ? attachment.OriginalName : attachment.DisplayName!;
        return new AttachmentDownload(dto, content, attachment.ContentType, downloadName);
    }

    // ---------------------------------------------------------------- delete

    public async Task<DeleteAttachmentResult> DeleteAsync(
        ClientContext client, UserContext user, long attachmentId, CancellationToken ct = default)
    {
        var attachment = await repository.FindAttachmentAsync(attachmentId, ct)
            ?? throw new NotFoundException("پیوست درخواستی یافت نشد.");
        var (request, micro) = await ResolveOwnerAsync((OwnerType)attachment.OwnerType, attachment.OwnerId, ct);
        if (!IsEditable(user, request, micro))
            await DenyAsync(client, user, "delete", (OwnerType)attachment.OwnerType, attachment.OwnerId, attachment.Id, attachment.OriginalName, ct);

        await repository.DeleteAttachmentAsync(attachment, ct); // physical delete; SQL Server removes the FILESTREAM blob

        await events.WriteAsync(EventTypes.AttachmentDelete, user.Id, user.Username, client.Ip, client.UserAgent,
            Json(new Dictionary<string, object?>
            {
                ["attachmentId"] = attachment.Id,
                ["ownerType"] = attachment.OwnerType,
                ["ownerId"] = attachment.OwnerId,
                ["fileName"] = attachment.OriginalName,
                ["sizeBytes"] = attachment.SizeBytes
            }), ct);

        return new DeleteAttachmentResult(attachment.Id, true);
    }

    // ---------------------------------------------------------------- helpers

    private async Task<(Request Request, RequestMicro? Micro)> ResolveOwnerAsync(OwnerType ownerType, long ownerId, CancellationToken ct)
    {
        if (ownerType == OwnerType.Request)
        {
            var request = await repository.FindRequestAsync((int)ownerId, ct)
                ?? throw new NotFoundException("درخواست یافت نشد.");
            return (request, null);
        }

        var micro = await repository.FindMicroAsync((int)ownerId, ct)
            ?? throw new NotFoundException("ریزفهرست یافت نشد.");
        var parentRequest = await repository.FindRequestAsync(micro.RequestId, ct)
            ?? throw new NotFoundException("درخواستِ این ریزفهرست یافت نشد.");
        return (parentRequest, micro);
    }

    private bool IsVisible(UserContext user, Request request, RequestMicro? micro) =>
        micro is null
            ? permissions.CanViewRequest(user, request.ToSnapshot())
            : permissions.CanViewMicro(user, request.ToSnapshot(), micro.ToSnapshot());

    private bool IsEditable(UserContext user, Request request, RequestMicro? micro) =>
        micro is null
            ? permissions.CanEditRequest(user, request.ToSnapshot())
            : permissions.CanEditMicro(user, request.ToSnapshot(), micro.ToSnapshot());

    private async Task<(Request Request, RequestMicro? Micro)> EnsureCanViewAsync(
        ClientContext client, UserContext user, RequestAttachment attachment, CancellationToken ct)
    {
        var (request, micro) = await ResolveOwnerAsync((OwnerType)attachment.OwnerType, attachment.OwnerId, ct);
        if (!IsVisible(user, request, micro))
            await DenyAsync(client, user, "view", (OwnerType)attachment.OwnerType, attachment.OwnerId, attachment.Id, attachment.OriginalName, ct);
        return (request, micro);
    }

    private async Task DenyAsync(
        ClientContext client, UserContext user, string action, OwnerType ownerType, long ownerId,
        long? attachmentId, string? fileName, CancellationToken ct)
    {
        var details = new Dictionary<string, object?>
        {
            ["action"] = action,
            ["ownerType"] = (int)ownerType,
            ["ownerId"] = ownerId,
            ["errorCode"] = ErrorCodes.PermissionDenied
        };
        if (attachmentId is { } id)
            details["attachmentId"] = id;
        if (!string.IsNullOrEmpty(fileName))
            details["fileName"] = fileName;

        await events.WriteAsync(EventTypes.PermissionDenied, user.Id, user.Username, client.Ip, client.UserAgent, Json(details), ct);
        throw new PermissionDeniedException(ErrorMessages.For(ErrorCodes.PermissionDenied));
    }

    private async Task<List<AttachmentMetaDto>> ToDtosAsync(IEnumerable<RequestAttachment> items, CancellationToken ct)
    {
        var list = items.ToList();
        var names = await repository.GetUserDisplayNamesAsync(list.Select(a => a.UploadedById).Distinct(), ct);
        return list.Select(a => ToDto(a, names.GetValueOrDefault(a.UploadedById))).ToList();
    }

    private async Task<AttachmentMetaDto> ToDtoAsync(RequestAttachment attachment, CancellationToken ct)
    {
        var names = await repository.GetUserDisplayNamesAsync([attachment.UploadedById], ct);
        return ToDto(attachment, names.GetValueOrDefault(attachment.UploadedById));
    }

    private static AttachmentMetaDto ToDto(RequestAttachment a, string? uploaderName) =>
        new(a.Id, a.OwnerType, a.OwnerId, a.OriginalName, a.DisplayName, a.Extension, a.ContentType,
            a.SizeBytes, a.Sha256, a.Status, a.UploadedById, uploaderName, a.UploadedAt, a.UploadedAtJ, a.UploadedTimeJ);

    private static string Json(Dictionary<string, object?> details) =>
        JsonSerializer.Serialize(details, AttachmentsJson.Web);
}
