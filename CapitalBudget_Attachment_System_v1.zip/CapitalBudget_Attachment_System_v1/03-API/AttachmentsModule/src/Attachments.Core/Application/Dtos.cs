using Attachments.Core.Domain.Entities;

namespace Attachments.Core.Application;

/// <summary>Uniform success envelope: { "success": true, "data": ... }.</summary>
public sealed record ApiEnvelope(bool Success, object? Data)
{
    public static ApiEnvelope Ok(object? data) => new(true, data);
}

public sealed record AttachmentMetaDto(
    long Id,
    int OwnerType,
    long OwnerId,
    string OriginalName,
    string? DisplayName,
    string Extension,
    string ContentType,
    long SizeBytes,
    string Sha256,
    string Status,
    int UploadedById,
    string? UploadedByName,
    DateTime UploadedAt,
    string? UploadedAtJ,
    string? UploadedTimeJ);

public sealed record MicroSummaryDto(int Id, int SeqNo, string Title);

public sealed record RequestSummaryDto(
    int Id,
    string Code,
    string Title,
    string Status,
    string? BudKind,
    IReadOnlyList<MicroSummaryDto> Micros);

public sealed record UserMeDto(
    int Id,
    string Username,
    string FullName,
    IReadOnlyList<string> Roles,
    bool MustChangePassword);

public sealed record LoginRequest(string Username, string Password);

public sealed record ChangePasswordRequest(string CurrentPassword, string NewPassword);

public sealed record UploadInput(string FileName, string? DisplayName, byte[] Content, string? IdempotencyKey);

public sealed record AttachmentDownload(AttachmentMetaDto Meta, byte[] Content, string ContentType, string DownloadName);

public sealed record DeleteAttachmentResult(long Id, bool Deleted);

public sealed record LoginResult(User User, IReadOnlyList<string> Roles, Guid SessionId);
