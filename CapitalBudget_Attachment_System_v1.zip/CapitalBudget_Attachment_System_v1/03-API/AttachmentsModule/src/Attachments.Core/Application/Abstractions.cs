using System.Text.Json;
using Attachments.Core.Domain.Entities;

namespace Attachments.Core.Application;

/// <summary>Connection + transaction pair handed to a binary store. Nulls for the InMemory provider.</summary>
public sealed record BinaryStoreContext(System.Data.Common.DbConnection? Connection, System.Data.Common.DbTransaction? Transaction);

/// <summary>
/// Pluggable attachment content storage. Production modes (SQL FILESTREAM) require the caller
/// to supply an open SqlConnection + its active SqlTransaction (see SqlFilestreamBinaryStore).
/// </summary>
public interface IAttachmentBinaryStore
{
    string Mode { get; }

    /// <summary>Writes (replaces) the binary content of an already-inserted attachment row, inside the caller's transaction.</summary>
    Task WriteAsync(BinaryStoreContext context, long attachmentId, Stream content, CancellationToken cancellationToken = default);

    /// <summary>Opens the stored content for reading, or null when the row has no content.</summary>
    Task<Stream?> OpenReadAsync(BinaryStoreContext context, long attachmentId, CancellationToken cancellationToken = default);
}

/// <summary>One upload unit-of-work: metadata insert + binary write, committed atomically.</summary>
public interface IAttachmentWriteSession : IAsyncDisposable
{
    Task<RequestAttachment> CreateAsync(RequestAttachment attachment, byte[] content, CancellationToken cancellationToken = default);

    Task CommitAsync(CancellationToken cancellationToken = default);
}

public interface IAttachmentWriteSessionFactory
{
    IAttachmentWriteSession Create();
}

/// <summary>Short-lived scope providing the (connection, transaction) pair for binary reads.</summary>
public interface IAttachmentReadScope : IAsyncDisposable
{
    Task<BinaryStoreContext> GetContextAsync(CancellationToken cancellationToken = default);
}

public interface IAttachmentReadScopeFactory
{
    IAttachmentReadScope Create();
}

public interface IAttachmentRepository
{
    Task<RequestAttachment?> FindAttachmentAsync(long id, CancellationToken cancellationToken = default);

    Task<List<RequestAttachment>> ListAttachmentsByOwnerAsync(int ownerType, long ownerId, CancellationToken cancellationToken = default);

    Task<int> CountAttachmentsAsync(int ownerType, long ownerId, CancellationToken cancellationToken = default);

    /// <summary>Physically deletes the attachment row (SQL Server cascades the FILESTREAM blob).</summary>
    Task DeleteAttachmentAsync(RequestAttachment attachment, CancellationToken cancellationToken = default);

    Task<Request?> FindRequestAsync(int id, CancellationToken cancellationToken = default);

    Task<Request?> FindRequestByCodeAsync(string code, CancellationToken cancellationToken = default);

    Task<RequestMicro?> FindMicroAsync(int id, CancellationToken cancellationToken = default);

    Task<List<RequestMicro>> ListMicrosAsync(int requestId, CancellationToken cancellationToken = default);

    Task<IReadOnlyDictionary<int, string>> GetUserDisplayNamesAsync(IEnumerable<int> userIds, CancellationToken cancellationToken = default);
}

public interface IUserAuthStore
{
    Task<User?> FindUserByUsernameAsync(string username, CancellationToken cancellationToken = default);

    Task<User?> FindUserByIdAsync(int id, CancellationToken cancellationToken = default);

    Task<List<string>> GetRolesAsync(int userId, CancellationToken cancellationToken = default);

    Task<LoginLockout?> FindLockoutAsync(string username, CancellationToken cancellationToken = default);

    /// <summary>Upserts the lockout row keyed by Username.</summary>
    Task SaveLockoutAsync(string username, int failedCount, DateTime? lockedUntilUtc, DateTime lastFailedAtUtc, CancellationToken cancellationToken = default);

    Task ClearLockoutAsync(string username, CancellationToken cancellationToken = default);

    Task SaveUserAsync(User user, CancellationToken cancellationToken = default);

    Task<AuthSession> CreateSessionAsync(AuthSession session, CancellationToken cancellationToken = default);

    Task<AuthSession?> FindSessionAsync(Guid id, CancellationToken cancellationToken = default);

    /// <summary>Sliding expiration: refresh LastSeenAt on each authenticated request.</summary>
    Task TouchSessionAsync(Guid id, DateTime lastSeenAtUtc, CancellationToken cancellationToken = default);

    Task RevokeSessionAsync(Guid id, DateTime revokedAtUtc, CancellationToken cancellationToken = default);
}

public interface ISecurityEventWriter
{
    /// <summary>
    /// Appends a SecurityEvents row. Callers pass compact JSON details — never file content,
    /// never physical paths, never tokens.
    /// </summary>
    Task WriteAsync(string eventType, int? userId, string? username, string ip, string userAgent, string detailsJson, CancellationToken cancellationToken = default);
}

/// <summary>Tiny cache abstraction so Core does not depend on IMemoryCache.</summary>
public interface IIdempotencyCache
{
    bool TryGet<TValue>(string key, out TValue? value);

    void Set<TValue>(string key, TValue value, TimeSpan ttl);
}

public interface IClock
{
    DateTime UtcNow { get; }
}

public sealed class SystemClock : IClock
{
    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Shared JSON options (camelCase, web defaults) for envelopes, DTOs and event details.</summary>
public static class AttachmentsJson
{
    public static readonly JsonSerializerOptions Web = new(JsonSerializerDefaults.Web);
}
