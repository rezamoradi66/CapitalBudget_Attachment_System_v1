using System.Globalization;

namespace Attachments.Core.Services;

/// <summary>
/// Gregorian → Jalali (Solar Hijri) conversion using the standard jalaali arithmetic
/// (breaks-based algorithm, identical to jalaali-js / the reference app).
/// Pure functions; Tehran timezone helpers are provided for producing UploadedAtJ/UploadedTimeJ
/// from UTC timestamps in the same save operation.
/// </summary>
public static class JalaliService
{
    private static readonly int[] Breaks =
    [
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635,
        2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    ];

    /// <summary>Converts a Gregorian date to (JalaliYear, JalaliMonth, JalaliDay).</summary>
    public static (int Year, int Month, int Day) ToJalali(int gy, int gm, int gd)
    {
        var jdn = G2d(gy, gm, gd);
        var gYear = D2g(jdn).Gy;
        var jy = gYear - 621;
        var cal = JalCal(jy);
        var jdn1f = G2d(cal.Gy, 3, cal.March);
        var k = jdn - jdn1f;

        int jm, jd;
        if (k >= 0)
        {
            if (k <= 185)
            {
                jm = 1 + Div(k, 31);
                jd = Mod(k, 31) + 1;
                return (jy, jm, jd);
            }
            k -= 186;
        }
        else
        {
            jy -= 1;
            k += 179;
            if (cal.Leap == 1)
                k += 1;
        }

        jm = 7 + Div(k, 30);
        jd = Mod(k, 30) + 1;
        return (jy, jm, jd);
    }

    /// <summary>Jalali date as "yyyy/MM/dd" (e.g. 1405/08/02).</summary>
    public static string FormatDate(DateTime gregorian)
    {
        var (year, month, day) = ToJalali(gregorian.Year, gregorian.Month, gregorian.Day);
        return string.Create(CultureInfo.InvariantCulture, $"{year:D4}/{month:D2}/{day:D2}");
    }

    /// <summary>Time as "HH:mm" (24h, invariant — matches the CHAR(5) UploadedTimeJ column).</summary>
    public static string FormatTime(DateTime gregorian) =>
        string.Create(CultureInfo.InvariantCulture, $"{gregorian.Hour:D2}:{gregorian.Minute:D2}");

    /// <summary>UTC → Tehran local → "yyyy/MM/dd" Jalali date.</summary>
    public static string FormatDateFromUtc(DateTime utc) => FormatDate(ToTehran(utc));

    /// <summary>UTC → Tehran local → "HH:mm" time.</summary>
    public static string FormatTimeFromUtc(DateTime utc) => FormatTime(ToTehran(utc));

    private static DateTime ToTehran(DateTime utc)
    {
        if (utc.Kind != DateTimeKind.Utc)
            utc = DateTime.SpecifyKind(utc, DateTimeKind.Utc);
        try
        {
            var tz = TimeZoneInfo.FindSystemTimeZoneById("Asia/Tehran"); // Linux/macOS tzdata
            return TimeZoneInfo.ConvertTimeFromUtc(utc, tz);
        }
        catch (TimeZoneNotFoundException)
        {
            try
            {
                var tz = TimeZoneInfo.FindSystemTimeZoneById("Iran Standard Time"); // Windows
                return TimeZoneInfo.ConvertTimeFromUtc(utc, tz);
            }
            catch (Exception)
            {
                // Iran abolished DST in 2022; fixed +03:30 is a safe fallback.
                return utc + TimeSpan.FromHours(3.5);
            }
        }
        catch (InvalidTimeZoneException)
        {
            return utc + TimeSpan.FromHours(3.5);
        }
    }

    private static int Div(int a, int b) => a / b; // C# '/' truncates toward zero, same as JS ~~(a/b)

    private static int Mod(int a, int b) => a - a / b * b;

    private static (int Leap, int Gy, int March) JalCal(int jy)
    {
        var bl = Breaks.Length;
        var gy = jy + 621;
        var leapJ = -14;
        var jp = Breaks[0];
        var jump = 0;

        if (jy < jp || jy >= Breaks[bl - 1])
            throw new ArgumentOutOfRangeException(nameof(jy), $"Jalali year {jy} is outside the supported range.");

        for (var i = 1; i < bl; i++)
        {
            var jm = Breaks[i];
            jump = jm - jp;
            if (jy < jm)
                break;
            leapJ += Div(jump, 33) * 8 + Div(Mod(jump, 33), 4);
            jp = jm;
        }

        var n = jy - jp;
        leapJ += Div(n, 33) * 8 + Div(Mod(n, 33) + 3, 4);
        if (Mod(jump, 33) == 4 && jump - n == 4)
            leapJ += 1;

        var leapG = Div(gy, 4) - Div((Div(gy, 100) + 1) * 3, 4) - 150;
        var march = 20 + leapJ - leapG;

        if (jump - n < 6)
            n = n - jump + Div(jump + 4, 33) * 33;
        var leap = Mod(Mod(n + 1, 33) - 1, 4);
        if (leap == -1)
            leap = 4;

        return (leap, gy, march);
    }

    private static int G2d(int gy, int gm, int gd)
    {
        var d = Div((gy + Div(gm - 8, 6) + 100100) * 1461, 4)
                + Div(153 * Mod(gm + 9, 12) + 2, 5)
                + gd - 34840408;
        d = d - Div(Div(gy + 100100 + Div(gm - 8, 6), 100) * 3, 4) + 752;
        return d;
    }

    private static (int Gy, int Gm, int Gd) D2g(int jdn)
    {
        var j = 4 * jdn + 139361631;
        j += Div(Div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
        var i = Div(Mod(j, 1461), 4) * 5 + 308;
        var gd = Div(Mod(i, 153), 5) + 1;
        var gm = Mod(Div(i, 153), 12) + 1;
        var gy = Div(j, 1461) - 100100 + Div(8 - gm, 6);
        return (gy, gm, gd);
    }
}
