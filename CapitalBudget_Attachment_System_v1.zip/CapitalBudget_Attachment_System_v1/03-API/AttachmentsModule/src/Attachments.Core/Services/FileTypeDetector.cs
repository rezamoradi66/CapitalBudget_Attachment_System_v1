using System.Text;
using Attachments.Core.Domain;

namespace Attachments.Core.Services;

/// <summary>
/// Validates that the declared extension is whitelisted and that the actual binary content
/// carries the expected magic-number signature. A mismatch between declared extension and
/// real content is rejected with 415 FILE-CONTENT-MISMATCH (anti-spoofing, e.g. "setup.pdf"
/// that is actually an MZ/PE executable).
/// </summary>
public sealed class FileTypeDetector
{
    private static readonly byte[] PngSignature = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
    private static readonly byte[] RarSignature = [0x52, 0x61, 0x72, 0x21, 0x1A, 0x07];          // "Rar!\x1A\x07" (RAR4 & RAR5)
    private static readonly byte[] SevenZipSignature = [0x37, 0x7B, 0xAF, 0x27, 0x9C];
    private static readonly byte[] Ole2Signature = [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1];
    private static readonly byte[] ZipSignature = [0x50, 0x4B, 0x03, 0x04];                       // "PK\x03\x04" (zip & OOXML)

    /// <summary>Rejects extensions outside the whitelist with 415 FILE-TYPE-NOT-ALLOWED.</summary>
    public void EnsureExtensionAllowed(string sanitizedFileName, IReadOnlySet<string>? extraAllowed = null)
    {
        var extension = FileTypeRules.NormalizeExtension(sanitizedFileName);
        if (!FileTypeRules.IsAllowed(extension) &&
            (extraAllowed is null || !extraAllowed.Contains(extension)))
        {
            var shown = extension.Length == 0 ? "نامشخص" : extension;
            throw new FileRuleException(415, ErrorCodes.FileTypeNotAllowed,
                $"{ErrorMessages.For(ErrorCodes.FileTypeNotAllowed)} (پسوند: {shown})");
        }
    }

    /// <summary>Verifies the binary signature for the declared extension; 415 FILE-CONTENT-MISMATCH on failure.</summary>
    public void EnsureSignatureMatches(string sanitizedFileName, byte[] bytes)
    {
        var extension = FileTypeRules.NormalizeExtension(sanitizedFileName);
        var ok = extension switch
        {
            ".pdf" => StartsWith(bytes, "%PDF-"u8),
            ".png" => StartsWith(bytes, PngSignature),
            ".jpg" or ".jpeg" => StartsWith(bytes, [0xFF, 0xD8, 0xFF]),
            ".gif" => StartsWith(bytes, "GIF8"u8),
            ".webp" => bytes.Length >= 12 && StartsWith(bytes, "RIFF"u8) && bytes.AsSpan(8, 4).SequenceEqual("WEBP"u8),
            ".zip" or ".docx" or ".xlsx" or ".pptx" => StartsWith(bytes, ZipSignature),
            ".rar" => StartsWith(bytes, RarSignature),
            ".7z" => StartsWith(bytes, SevenZipSignature),
            ".doc" or ".xls" or ".ppt" => StartsWith(bytes, Ole2Signature), // legacy OLE2 compound documents
            ".txt" or ".csv" => LooksLikeText(bytes),
            _ => false // should be unreachable after EnsureExtensionAllowed
        };

        if (!ok)
            throw new FileRuleException(415, ErrorCodes.FileContentMismatch, ErrorMessages.For(ErrorCodes.FileContentMismatch));
    }

    /// <summary>
    /// txt/csv rule: no NUL bytes within the first 512 bytes AND the whole payload must decode
    /// as strict UTF-8 (ASCII is a subset of UTF-8, so "ASCII-ish" holds too).
    /// </summary>
    private static bool LooksLikeText(byte[] bytes)
    {
        var probeLength = Math.Min(512, bytes.Length);
        for (var i = 0; i < probeLength; i++)
            if (bytes[i] == 0x00)
                return false;
        try
        {
            var strictUtf8 = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);
            strictUtf8.GetString(bytes);
            return true;
        }
        catch (DecoderFallbackException)
        {
            return false;
        }
    }

    private static bool StartsWith(byte[] bytes, ReadOnlySpan<byte> signature) =>
        bytes.Length >= signature.Length && bytes.AsSpan(0, signature.Length).SequenceEqual(signature);
}
