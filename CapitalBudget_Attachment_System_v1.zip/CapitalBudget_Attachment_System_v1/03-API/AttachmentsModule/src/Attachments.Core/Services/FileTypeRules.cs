namespace Attachments.Core.Services;

/// <summary>
/// The exact extension whitelist + extension → Content-Type mapping required by the client.
/// The keys of ContentTypes are the single source of truth for "allowed".
/// </summary>
public static class FileTypeRules
{
    public static readonly IReadOnlyDictionary<string, string> ContentTypes =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [".pdf"] = "application/pdf",
            [".doc"] = "application/msword",
            [".docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            [".xls"] = "application/vnd.ms-excel",
            [".xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            [".ppt"] = "application/vnd.ms-powerpoint",
            [".pptx"] = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            [".jpg"] = "image/jpeg",
            [".jpeg"] = "image/jpeg",
            [".png"] = "image/png",
            [".gif"] = "image/gif",
            [".webp"] = "image/webp",
            [".zip"] = "application/zip",
            [".rar"] = "application/vnd.rar",
            [".7z"] = "application/x-7z-compressed",
            [".txt"] = "text/plain",
            [".csv"] = "text/csv"
        };

    public static readonly IReadOnlySet<string> AllowedExtensions =
        new HashSet<string>(ContentTypes.Keys, StringComparer.OrdinalIgnoreCase);

    /// <summary>Extracts the lowercase extension (including the dot) or "" when the name has none.</summary>
    public static string NormalizeExtension(string fileName)
    {
        var dot = fileName.LastIndexOf('.');
        return dot < 0 || dot == fileName.Length - 1 ? "" : fileName[dot..].ToLowerInvariant();
    }

    public static bool IsAllowed(string extension) => AllowedExtensions.Contains(extension);

    public static string ContentTypeFor(string extension) =>
        ContentTypes.TryGetValue(extension, out var contentType) ? contentType : "application/octet-stream";
}
