using Attachments.Core.Application;
using Attachments.Core.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Attachments.Infrastructure.Persistence;

public sealed class AttachmentWriteSessionFactory(AppDbContext db, IAttachmentBinaryStore store) : IAttachmentWriteSessionFactory
{
    public IAttachmentWriteSession Create() => new AttachmentWriteSession(db, store);
}

/// <summary>
/// Coordinates a single upload across EF Core metadata insert and the binary store within the
/// SAME database transaction. With the InMemory (test) provider no real transaction is opened
/// — the InMemoryBinaryStore keeps the bytes itself.
/// </summary>
internal sealed class AttachmentWriteSession : IAttachmentWriteSession
{
    private readonly AppDbContext _db;
    private readonly IAttachmentBinaryStore _store;
    private IDbContextTransaction? _transaction;
    private bool _committed;

    public AttachmentWriteSession(AppDbContext db, IAttachmentBinaryStore store)
    {
        _db = db;
        _store = store;
    }

    public async Task<RequestAttachment> CreateAsync(RequestAttachment attachment, byte[] content, CancellationToken ct = default)
    {
        var relational = _db.Database.IsRelational();
        if (relational)
            _transaction = await _db.Database.BeginTransactionAsync(ct);

        _db.RequestAttachments.Add(attachment);
        await _db.SaveChangesAsync(ct); // metadata INSERT; assigns identity Id; FileContent stays NULL (not EF-mapped)

        var storeContext = relational
            ? new BinaryStoreContext(_db.Database.GetDbConnection(), _transaction!.GetDbTransaction())
            : new BinaryStoreContext(null, null);

        await _store.WriteAsync(storeContext, attachment.Id, new MemoryStream(content), ct);
        return attachment;
    }

    public async Task CommitAsync(CancellationToken ct = default)
    {
        if (_transaction is not null)
            await _transaction.CommitAsync(ct);
        _committed = true;
    }

    public async ValueTask DisposeAsync()
    {
        if (_transaction is not null)
        {
            if (!_committed)
            {
                try
                {
                    await _transaction.RollbackAsync();
                }
                catch
                {
                    // best-effort rollback during disposal
                }
            }

            await _transaction.DisposeAsync();
        }
    }
}

public sealed class BinaryReadScopeFactory(AppDbContext db) : IAttachmentReadScopeFactory
{
    public IAttachmentReadScope Create() => new BinaryReadScope(db);
}

/// <summary>
/// Opens a short transaction (relational providers only) so SqlFilestreamBinaryStore can call
/// GET_FILESTREAM_TRANSACTION_CONTEXT(); committed on dispose (read-only scope).
/// </summary>
internal sealed class BinaryReadScope : IAttachmentReadScope
{
    private readonly AppDbContext _db;
    private IDbContextTransaction? _transaction;

    public BinaryReadScope(AppDbContext db) => _db = db;

    public async Task<BinaryStoreContext> GetContextAsync(CancellationToken ct = default)
    {
        if (!_db.Database.IsRelational())
            return new BinaryStoreContext(null, null);

        _transaction ??= await _db.Database.BeginTransactionAsync(ct);
        return new BinaryStoreContext(_db.Database.GetDbConnection(), _transaction.GetDbTransaction());
    }

    public async ValueTask DisposeAsync()
    {
        if (_transaction is not null)
        {
            try
            {
                await _transaction.CommitAsync();
            }
            catch
            {
                try
                {
                    await _transaction.RollbackAsync();
                }
                catch
                {
                    // nothing more we can do while disposing a read scope
                }
            }

            await _transaction.DisposeAsync();
        }
    }
}
