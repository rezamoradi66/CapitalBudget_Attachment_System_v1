using Attachments.Core.Application;
using Attachments.Core.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Attachments.Infrastructure.Persistence;

public class AttachmentRepository(AppDbContext db) : IAttachmentRepository
{
    public Task<RequestAttachment?> FindAttachmentAsync(long id, CancellationToken ct = default) =>
        db.RequestAttachments.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id, ct);

    public Task<List<RequestAttachment>> ListAttachmentsByOwnerAsync(int ownerType, long ownerId, CancellationToken ct = default) =>
        db.RequestAttachments.AsNoTracking()
            .Where(a => a.OwnerType == ownerType && a.OwnerId == ownerId)
            .OrderBy(a => a.Id)
            .ToListAsync(ct);

    public Task<int> CountAttachmentsAsync(int ownerType, long ownerId, CancellationToken ct = default) =>
        db.RequestAttachments.CountAsync(a => a.OwnerType == ownerType && a.OwnerId == ownerId, ct);

    public async Task DeleteAttachmentAsync(RequestAttachment attachment, CancellationToken ct = default)
    {
        // Attach a stub by key so the physical DELETE is emitted by key.
        db.RequestAttachments.Remove(new RequestAttachment { Id = attachment.Id });
        await db.SaveChangesAsync(ct);
    }

    public Task<Request?> FindRequestAsync(int id, CancellationToken ct = default) =>
        db.Requests.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id, ct);

    public Task<Request?> FindRequestByCodeAsync(string code, CancellationToken ct = default) =>
        db.Requests.AsNoTracking().FirstOrDefaultAsync(r => r.Code == code, ct);

    public Task<RequestMicro?> FindMicroAsync(int id, CancellationToken ct = default) =>
        db.RequestMicros.AsNoTracking().FirstOrDefaultAsync(m => m.Id == id, ct);

    public Task<List<RequestMicro>> ListMicrosAsync(int requestId, CancellationToken ct = default) =>
        db.RequestMicros.AsNoTracking()
            .Where(m => m.RequestId == requestId)
            .OrderBy(m => m.SeqNo)
            .ToListAsync(ct);

    public async Task<IReadOnlyDictionary<int, string>> GetUserDisplayNamesAsync(IEnumerable<int> userIds, CancellationToken ct = default)
    {
        var ids = userIds.Distinct().ToList();
        if (ids.Count == 0)
            return new Dictionary<int, string>();

        var rows = await db.Users.AsNoTracking()
            .Where(u => ids.Contains(u.Id))
            .Select(u => new { u.Id, u.FirstName, u.LastName, u.Username })
            .ToListAsync(ct);

        return rows.ToDictionary(r => r.Id, r => DisplayName(r.FirstName, r.LastName, r.Username));
    }

    internal static string DisplayName(string? firstName, string? lastName, string username)
    {
        var full = string.Join(" ", new[] { firstName, lastName }
            .Where(part => !string.IsNullOrWhiteSpace(part))
            .Select(part => part!.Trim()));
        return full.Length > 0 ? full : username;
    }
}
