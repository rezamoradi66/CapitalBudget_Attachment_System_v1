using Attachments.Core.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Attachments.Infrastructure.Persistence;

/// <summary>
/// EF Core DbContext over the pre-existing CapitalBudgetDB schema. The database is NEVER
/// created or migrated by this module (no EnsureCreated/Migrate); tables below map 1:1 to the
/// documented SQL Server schema, including the FILESTREAM column that is deliberately NOT
/// mapped on RequestAttachment (handled by raw SQL in the binary stores).
/// </summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<Request> Requests => Set<Request>();
    public DbSet<RequestMicro> RequestMicros => Set<RequestMicro>();
    public DbSet<RequestAttachment> RequestAttachments => Set<RequestAttachment>();
    public DbSet<SecurityEvent> SecurityEvents => Set<SecurityEvent>();
    public DbSet<LoginLockout> LoginLockouts => Set<LoginLockout>();
    public DbSet<AuthSession> AuthSessions => Set<AuthSession>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(e =>
        {
            e.ToTable("Users", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
            e.Property(x => x.Username).HasColumnName("Username").HasMaxLength(100).IsRequired();
            e.Property(x => x.PasswordHash).HasColumnName("PasswordHash").HasMaxLength(200).IsRequired();
            e.Property(x => x.FirstName).HasColumnName("FirstName").HasMaxLength(100);
            e.Property(x => x.LastName).HasColumnName("LastName").HasMaxLength(100);
            e.Property(x => x.IsActive).HasColumnName("IsActive");
            e.Property(x => x.MustChangePassword).HasColumnName("MustChangePassword");
            e.Property(x => x.ManagementId).HasColumnName("ManagementId");
            e.Property(x => x.UnitId).HasColumnName("UnitId");
            e.HasIndex(x => x.Username).IsUnique();
        });

        modelBuilder.Entity<UserRole>(e =>
        {
            e.ToTable("UserRoles", "dbo");
            e.HasKey(x => new { x.UserId, x.RoleCode });
            e.Property(x => x.UserId).HasColumnName("UserId");
            e.Property(x => x.RoleCode).HasColumnName("RoleCode").HasMaxLength(30).IsRequired();
        });

        modelBuilder.Entity<Request>(e =>
        {
            e.ToTable("Requests", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
            e.Property(x => x.Code).HasColumnName("Code").HasMaxLength(50).IsRequired();
            e.Property(x => x.Title).HasColumnName("Title").HasMaxLength(300).IsRequired();
            e.Property(x => x.BudKind).HasColumnName("BudKind").HasMaxLength(30);
            e.Property(x => x.Status).HasColumnName("Status").HasMaxLength(30).IsRequired();
            e.Property(x => x.ApplicantId).HasColumnName("ApplicantId");
            e.Property(x => x.CommitterId).HasColumnName("CommitterId");
            e.Property(x => x.SeniorManagerId).HasColumnName("SeniorManagerId");
            e.Property(x => x.ManagementId).HasColumnName("ManagementId");
            e.Property(x => x.UnitId).HasColumnName("UnitId");
            e.Property(x => x.CreatedById).HasColumnName("CreatedById");
            e.HasIndex(x => x.Code).IsUnique();
        });

        modelBuilder.Entity<RequestMicro>(e =>
        {
            e.ToTable("RequestMicros", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
            e.Property(x => x.RequestId).HasColumnName("RequestId");
            e.Property(x => x.SeqNo).HasColumnName("SeqNo");
            e.Property(x => x.Title).HasColumnName("Title").HasMaxLength(300).IsRequired();
            e.Property(x => x.AhpStatus).HasColumnName("AhpStatus").HasMaxLength(30);
            e.HasIndex(x => x.RequestId);
        });

        modelBuilder.Entity<RequestAttachment>(e =>
        {
            e.ToTable("RequestAttachments", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
            e.Property(x => x.OwnerType).HasColumnName("OwnerType");
            e.Property(x => x.OwnerId).HasColumnName("OwnerId");
            e.Property(x => x.RequestId).HasColumnName("RequestId");
            e.Property(x => x.MicroId).HasColumnName("MicroId");
            e.Property(x => x.OriginalName).HasColumnName("OriginalName").HasMaxLength(300).IsRequired();
            e.Property(x => x.DisplayName).HasColumnName("DisplayName").HasMaxLength(300);
            e.Property(x => x.Extension).HasColumnName("Extension").HasMaxLength(20).IsRequired();
            e.Property(x => x.ContentType).HasColumnName("ContentType").HasMaxLength(120).IsRequired();
            e.Property(x => x.SizeBytes).HasColumnName("SizeBytes");
            e.Property(x => x.Sha256).HasColumnName("Sha256").HasMaxLength(64).IsRequired();
            e.Property(x => x.Status).HasColumnName("Status").HasMaxLength(20).IsRequired().HasDefaultValue("active");
            e.Property(x => x.UploadedById).HasColumnName("UploadedById");
            e.Property(x => x.UploadedAt).HasColumnName("UploadedAt");
            e.Property(x => x.UploadedAtJ).HasColumnName("UploadedAtJ").HasMaxLength(10);
            e.Property(x => x.UploadedTimeJ).HasColumnName("UploadedTimeJ").HasMaxLength(5);
            e.HasIndex(x => new { x.OwnerType, x.OwnerId });
            // FileGuid + FileContent (FILESTREAM) intentionally NOT mapped — raw SQL only.
        });

        modelBuilder.Entity<SecurityEvent>(e =>
        {
            e.ToTable("SecurityEvents", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedOnAdd();
            e.Property(x => x.EventType).HasColumnName("EventType").HasMaxLength(50).IsRequired();
            e.Property(x => x.UserId).HasColumnName("UserId");
            e.Property(x => x.Username).HasColumnName("Username").HasMaxLength(100);
            e.Property(x => x.Ip).HasColumnName("Ip").HasMaxLength(64).IsRequired();
            e.Property(x => x.UserAgent).HasColumnName("UserAgent").HasMaxLength(400);
            e.Property(x => x.Details).HasColumnName("Details").IsRequired();
            e.Property(x => x.CreatedAt).HasColumnName("CreatedAt");
            e.HasIndex(x => x.EventType);
        });

        modelBuilder.Entity<LoginLockout>(e =>
        {
            e.ToTable("LoginLockouts", "dbo");
            e.HasKey(x => x.Username);
            e.Property(x => x.Username).HasColumnName("Username").HasMaxLength(100).IsRequired();
            e.Property(x => x.FailedCount).HasColumnName("FailedCount");
            e.Property(x => x.LockedUntilUtc).HasColumnName("LockedUntil");
            e.Property(x => x.LastFailedAtUtc).HasColumnName("LastFailedAt");
        });

        modelBuilder.Entity<AuthSession>(e =>
        {
            e.ToTable("AuthSessions", "dbo");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("Id").ValueGeneratedNever();
            e.Property(x => x.UserId).HasColumnName("UserId");
            e.Property(x => x.Username).HasColumnName("Username").HasMaxLength(100).IsRequired();
            e.Property(x => x.CreatedAtUtc).HasColumnName("CreatedAt");
            e.Property(x => x.LastSeenAtUtc).HasColumnName("LastSeenAt");
            e.Property(x => x.RevokedAtUtc).HasColumnName("RevokedAt");
            e.HasIndex(x => x.UserId);
        });
    }
}
