using System.Data;
using System.Data.SqlTypes;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Microsoft.Data.SqlClient;

namespace Attachments.Infrastructure.Storage;

/// <summary>
/// Production binary store (mode «Filestream») using the native SQL FILESTREAM API:
/// System.Data.SqlTypes.SqlFileStream (Windows-only, compiled via the System.Data.SqlClient
/// package — see csproj note) over FileContent.PathName() +
/// GET_FILESTREAM_TRANSACTION_CONTEXT().
///
/// Contract: the caller (AttachmentWriteSession / BinaryReadScope) supplies the SAME open
/// SqlConnection and its ACTIVE SqlTransaction used for the metadata row, because
/// GET_FILESTREAM_TRANSACTION_CONTEXT() is only meaningful inside a running transaction.
/// The FileContent (VARBINARY(MAX) FILESTREAM) and FileGuid (ROWGUIDCOL) columns are never
/// mapped in EF Core — this store is the only component touching them, via raw SQL.
/// </summary>
public sealed class SqlFilestreamBinaryStore : IAttachmentBinaryStore
{
    public string Mode => AttachmentBinaryStoreModes.Filestream;

    public async Task WriteAsync(BinaryStoreContext context, long attachmentId, Stream content, CancellationToken cancellationToken = default)
    {
        var (connection, transaction) = Require(context);

        // The row was inserted by EF with FileContent untouched (NULL). Seed an empty binary
        // value first so the FILESTREAM cell exists and PathName() becomes available, then
        // stream the bytes through SqlFileStream inside the very same transaction.
        await using (var seed = new SqlCommand(
            "UPDATE dbo.RequestAttachments SET FileContent = 0x WHERE Id = @Id;",
            connection, transaction))
        {
            seed.Parameters.Add("@Id", SqlDbType.BigInt).Value = attachmentId;
            await seed.ExecuteNonQueryAsync(cancellationToken);
        }

        string pathName;
        byte[] transactionContext;
        await using (var command = new SqlCommand(
            "SELECT FileContent.PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT() " +
            "FROM dbo.RequestAttachments WHERE Id = @Id;",
            connection, transaction))
        {
            command.Parameters.Add("@Id", SqlDbType.BigInt).Value = attachmentId;
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                throw new InvalidOperationException($"Attachment row {attachmentId} disappeared before the FILESTREAM write.");

            pathName = reader.GetSqlString(0).IsNull ? string.Empty : reader.GetSqlString(0).Value;
            transactionContext = reader.GetSqlBytes(1).Value;
        }

        if (pathName.Length == 0)
            throw new InvalidOperationException(
                $"Attachment row {attachmentId} has no FILESTREAM path. Verify that FileContent is VARBINARY(MAX) FILESTREAM and the table lives on a FILESTREAM filegroup.");

        await using (var fileStream = new SqlFileStream(pathName, transactionContext, FileAccess.Write))
        {
            await content.CopyToAsync(fileStream, cancellationToken);
            await fileStream.FlushAsync(cancellationToken);
        }
    }

    public async Task<Stream?> OpenReadAsync(BinaryStoreContext context, long attachmentId, CancellationToken cancellationToken = default)
    {
        var (connection, transaction) = Require(context);

        string? pathName = null;
        byte[] transactionContext = [];
        long length = 0;

        await using (var command = new SqlCommand(
            "SELECT FileContent.PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT(), DATALENGTH(FileContent) " +
            "FROM dbo.RequestAttachments WHERE Id = @Id;",
            connection, transaction))
        {
            command.Parameters.Add("@Id", SqlDbType.BigInt).Value = attachmentId;
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
                return null;

            if (!reader.GetSqlString(0).IsNull)
                pathName = reader.GetSqlString(0).Value;
            transactionContext = reader.GetSqlBytes(1).Value;
            length = reader.IsDBNull(2) ? 0 : reader.GetInt64(2);
        }

        if (string.IsNullOrEmpty(pathName) || length == 0)
            return null;

        return new SqlFileStream(pathName!, transactionContext, FileAccess.Read);
    }

    private static (SqlConnection Connection, SqlTransaction Transaction) Require(BinaryStoreContext context)
    {
        if (context.Connection is not SqlConnection connection)
            throw new InvalidOperationException(
                $"{AttachmentBinaryStoreModes.Filestream} binary store requires an open SqlConnection in the BinaryStoreContext.");
        if (context.Transaction is not SqlTransaction transaction)
            throw new InvalidOperationException(
                $"{AttachmentBinaryStoreModes.Filestream} binary store requires an active SqlTransaction in the BinaryStoreContext.");
        return (connection, transaction);
    }
}
