using System.Data;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Microsoft.Data.SqlClient;

namespace Attachments.Infrastructure.Storage;

/// <summary>
/// Fallback production binary store (mode «FilestreamViaSql»): the bytes travel as a plain
/// parameterized VARBINARY(MAX) transfer (UPDATE ... SET FileContent = @bytes / SELECT
/// FileContent) inside the caller's transaction, on the SAME SqlConnection.
/// Works even when the SqlFileStream Win32 API is unavailable (e.g. hardened servers); the
/// content still lives in the FILESTREAM column, only the transport differs.
/// </summary>
public sealed class SqlByteTransferBinaryStore : IAttachmentBinaryStore
{
    public string Mode => AttachmentBinaryStoreModes.FilestreamViaSql;

    public async Task WriteAsync(BinaryStoreContext context, long attachmentId, Stream content, CancellationToken cancellationToken = default)
    {
        var (connection, transaction) = Require(context);

        using var buffer = new MemoryStream();
        await content.CopyToAsync(buffer, cancellationToken);

        await using var command = new SqlCommand(
            "UPDATE dbo.RequestAttachments SET FileContent = @Bytes WHERE Id = @Id;",
            connection, transaction);
        command.Parameters.Add("@Id", SqlDbType.BigInt).Value = attachmentId;
        var bytesParameter = command.Parameters.Add("@Bytes", SqlDbType.VarBinary, -1);
        bytesParameter.Value = buffer.ToArray();
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<Stream?> OpenReadAsync(BinaryStoreContext context, long attachmentId, CancellationToken cancellationToken = default)
    {
        var (connection, transaction) = Require(context);

        await using var command = new SqlCommand(
            "SELECT FileContent FROM dbo.RequestAttachments WHERE Id = @Id;",
            connection, transaction);
        command.Parameters.Add("@Id", SqlDbType.BigInt).Value = attachmentId;

        var result = await command.ExecuteScalarAsync(cancellationToken);
        if (result is not byte[] bytes || bytes.Length == 0)
            return null;

        return new MemoryStream(bytes, writable: false);
    }

    private static (SqlConnection Connection, SqlTransaction Transaction) Require(BinaryStoreContext context)
    {
        if (context.Connection is not SqlConnection connection)
            throw new InvalidOperationException(
                $"{AttachmentBinaryStoreModes.FilestreamViaSql} binary store requires an open SqlConnection in the BinaryStoreContext.");
        if (context.Transaction is not SqlTransaction transaction)
            throw new InvalidOperationException(
                $"{AttachmentBinaryStoreModes.FilestreamViaSql} binary store requires an active SqlTransaction in the BinaryStoreContext.");
        return (connection, transaction);
    }
}
