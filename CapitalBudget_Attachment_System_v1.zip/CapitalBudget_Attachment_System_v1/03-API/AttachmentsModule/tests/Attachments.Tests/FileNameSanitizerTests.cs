using Attachments.Core.Domain;
using Attachments.Core.Services;

using Xunit;

namespace Attachments.Tests;

public class FileNameSanitizerTests
{
    [Theory]
    [InlineData("../../evil.exe", "evil.exe")]
    [InlineData("..\\..\\evil.exe", "evil.exe")]
    [InlineData("/etc/passwd", "passwd")]
    [InlineData("C:\\Users\\bob\\report.pdf", "report.pdf")]
    public void PathTraversal_IsStrippedToBareFileName(string raw, string expected)
    {
        Assert.Equal(expected, FileNameSanitizer.Sanitize(raw));
    }

    [Fact]
    public void ReservedDeviceName_IsRenamed()
    {
        Assert.Equal("_CON.txt", FileNameSanitizer.Sanitize("CON.txt"));
        Assert.Equal("_NUL", FileNameSanitizer.Sanitize("NUL"));
    }

    [Fact]
    public void PersianNames_ArePreserved()
    {
        Assert.Equal("گزارش مالی.xlsx", FileNameSanitizer.Sanitize("گزارش مالی.xlsx"));
        Assert.Equal("صورتجلسه-هیئت‌مديره.pdf", FileNameSanitizer.Sanitize("صورتجلسه-هیئت‌مديره.pdf"));
    }

    [Fact]
    public void OverlongName_IsTruncatedTo260Chars_PreservingExtension()
    {
        var raw = new string('ط', 300) + ".pdf";
        var sanitized = FileNameSanitizer.Sanitize(raw);

        Assert.Equal(FileNameSanitizer.MaxLength, sanitized.Length);
        Assert.EndsWith(".pdf", sanitized, StringComparison.Ordinal);
    }

    [Fact]
    public void ControlCharacters_AreStripped()
    {
        Assert.Equal("name.txt", FileNameSanitizer.Sanitize("na\x01\x02\x1Fme.txt"));
    }

    [Fact]
    public void TrailingDotsAndSpaces_AreTrimmed()
    {
        Assert.Equal("report.pdf", FileNameSanitizer.Sanitize("  report.pdf . . "));
        Assert.Equal("file.txt", FileNameSanitizer.Sanitize("file.txt..."));
    }

    [Fact]
    public void WindowsInvalidCharacters_AreRemoved()
    {
        Assert.Equal("abcdefg.txt", FileNameSanitizer.Sanitize("a<b>:c\"d|e?f*g.txt"));
    }

    [Fact]
    public void WhitespaceRuns_AreCollapsed()
    {
        Assert.Equal("a b.txt", FileNameSanitizer.Sanitize("a\t\t  b.txt"));
    }

    [Fact]
    public void UnsanitizableName_Throws422FilenameInvalid()
    {
        var exception = Assert.Throws<FileRuleException>(() => FileNameSanitizer.Sanitize("  ...  "));

        Assert.Equal(422, exception.StatusCode);
        Assert.Equal(ErrorCodes.FilenameInvalid, exception.ErrorCode);
    }

    [Fact]
    public void SanitizeOrNull_ReturnsNullWhenNothingUsableRemains()
    {
        Assert.Null(FileNameSanitizer.SanitizeOrNull(""));
        Assert.Null(FileNameSanitizer.SanitizeOrNull(null));
        Assert.Null(FileNameSanitizer.SanitizeOrNull("???"));
    }
}
