using Attachments.Core.Domain;
using Attachments.Core.Services;

using Xunit;

namespace Attachments.Tests;

/// <summary>
/// Table-driven verification of the client-approved permission rules
/// (Core/PermissionService.cs is used as-is — these tests pin its behavior).
/// </summary>
public class PermissionServiceTests
{
    private readonly PermissionService _permissions = new();

    private const int CurrentUserId = 7;

    private static UserContext User(string rolesCsv, int? unitId = null, int? managementId = null) =>
        new(
            Id: CurrentUserId,
            Username: "u7",
            UnitId: unitId,
            ManagementId: managementId,
            Roles: rolesCsv.Split(',', StringSplitOptions.RemoveEmptyEntries).ToHashSet(StringComparer.Ordinal));

    // Request snapshots (record equality makes them usable as theory data).
    private static readonly RequestSnapshot OwnDraft = new(BudKinds.Capital, RequestStatuses.Draft,
        ApplicantId: CurrentUserId, CreatedById: CurrentUserId, CommitterId: 9, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot OwnReturned = new(BudKinds.Capital, RequestStatuses.Returned,
        CurrentUserId, CurrentUserId, 9, 100, 10);
    private static readonly RequestSnapshot OwnPendingCommitter = new(BudKinds.Capital, RequestStatuses.PendingCommitter,
        CurrentUserId, CurrentUserId, 9, 100, 10);
    private static readonly RequestSnapshot ForeignDraft = new(BudKinds.Capital, RequestStatuses.Draft,
        ApplicantId: 8, CreatedById: 8, CommitterId: 9, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot PendingCommitterForUser = new(BudKinds.Capital, RequestStatuses.PendingCommitter,
        ApplicantId: 8, CreatedById: 8, CommitterId: CurrentUserId, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot PendingCommitterForOther = new(BudKinds.Capital, RequestStatuses.PendingCommitter,
        ApplicantId: 8, CreatedById: 8, CommitterId: 9, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot PendingSenior = new(BudKinds.Capital, RequestStatuses.PendingSenior,
        ApplicantId: 8, CreatedById: 8, CommitterId: 9, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot CurrentKind = new(BudKinds.Current, RequestStatuses.Draft,
        ApplicantId: 8, CreatedById: 8, CommitterId: 9, ManagementId: 100, UnitId: 10);
    private static readonly RequestSnapshot NullKind = new(null, RequestStatuses.Draft,
        ApplicantId: 8, CreatedById: 8, CommitterId: 9, ManagementId: 100, UnitId: 10);

    public static TheoryData<string, int?, int?, RequestSnapshot, bool, bool> RequestRuleCases => new()
    {
        // roles, unitId, managementId, snapshot, canView, canEdit
        { "admin", null, null, OwnDraft, true, true },
        { "admin", null, null, PendingSenior, true, true },
        { "ceo", null, null, OwnDraft, true, false },
        { "ceo", null, null, PendingSenior, true, false },
        { "applicant", 10, null, OwnDraft, true, true },
        { "applicant", 10, null, OwnReturned, true, true },
        { "applicant", 10, null, OwnPendingCommitter, true, false },
        { "applicant", 10, null, ForeignDraft, false, false },
        { "committer", 10, null, ForeignDraft, true, false },        // same unit → view; not assignee/draft → no edit
        { "committer", 10, null, PendingCommitterForUser, true, true },  // assignee + pending_committer → edit
        { "committer", 10, null, PendingCommitterForOther, true, false },// wrong assignee
        { "committer", 11, null, ForeignDraft, false, false },       // other unit
        { "senior", null, 100, ForeignDraft, true, false },          // same management → view only
        { "senior", null, 101, ForeignDraft, false, false },         // other management
        { "budget", 10, null, CurrentKind, false, false },           // kind mismatch → invisible
        { "budget", 10, null, OwnDraft, true, true },                // kind match (capital) → view + edit
        { "budget", 10, null, NullKind, true, false },               // NULL kind → view only
        { "budget_cur", 10, null, CurrentKind, true, true },
        { "budget_cur", 10, null, OwnDraft, false, false },
        { "budget_cur", 10, null, NullKind, true, false }
    };

    [Theory]
    [MemberData(nameof(RequestRuleCases))]
    public void RequestRules_AreEnforced(
        string rolesCsv, int? unitId, int? managementId, RequestSnapshot request, bool canView, bool canEdit)
    {
        var user = User(rolesCsv, unitId: unitId, managementId: managementId);

        Assert.Equal(canView, _permissions.CanViewRequest(user, request));
        Assert.Equal(canEdit, _permissions.CanEditRequest(user, request));
    }

    [Fact]
    public void Applicant_EditsMicro_WhileAhpNotApproved()
    {
        Assert.True(_permissions.CanEditMicro(User("applicant", unitId: 10), OwnDraft, new MicroSnapshot(AhpStatuses.Pending)));
        Assert.True(_permissions.CanEditMicro(User("applicant", unitId: 10), OwnDraft, new MicroSnapshot(AhpStatuses.Draft)));
    }

    [Fact]
    public void ApprovedMicro_BlocksEdit_ButStaysViewable()
    {
        var applicant = User("applicant", unitId: 10);
        var approved = new MicroSnapshot(AhpStatuses.Approved);

        Assert.False(_permissions.CanEditMicro(applicant, OwnDraft, approved));
        Assert.True(_permissions.CanViewMicro(applicant, OwnDraft, approved));
        Assert.True(_permissions.CanEditMicro(User("admin"), ForeignDraft, approved)); // admin still edits everything
    }

    [Fact]
    public void Ceo_ViewsMicro_ButNeverEdits()
    {
        var ceo = User("ceo");

        Assert.True(_permissions.CanViewMicro(ceo, ForeignDraft, new MicroSnapshot(AhpStatuses.Pending)));
        Assert.False(_permissions.CanEditMicro(ceo, ForeignDraft, new MicroSnapshot(AhpStatuses.Pending)));
    }
}
