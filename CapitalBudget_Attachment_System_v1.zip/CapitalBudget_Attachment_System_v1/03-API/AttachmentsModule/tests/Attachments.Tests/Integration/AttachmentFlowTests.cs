using System.Net;
using System.Text.RegularExpressions;
using Attachments.Core.Domain;
using Attachments.Infrastructure.Persistence;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

[Collection(nameof(AttachmentsApiCollection))]
public class AttachmentFlowTests(AttachmentsApiFactory factory)
{
    private int RequestId(string code)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        return db.Requests.Single(r => r.Code == code).Id;
    }

    private int MicroId(int requestId, int seqNo)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        return db.RequestMicros.Single(m => m.RequestId == requestId && m.SeqNo == seqNo).Id;
    }

    [Fact]
    public async Task Upload_Download_List_Info_Delete_FullCycle()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-LAB-001");
        var bytes = TestFiles.Pdf();

        // ---- upload → 201 + metadata (no path/FileGuid/fileContent in the response)
        var upload = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "report.pdf", bytes, displayName: "گزارش آزمایشی");
        Assert.Equal(HttpStatusCode.Created, upload.StatusCode);
        var rawUpload = await upload.Content.ReadAsStringAsync();
        Assert.DoesNotContain("fileGuid", rawUpload, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("fileContent", rawUpload, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("\"path\"", rawUpload, StringComparison.OrdinalIgnoreCase);

        var meta = await upload.ReadDataAsync();
        var attachmentId = meta.GetProperty("id").GetInt64();
        Assert.True(attachmentId > 0);
        Assert.Equal("report.pdf", meta.GetProperty("originalName").GetString());
        Assert.Equal("گزارش آزمایشی", meta.GetProperty("displayName").GetString());
        Assert.Equal("application/pdf", meta.GetProperty("contentType").GetString());
        Assert.Equal(".pdf", meta.GetProperty("extension").GetString());
        Assert.Equal(bytes.Length, meta.GetProperty("sizeBytes").GetInt64());
        Assert.Equal(64, meta.GetProperty("sha256").GetString()!.Length);
        Assert.Matches(new Regex(@"^\d{4}/\d{2}/\d{2}$"), meta.GetProperty("uploadedAtJ").GetString() ?? "");
        Assert.Matches(new Regex(@"^\d{2}:\d{2}$"), meta.GetProperty("uploadedTimeJ").GetString() ?? "");

        // ---- download → identical bytes + mandatory headers
        var download = await client.GetAsync($"/api/v1/attachments/{attachmentId}");
        Assert.Equal(HttpStatusCode.OK, download.StatusCode);
        var downloaded = await download.Content.ReadAsByteArrayAsync();
        Assert.Equal(bytes, downloaded);
        Assert.Equal("application/pdf", download.Content.Headers.ContentType!.MediaType);
        Assert.StartsWith("attachment", download.Content.Headers.ContentDisposition!.ToString(), StringComparison.Ordinal);
        Assert.Equal("nosniff", download.Headers.TryGetValues("X-Content-Type-Options", out var nosniff) ? nosniff.First() : "");

        // ---- list → exactly 1; info → same id
        var list = await client.GetAsync($"/api/v1/requests/{requestId}/attachments");
        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
        Assert.Equal(1, (await list.ReadDataAsync()).GetArrayLength());

        var info = await client.GetAsync($"/api/v1/attachments/{attachmentId}/info");
        Assert.Equal(HttpStatusCode.OK, info.StatusCode);
        Assert.Equal(attachmentId, (await info.ReadDataAsync()).GetProperty("id").GetInt64());

        // ---- delete → 200; list → empty
        var delete = await client.DeleteAsync($"/api/v1/attachments/{attachmentId}");
        Assert.Equal(HttpStatusCode.OK, delete.StatusCode);
        Assert.True((await delete.ReadDataAsync()).GetProperty("deleted").GetBoolean());

        var listAfterDelete = await client.GetAsync($"/api/v1/requests/{requestId}/attachments");
        Assert.Equal(0, (await listAfterDelete.ReadDataAsync()).GetArrayLength());
    }

    [Fact]
    public async Task Upload_ToForeignRequest_Is403PermissionDenied()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var outsiderRequestId = RequestId("PRG-OUT-001");

        var response = await client.UploadAsync($"/api/v1/requests/{outsiderRequestId}/attachments", "intruder.pdf", TestFiles.Pdf());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.PermissionDenied));
    }

    [Fact]
    public async Task Upload_ToUnknownRequest_Is404()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);

        var response = await client.UploadAsync("/api/v1/requests/999999/attachments", "ghost.pdf", TestFiles.Pdf());

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.NotFound));
    }

    [Fact]
    public async Task Upload_EmptyFile_Is422FileEmpty()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-LAB-001");

        var response = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "empty.pdf", []);

        Assert.Equal(HttpStatusCode.UnprocessableEntity, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileEmpty));
    }

    [Fact]
    public async Task Upload_OversizeFile_Is413FileTooLarge()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-LAB-001");
        var oversize = TestFiles.Pdf(1_048_576 + 1); // MaxFileSizeBytes + 1

        var response = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "big.pdf", oversize);

        Assert.Equal((HttpStatusCode)413, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileTooLarge));
    }

    [Fact]
    public async Task Upload_ExeExtension_Is415FileTypeNotAllowed()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-LAB-001");

        var response = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "virus.exe", TestFiles.Exe());

        Assert.Equal(HttpStatusCode.UnsupportedMediaType, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileTypeNotAllowed));
    }

    [Fact]
    public async Task Upload_ExeDisguisedAsPdf_Is415FileContentMismatch()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-LAB-001");

        var response = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "setup.pdf", TestFiles.Exe());

        Assert.Equal(HttpStatusCode.UnsupportedMediaType, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileContentMismatch));
    }

    [Fact]
    public async Task Upload_11thFile_Is422FileCountExceeded()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-COUNT-001");
        var bytes = TestFiles.Pdf();

        for (var i = 1; i <= 10; i++)
        {
            var ok = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", $"file-{i}.pdf", bytes);
            Assert.True(ok.IsSuccessStatusCode, $"upload {i} failed: {await ok.Content.ReadAsStringAsync()}");
        }

        var eleventh = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "file-11.pdf", bytes);
        Assert.Equal(HttpStatusCode.UnprocessableEntity, eleventh.StatusCode);
        Assert.True(await eleventh.HasErrorCodeAsync(ErrorCodes.FileCountExceeded));
    }

    [Fact]
    public async Task Upload_WithSameRequestId_IsIdempotent()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = RequestId("PRG-IDEM-001");
        var bytes = TestFiles.Pdf();

        var first = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "idem.pdf", bytes, requestId: "it-idem-001");
        var second = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "idem.pdf", bytes, requestId: "it-idem-001");

        Assert.Equal(HttpStatusCode.Created, first.StatusCode);
        Assert.Equal(HttpStatusCode.Created, second.StatusCode);
        Assert.Equal((await first.ReadDataAsync()).GetProperty("id").GetInt64(),
                     (await second.ReadDataAsync()).GetProperty("id").GetInt64());

        var list = await client.GetAsync($"/api/v1/requests/{requestId}/attachments");
        Assert.Equal(1, (await list.ReadDataAsync()).GetArrayLength()); // exactly 1 row
    }

    [Fact]
    public async Task Upload_ToMicro_Returns201AndListed()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var labRequestId = RequestId("PRG-LAB-001");
        var microId = MicroId(labRequestId, 1);
        var bytes = TestFiles.Pdf();

        var upload = await client.UploadAsync($"/api/v1/micros/{microId}/attachments", "micro-report.pdf", bytes);
        Assert.Equal(HttpStatusCode.Created, upload.StatusCode);
        var meta = await upload.ReadDataAsync();
        Assert.Equal(2, meta.GetProperty("ownerType").GetInt32()); // Micro

        var list = await client.GetAsync($"/api/v1/micros/{microId}/attachments");
        Assert.Equal(1, (await list.ReadDataAsync()).GetArrayLength());

        // cleanup so other suites start with a clean PRG-LAB-001
        Assert.Equal(HttpStatusCode.OK, (await client.DeleteAsync($"/api/v1/attachments/{meta.GetProperty("id").GetInt64()}")).StatusCode);
    }

    [Fact]
    public async Task Download_UnknownAttachment_Is404()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);

        var response = await client.GetAsync("/api/v1/attachments/424242/info");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.NotFound));
    }
}
