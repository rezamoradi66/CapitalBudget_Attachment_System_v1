using System.Net;
using System.Net.Http.Json;
using Attachments.Core.Domain;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// Dedicated factory with a 3-logins-per-minute limit (own host + own InMemory database)
/// to verify the fixed-window per-IP limiter on /auth/login in isolation.
/// </summary>
public sealed class RateLimitFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.UseSetting("Database:Provider", "InMemory");
        builder.UseSetting("Database:Name", "attachments-it-rl");
        builder.UseSetting("Attachments:BinaryStore", "InMemory");
        builder.UseSetting("Attachments:LoginRateLimitPerMinute", "3");
        builder.ConfigureAppConfiguration((_, configuration) =>
        {
            configuration.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Database:Provider"] = "InMemory",
                ["Database:Name"] = "attachments-it-rl",
                ["Attachments:BinaryStore"] = "InMemory",
                ["Attachments:LoginRateLimitPerMinute"] = "3"
            });
        });
    }
}

[CollectionDefinition("RateLimit")]
public sealed class RateLimitCollection : ICollectionFixture<RateLimitFactory>;

[Collection("RateLimit")]
public class RateLimitTests(RateLimitFactory factory)
{
    [Fact]
    public async Task Login_ExceedingPerMinuteLimit_Is429RateLimited()
    {
        using var scope = factory.Services.CreateScope();
        await DbSeed.SeedAsync(scope.ServiceProvider);

        var client = factory.CreateClient();

        // The first 3 requests pass the limiter (they may be 401 INVALID-CREDENTIALS).
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var attemptResponse = await client.PostAsJsonAsync("/api/v1/auth/login",
                new { username = DbSeed.LockedUsername, password = $"bad-{attempt}" });
            Assert.NotEqual(HttpStatusCode.TooManyRequests, attemptResponse.StatusCode);
        }

        var limited = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.LockedUsername, password = "one-too-many" });

        Assert.Equal(HttpStatusCode.TooManyRequests, limited.StatusCode);
        Assert.True(await limited.HasErrorCodeAsync(ErrorCodes.RateLimited));
    }
}
