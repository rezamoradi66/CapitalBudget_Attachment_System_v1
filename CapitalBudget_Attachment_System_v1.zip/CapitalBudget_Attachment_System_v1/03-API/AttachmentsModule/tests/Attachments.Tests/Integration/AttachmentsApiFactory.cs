using Attachments.Core.Domain.Entities;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Core.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// One host (and therefore one EF InMemory database) shared by every integration test class
/// in the «AttachmentsApi» collection. Config override switches the app to the InMemory
/// provider + InMemory binary store and removes the login rate limit for the shared factory.
/// </summary>
public sealed class AttachmentsApiFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public const string DatabaseName = "attachments-it";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.UseSetting("Database:Provider", "InMemory");
        builder.UseSetting("Database:Name", DatabaseName);
        builder.UseSetting("Attachments:BinaryStore", "InMemory");
        builder.UseSetting("Attachments:LoginRateLimitPerMinute", "10000");
        builder.ConfigureAppConfiguration((_, configuration) =>
        {
            configuration.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Database:Provider"] = "InMemory",
                ["Database:Name"] = DatabaseName,
                ["Attachments:BinaryStore"] = "InMemory",
                ["Attachments:LoginRateLimitPerMinute"] = "10000"
            });
        });
    }

    public new Task DisposeAsync() => Task.CompletedTask; // host disposal is owned by WebApplicationFactory

    Task IAsyncLifetime.InitializeAsync() => SeedAsync();

    private async Task SeedAsync()
    {
        using var scope = Services.CreateScope();
        await DbSeed.SeedAsync(scope.ServiceProvider);
    }
}

[CollectionDefinition(nameof(AttachmentsApiCollection))]
public sealed class AttachmentsApiCollection : ICollectionFixture<AttachmentsApiFactory>;
