using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>HTTP helpers: session-cookie propagation, envelope parsing, multipart upload.</summary>
public static class TestClient
{
    public const string SessionCookieName = "CBM.Attach.Session";

    /// <summary>Performs a real login and pins the issued session cookie on the client.</summary>
    public static async Task<HttpClient> LoginAsync(this HttpClient client, string username, string password)
    {
        var response = await client.PostAsJsonAsync("/api/v1/auth/login", new { username, password });
        Assert.True(response.IsSuccessStatusCode, $"login failed for '{username}': {(int)response.StatusCode} {await response.Content.ReadAsStringAsync()}");

        var setCookie = response.Headers.TryGetValues("Set-Cookie", out var values)
            ? values.FirstOrDefault(v => v.StartsWith($"{SessionCookieName}=", StringComparison.Ordinal))
            : null;
        Assert.NotNull(setCookie);

        var cookiePair = setCookie!.Split(';')[0];
        client.DefaultRequestHeaders.Remove("Cookie");
        client.DefaultRequestHeaders.Add("Cookie", cookiePair);
        return client;
    }

    /// <summary>Parses the {success,data} envelope and returns `data`.</summary>
    public static async Task<JsonElement> ReadDataAsync(this HttpResponseMessage response)
    {
        var json = await response.Content.ReadAsStringAsync();
        using var document = JsonDocument.Parse(json);
        return document.RootElement.GetProperty("data").Clone();
    }

    /// <summary>Reads the stable `errorCode` from a ProblemDetails body ("" when absent).</summary>
    public static async Task<string> ReadErrorCodeAsync(this HttpResponseMessage response)
    {
        var json = await response.Content.ReadAsStringAsync();
        using var document = JsonDocument.Parse(json);
        return document.RootElement.TryGetProperty("errorCode", out var code) ? code.GetString() ?? "" : "";
    }

    public static async Task<bool> HasErrorCodeAsync(this HttpResponseMessage response, string errorCode) =>
        await response.ReadErrorCodeAsync() == errorCode;

    /// <summary>POST multipart/form-data with the `file` field (+ optional displayName / X-Request-Id).</summary>
    public static async Task<HttpResponseMessage> UploadAsync(
        this HttpClient client, string url, string fileName, byte[] bytes,
        string? displayName = null, string? requestId = null)
    {
        using var form = new MultipartFormDataContent();
        var fileContent = new ByteArrayContent(bytes);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
        form.Add(fileContent, "file", fileName);
        if (!string.IsNullOrEmpty(displayName))
            form.Add(new StringContent(displayName), "displayName");

        using var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = form };
        if (!string.IsNullOrEmpty(requestId))
            request.Headers.Add("X-Request-Id", requestId);
        // The request MUST be awaited inside this method: disposing `form` before the send
        // completes would close the multipart stream mid-flight (ObjectDisposedException).
        return await client.SendAsync(request);
    }
}
