using System.Net;
using Attachments.Core.Domain;
using Attachments.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// dbo.SecurityEvents audit trail: upload / download / delete / permission_denied are recorded,
/// and no Details payload ever contains file content (the "%PDF" marker must never appear),
/// physical paths or drive letters.
/// </summary>
[Collection(nameof(AttachmentsApiCollection))]
public class SecurityEventTests(AttachmentsApiFactory factory)
{
    [Fact]
    public async Task AttachmentEvents_AreRecorded_WithoutFileContent()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var requestId = OwnerRequestId("PRG-LAB-001");
        var outsiderRequestId = OwnerRequestId("PRG-OUT-001");
        var bytes = TestFiles.Pdf();

        var upload = await client.UploadAsync($"/api/v1/requests/{requestId}/attachments", "event-log.pdf", bytes);
        Assert.Equal(HttpStatusCode.Created, upload.StatusCode);
        var attachmentId = (await upload.ReadDataAsync()).GetProperty("id").GetInt64();

        var download = await client.GetAsync($"/api/v1/attachments/{attachmentId}");
        Assert.Equal(HttpStatusCode.OK, download.StatusCode);

        var denied = await client.UploadAsync($"/api/v1/requests/{outsiderRequestId}/attachments", "no-access.pdf", bytes);
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode);

        var delete = await client.DeleteAsync($"/api/v1/attachments/{attachmentId}");
        Assert.Equal(HttpStatusCode.OK, delete.StatusCode);

        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var events = await db.SecurityEvents.AsNoTracking().ToListAsync();

        Assert.Contains(events, e => e.EventType == EventTypes.AttachmentUpload);
        Assert.Contains(events, e => e.EventType == EventTypes.AttachmentDownload);
        Assert.Contains(events, e => e.EventType == EventTypes.AttachmentDelete);
        Assert.Contains(events, e => e.EventType == EventTypes.PermissionDenied);

        // File bytes never appear in audit details — for ALL events, not just the above.
        Assert.All(events, e => Assert.DoesNotContain("%PDF", e.Details, StringComparison.OrdinalIgnoreCase));

        Assert.All(events, e => Assert.DoesNotContain("PathName", e.Details, StringComparison.OrdinalIgnoreCase));
        Assert.All(events, e => Assert.DoesNotContain(":\\".ToString(), e.Details, StringComparison.Ordinal));
    }

    private int OwnerRequestId(string code)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        return db.Requests.Single(r => r.Code == code).Id;
    }
}
