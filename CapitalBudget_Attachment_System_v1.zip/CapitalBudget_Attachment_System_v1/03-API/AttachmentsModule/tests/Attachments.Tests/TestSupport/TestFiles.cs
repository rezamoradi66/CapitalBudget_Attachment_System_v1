using Attachments.Core.Domain;
using Attachments.Core.Services;

namespace Attachments.Tests;

/// <summary>Deterministic sample payloads used by detector and integration tests.</summary>
public static class TestFiles
{
    /// <summary>Minimal real PDF starting with "%PDF-1.4\n%CBM-LAB\n" and padded with 'A'.</summary>
    public static byte[] Pdf(long? totalSize = null)
    {
        var head = "%PDF-1.4\n%CBM-LAB\n"u8.ToArray();
        var size = (int)(totalSize ?? head.Length + 48);
        var bytes = new byte[size];
        Array.Copy(head, bytes, Math.Min(head.Length, size));
        for (var i = head.Length; i < size; i++)
            bytes[i] = 0x41; // 'A'
        return bytes;
    }

    public static byte[] Exe() => [0x4D, 0x5A, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00];
    public static byte[] Png() => [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52];
    public static byte[] Jpg() => [0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46];
    public static byte[] Gif() => [0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00];
    public static byte[] Webp()
    {
        var bytes = new List<byte>(16);
        bytes.AddRange("RIFF"u8.ToArray());
        bytes.AddRange([0x00, 0x00, 0x00, 0x00]);
        bytes.AddRange("WEBP"u8.ToArray());
        bytes.AddRange([0x56, 0x50, 0x38, 0x20]);
        return [.. bytes];
    }
    public static byte[] Zip() => [0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x00, 0x00];
    public static byte[] Rar() => [0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00];
    public static byte[] SevenZip() => [0x37, 0x7B, 0xAF, 0x27, 0x9C, 0x00, 0x00, 0x00];
    public static byte[] Doc() => [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1, 0x00, 0x00];
    public static byte[] Txt() => "سند آزمایشی — plain UTF-8 text without NUL bytes."u8.ToArray();

    /// <summary>Plain text whose first 512 bytes contain an embedded NUL — must be rejected for .txt/.csv.</summary>
    public static byte[] TxtWithNullByte() => "payload\x00with NUL"u8.ToArray();

    /// <summary>Valid signature bytes for the given (lowercase) extension.</summary>
    public static byte[] For(string extension) => extension.ToLowerInvariant() switch
    {
        ".pdf" => Pdf(),
        ".png" => Png(),
        ".jpg" or ".jpeg" => Jpg(),
        ".gif" => Gif(),
        ".webp" => Webp(),
        ".zip" or ".docx" or ".xlsx" or ".pptx" => Zip(),
        ".rar" => Rar(),
        ".7z" => SevenZip(),
        ".doc" or ".xls" or ".ppt" => Doc(),
        ".txt" or ".csv" => Txt(),
        _ => throw new ArgumentException($"No sample payload for extension '{extension}'.", nameof(extension))
    };
}
