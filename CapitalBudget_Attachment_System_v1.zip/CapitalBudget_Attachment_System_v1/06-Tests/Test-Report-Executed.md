# گزارش آزمون‌های اجراشده واقعی — محیط توسعه (Test-Report-Executed)

**روش اجرا:** `dotnet test -c Release` با SDK 10.0.402 — WebApplicationFactory + EF InMemory + Store جایگزین InMemory + استریم واقعی HTTP.
**نتیجه نهایی: 89/89 PASS — 0 رد — 0 خطا** (اجرای آخر: پس از اصلاحات؛ Duration ≈ 4s)

| مجموعه | فایل | تعداد | نتیجه |
|---|---|---|---|
| یکپارچگی HTTP | Integration/AnonymousAccessTests | 11 | ✅ همه (401 همه Endpointهای محافظت‌شده + /health ناشناس) |
| یکپارچگی HTTP | Integration/AuthFlowTests | 5 | ✅ چرخه ورود/me/خروج؛ یکنواختی 401 (بدون افشای وجود کاربر)؛ قفل ۵تلاشی→۱۵دقیقه و بازگشایی پس از انقضا؛ by-code و scope آن |
| یکپارچگی HTTP | Integration/AttachmentFlowTests | 13 | ✅ چرخه کامل بارگذاری/دانلود(تطبیق بایت)/فهرست/info/حذف؛ 403 بیگانه؛ 404 ناشناس؛ 413 بزرگ‌تر از ۱MB؛ 422 خالی؛ 422 پیوست یازدهم؛ 415 پسوند غیرمجاز؛ 415 محتوای ناسازگار (exe با نام pdf)؛ idempotency با X-Request-Id؛ پیوست ردیف (micro) |
| یکپارچگی HTTP | Integration/PasswordChangeFlowTests | 4 | ✅ مسدودی تا تغییر رمز (D-01/دکور D-16)؛ رد رمز رایج/کوتاه/برابر نام کاربری؛ ورود با رمز جدید فقط |
| یکپارچگی HTTP | Integration/RateLimitTests | 1 | ✅ ورود بیش از سقف → 429 RATE-LIMITED (کارخانه اختصاصی با سقف ۳) |
| یکپارچگی HTTP | Integration/SecurityEventTests | 1 | ✅ رویدادهای upload/download/delete/denied ثبت؛ بدون محتوای فایل (بدون «%PDF») |
| واحد | FileTypeDetectorTests | 8 | ✅ امضاهای PDF/PNG/JPEG/GIF/WEBP/ZIP(OOXML)/RAR/7Z/OLE2/متن؛ ناهم‌خوانی؛ پسوند خارج از فهرست |
| واحد | FileNameSanitizerTests | 9 | ✅ Path Traversal، نام‌های رزرو ویندوز (CON و…)، نویسه کنترلی، طول ۳۰۰+، حفظ نام فارسی |
| واحد | PermissionServiceTests | 12 | ✅ ماتریس کامل نقش‌ها (admin/ceo/applicant/committer/senior/budget/budget_cur) + قفل micro تأییدشده + مستثنای admin طبق کد مرجع |
| واحد | JalaliServiceTests | 6 | ✅ تبدیل‌های طلایی (مثلاً 2026-10-24→1405/08/02) |
| دود HTML | TC-ATT-050/051 (test_adapter.js + verify_patch.py) | 43 | ✅ 38/38 راستی‌آزمایی وصله + 5/5 دود آداپتور |
| رگرسیون HTML | سوت تثبیت رسمی v3.1.1 روی نسخه وصله‌شده | 36 | ✅ 36/36 (برابر خط پایه) |

## اشکالات کشف‌شده حین آزمون و اصلاحات (شواهد ارزش آزمون واقعی)

| # | علامت | ریشه | اصلاح |
|---|---|---|---|
| ۱ | 34 رد یکجا: «constructor parameters did not have matching fixture data» | نام کالکشن xunit: تعریف `"AttachmentsApi"` در برابر ارجاع `nameof(AttachmentsApiCollection)` | هم‌سازی نام تعریف با ارجاع |
| ۲ | آبشار 429 روی ورودها در کل مجموعه | Settings در top-level Program.cs زودتر از اورراید آزمون بسته می‌شد | اورراید با `UseSetting` در کارخانه‌های آزمون (رفتار Production دست‌نخورده) |
| ۳ | `ObjectDisposedException` روی multipart | `using` روی محتوا قبل از پایان SendAsync در کمکی آزمون | await درون متد |
| ۴ | رد منطقی «قفل micro برای admin» | ناسازگاری با قاعده admin-first کد مرجع (خط ۱۸۸۴) | اصلاح PermissionService + تست |
| ۵ | ناسازگاری runner (xunit 2.9 با runner 3.x) | نسخه runner | pin به runner 2.8.2 |

> صادقانه: هیچ‌یک از این پنج مورد «آزمون شبیه‌سازی‌شده» نیستند؛ همگی در اجرای واقعی کشف و رفع شدند — دقیقاً دلیل الزام بند ۱۳ مأموریت.

## دامنه و مرز نتیجه

- این نتایج منطق مجوز، اعتبارسنجی فایل، احراز هویت، قرارداد HTTP و جریان متادیتا را در **Store جایگزین** اثبات می‌کند.
- **مسیر واقعی SqlFileStream/FILESTREAM اینجا آزمایش نشده** (SQL Server/Windows در محیط توسعه نیست) — پوشش آن: TC-ATT-030…036 در `Lab-Test-Runbook.md` (PENDING-LAB).
