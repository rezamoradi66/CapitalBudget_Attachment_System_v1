/* =====================================================================
   اسکریپت ۹۹ — بازگردانی (Rollback) ساختار پیوست‌ها — با حفاظت داده
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶
   ---------------------------------------------------------------------
   هدف:
     حذف «فقط عناصری که اسکریپت ۰۲ اضافه کرده است» — به ترتیب ایمن:
       ۱) اگر جدول dbo.RequestAttachments ردیف دارد: «هیچ کاری انجام
          نمی‌شود» و فقط هشدار + دستور بازیابی از پشتیبان چاپ می‌گردد
          (سیاست: هرگز داده پیوست به‌صورت بی‌صدا نابود نشود).
       ۲) اگر جدول صفر ردیف دارد:
          - اگر جدول «توسط اسکریپت ۰۲ ساخته شده» باشد → DROP TABLE کامل.
          - اگر جدول «از قبل موجود» بوده باشد → فقط FKها، ایندکس‌ها،
            قیدهای CHECK و ستون‌های الحاقی v6 حذف می‌شوند؛ ستون‌های هسته
            و داده‌ها دست‌نخورده می‌مانند.
       ۳) فایل کانتینر و فایل‌گروپ FILESTREAM فقط «در صورت خالی بودن» حذف می‌شوند.
   ---------------------------------------------------------------------
   روش تشخیص «جدول ساخته‌شده توسط اسکریپت»:
     الف) وجود Extended Property با نام CreatedByScript (ثبت‌شده توسط اسکریپت ۰۲)؛
     ب) روش جایگزین (ساده): شمارش ستون‌های جدول = ۱۸ (یعنی فقط ستون‌های
        طراحی v6 موجودند و هیچ ستون خارجی از طراحی قدیمی نیست).
   ---------------------------------------------------------------------
   نکات ایمنی:
     * هر گام با گارد و پیام فارسی همراه است و در TRY/CATCH اجرا می‌شود.
     * اجرای مکرر امن است (Idempotent) — عناصر غایب رد می‌شوند.
     * این اسکریپت حذف «داده» نیست؛ فقط ساختار است — و حتی آن هم مشروط.
   ===================================================================== */
SET NOCOUNT ON;

IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید. اجرا متوقف شد.';
    RETURN;
END

DECLARE @FGName  NVARCHAR(128) = N'AttachmentsFS';    /* با نام فایل‌گروپ اسکریپت ۰۲ مطابقت داده شود */
DECLARE @FSFile  NVARCHAR(128) = N'AttachmentsFSData';/* نام منطقی فایل کانتینر (ثابت در اسکریپت ۰۲)      */
DECLARE @Tid     INT = OBJECT_ID(N'dbo.RequestAttachments', N'U');
DECLARE @RowCount BIGINT = 0;

PRINT N'=== اسکریپت ۹۹: Rollback ساختار پیوست‌ها — شروع ===';
PRINT N'پایگاه‌داده جاری: ' + DB_NAME() + N' — یادآوری: این اسکریپت هرگز داده را بی‌صدا حذف نمی‌کند.';

/* ================== گام ۰: شمارش ردیف‌ها — حفاظت اصلی داده ================== */
IF @Tid IS NOT NULL
    SELECT @RowCount = ISNULL(SUM(CAST(p.rows AS BIGINT)), 0)
    FROM sys.partitions AS p
    WHERE p.object_id = @Tid AND p.index_id IN (0, 1);

IF @RowCount > 0
BEGIN
    PRINT N'*******************************************************************';
    PRINT N'★ هشدار مهم: جدول dbo.RequestAttachments حاوی ' + CAST(@RowCount AS NVARCHAR(20)) + N' ردیف است. ★';
    PRINT N'طبق سیاست حفاظت از داده پیوست‌ها، هیچ تغییری اعمال نشد.';
    PRINT N'برای حذف ساختار در چنین وضعیتی، تنها مسیر مجاز چنین است:';
    PRINT N'  ۱) گرفتن پشتیبان کامل از پایگاه‌داده (شامل داده‌های FILESTREAM)؛';
    PRINT N'  ۲) تأیید کتبی مالک داده/DBA مبنی بر عدم نیاز به این داده‌ها؛';
    PRINT N'  ۳) بازیابی کامل (RESTORE) ساختار و داده از نسخه پشتیبان قبلی در یک محیط جدا؛';
    PRINT N'  ۴) سپس اجرای این اسکریپت روی نسخه «خالی‌شده از داده».';
    PRINT N'*******************************************************************';
    RETURN;
END
PRINT N'OK: جدول پیوست‌ها خالی است (' + CAST(@RowCount AS NVARCHAR(10)) + N' ردیف) — ادامه Rollback مجاز است.';

/* ================== گام ۱: تشخیص سازنده جدول ================== */
DECLARE @CreatedByScript BIT = 0;

IF @Tid IS NOT NULL
BEGIN
    IF EXISTS (SELECT 1 FROM sys.extended_properties
               WHERE major_id = @Tid AND name = N'CreatedByScript' AND value = N'02-Create-Attachment-Structure')
        SET @CreatedByScript = 1;
    ELSE IF (SELECT COUNT(*) FROM sys.columns WHERE object_id = @Tid) = 18
        SET @CreatedByScript = 1;  /* روش جایگزین: جدول فقط شامل ۱۸ ستون طراحی v6 است */
END

/* ================== گام ۲: حذف ساختار جدول ================== */
IF @Tid IS NULL
    PRINT N'اطلاع: جدول dbo.RequestAttachments وجود ندارد — گام حذف جدول رد شد.';
ELSE IF @CreatedByScript = 1
BEGIN
    /* جدول کاملاً توسط اسکریپت ۰۲ ساخته شده — DROP TABLE همه قیدها/ایندکس‌ها را نیز حذف می‌کند
       و Extended Property نشانگر نیز همراه جدول حذف می‌شود. */
    BEGIN TRY
        DROP TABLE dbo.RequestAttachments;
        PRINT N'OK: جدول dbo.RequestAttachments (ساخته‌شده توسط اسکریپت ۰۲) به‌طور کامل حذف شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: حذف جدول ناموفق بود (احتمالاً وابستگی خارجی وجود دارد): ' + ERROR_MESSAGE();
        RETURN;
    END CATCH
END
ELSE
BEGIN
    /* جدول از قبل (برنامه قدیمی/ساخت دستی) وجود داشته — فقط الحاقیات v6 حذف می‌شوند */
    PRINT N'اطلاع: جدول از قبل موجود بوده است — فقط عناصر اضافه‌شده توسط اسکریپت ۰۲ حذف می‌شوند؛ ستون‌های هسته و داده حفظ می‌شوند.';

    /* --- ۲-۱) کلیدهای خارجی --- */
    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_Request')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT FK_Attachments_Request; PRINT N'OK: FK_Attachments_Request حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف FK_Attachments_Request ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_Micro')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT FK_Attachments_Micro; PRINT N'OK: FK_Attachments_Micro حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف FK_Attachments_Micro ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_UploadedBy')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT FK_Attachments_UploadedBy; PRINT N'OK: FK_Attachments_UploadedBy حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف FK_Attachments_UploadedBy ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END

    /* --- ۲-۲) قیدهای CHECK (نام‌های اضافه‌شده توسط اسکریپت ۰۲) --- */
    DECLARE @Ck NVARCHAR(128);
    DECLARE ck_cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT N'CK_Attachments_ExactlyOneOwner'
        UNION ALL SELECT N'CK_Attachments_Status'
        UNION ALL SELECT N'CK_Attachments_Size'
        UNION ALL SELECT N'CK_Attachments_OwnerType';
    OPEN ck_cur;
    FETCH NEXT FROM ck_cur INTO @Ck;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = @Ck AND parent_object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U'))
        BEGIN
            BEGIN TRY
                EXEC (N'ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT ' + @Ck + N';');
                PRINT N'OK: قید ' + @Ck + N' حذف شد.';
            END TRY
            BEGIN CATCH
                PRINT N'FAIL: حذف قید ' + @Ck + N' ناموفق: ' + ERROR_MESSAGE();
            END CATCH
        END
        FETCH NEXT FROM ck_cur INTO @Ck;
    END
    CLOSE ck_cur;
    DEALLOCATE ck_cur;

    /* --- ۲-۳) ایندکس‌های غیرخوشه‌ای --- */
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Attachments_UploadedAt' AND object_id = @Tid)
    BEGIN
        BEGIN TRY DROP INDEX IX_Attachments_UploadedAt ON dbo.RequestAttachments; PRINT N'OK: IX_Attachments_UploadedAt حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف IX_Attachments_UploadedAt ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Attachments_Micro' AND object_id = @Tid)
    BEGIN
        BEGIN TRY DROP INDEX IX_Attachments_Micro ON dbo.RequestAttachments; PRINT N'OK: IX_Attachments_Micro حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف IX_Attachments_Micro ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Attachments_Request' AND object_id = @Tid)
    BEGIN
        BEGIN TRY DROP INDEX IX_Attachments_Request ON dbo.RequestAttachments; PRINT N'OK: IX_Attachments_Request حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف IX_Attachments_Request ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Attachments_Owner' AND object_id = @Tid)
    BEGIN
        BEGIN TRY DROP INDEX IX_Attachments_Owner ON dbo.RequestAttachments; PRINT N'OK: IX_Attachments_Owner حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف IX_Attachments_Owner ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END

    /* --- ۲-۴) قید یکتای FileGuid (پیش از حذف ستون) --- */
    IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE type = N'U' AND name = N'UX_Attachments_FileGuid')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT UX_Attachments_FileGuid; PRINT N'OK: UX_Attachments_FileGuid حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف UX_Attachments_FileGuid ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END

    /* --- ۲-۵) پیش‌فرض‌های متصل به ستون‌های حذفی (به‌صورت صریح، برای اطمینان) --- */
    IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'DF_Attachments_FileGuid')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT DF_Attachments_FileGuid; PRINT N'OK: DF_Attachments_FileGuid حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف DF_Attachments_FileGuid ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END
    IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'DF_Attachments_Status')
    BEGIN
        BEGIN TRY ALTER TABLE dbo.RequestAttachments DROP CONSTRAINT DF_Attachments_Status; PRINT N'OK: DF_Attachments_Status حذف شد.'; END TRY
        BEGIN CATCH PRINT N'FAIL: حذف DF_Attachments_Status ناموفق: ' + ERROR_MESSAGE(); END CATCH
    END

    /* --- ۲-۶) ستون‌های الحاقی v6 (فقط در صورت وجود) — Dynamic SQL برای پرهیز از خطای Bind زمان کامپایل --- */
    DECLARE @Col NVARCHAR(128);
    DECLARE col_cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT N'FileGuid'
        UNION ALL SELECT N'FileContent'
        UNION ALL SELECT N'Sha256'
        UNION ALL SELECT N'Status'
        UNION ALL SELECT N'DisplayName'
        UNION ALL SELECT N'Extension';
    OPEN col_cur;
    FETCH NEXT FROM col_cur INTO @Col;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = @Col)
        BEGIN
            BEGIN TRY
                EXEC (N'ALTER TABLE dbo.RequestAttachments DROP COLUMN ' + @Col + N';');
                PRINT N'OK: ستون ' + @Col + N' حذف شد.';
            END TRY
            BEGIN CATCH
                PRINT N'FAIL: حذف ستون ' + @Col + N' ناموفق (وابستگی/داده): ' + ERROR_MESSAGE();
            END CATCH
        END
        FETCH NEXT FROM col_cur INTO @Col;
    END
    CLOSE col_cur;
    DEALLOCATE col_cur;

    /* یادداشت: پیش‌فرض‌های *_Mig متصل به ستون‌های هسته باقی می‌مانند تا ستون‌های NOT NULL بدون مقدار نمانند؛
       در صورت تمایل به حذف کامل آن‌ها، DBA به‌صورت دستی اقدام کند (فهرست: DF_Attachments_*_Mig). */
END

/* ================== گام ۳: حذف فایل و فایل‌گروپ FILESTREAM (فقط در صورت خالی بودن) ================== */
IF EXISTS (SELECT 1 FROM sys.filegroups WHERE name = @FGName AND type = N'FD')
BEGIN
    DECLARE @FgDataSpaceId INT = (SELECT data_space_id FROM sys.filegroups WHERE name = @FGName);

    IF NOT EXISTS (SELECT 1 FROM sys.allocation_units WHERE data_space_id = @FgDataSpaceId)
       AND NOT EXISTS (SELECT 1 FROM sys.indexes WHERE data_space_id = @FgDataSpaceId)
    BEGIN
        BEGIN TRY
            IF EXISTS (SELECT 1 FROM sys.database_files WHERE name = @FSFile)
            BEGIN
                ALTER DATABASE CURRENT REMOVE FILE AttachmentsFSData;   -- نام منطقی فایل
                PRINT N'OK: فایل کانتینر ' + @FSFile + N' حذف شد.';
            END
            ALTER DATABASE CURRENT REMOVE FILEGROUP AttachmentsFS;
            PRINT N'OK: فایل‌گروپ ' + @FGName + N' حذف شد.';
        END TRY
        BEGIN CATCH
            PRINT N'FAIL: حذف فایل/فایل‌گروپ FILESTREAM ناموفق بود: ' + ERROR_MESSAGE();
            PRINT N'احتمال: آزادسازی فضای FILESTREAM به‌صورت تأخیری انجام می‌شود؛ پس از چند دقیقه (پس از Checkpoint/GC) این اسکریپت را دوباره اجرا کنید.';
        END CATCH
    END
    ELSE
        PRINT N'اطلاع: فایل‌گروپ ' + @FGName + N' خالی نیست (هنوز تخصیصی روی آن وجود دارد) — حذف نشد.';
END
ELSE
    PRINT N'اطلاع: فایل‌گروپ ' + @FGName + N' وجود ندارد — گام حذف فایل‌گروپ رد شد.';

/* ================== خلاصه نهایی ================== */
PRINT N'=== اسکریپت ۹۹ پایان یافت ===';
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NOT NULL
    PRINT N'وضعیت جدول: dbo.RequestAttachments حفظ شد (ساختار هسته موجود است).';
ELSE
    PRINT N'وضعیت جدول: dbo.RequestAttachments حذف شده است.';
PRINT N'یادآوری: برای بازگردانی داده‌های واقعی همیشه از RESTORE نسخه پشتیبان استفاده کنید (هرگز کانتینر FILESTREAM را دستی کپی/حذف نکنید).';