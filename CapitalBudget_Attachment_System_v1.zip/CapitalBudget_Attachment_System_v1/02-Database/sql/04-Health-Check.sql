/* =====================================================================
   اسکریپت ۰۴ — پایش سلامت پیوست‌ها (عملیاتی، فقط‌خواندنی / READ-ONLY)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶
   ---------------------------------------------------------------------
   هدف (پایش دوره‌ای بهره‌بردار):
     * تعداد کل پیوست‌ها و مجموع حجم آن‌ها
     * توزیع بر اساس نوع مالک (OwnerType) و وضعیت (Status)
     * تشخیص ردیف‌های «یتیم» (RequestId/MicroId که دیگر در جدول پایه
       یافت نمی‌شوند — فقط در صورت وجود جدول پایه معنادار است)
     * اندازه منطقی کانتینر FILESTREAM از sys.database_files و
       فضای آزاد ولوم میزبان آن (sys.dm_os_volume_stats)
   ---------------------------------------------------------------------
   نکات ایمنی:
     * فقط‌خواندنی — هیچ تغییری ایجاد نمی‌کند؛ برای اجرای دوره‌ای/زمان‌بندی‌شده مناسب است.
     * قابل اجرای مکرر (Idempotent) است.
     * فرض: اسکریپت ۰۲ با موفقیت اجرا شده و ستون‌های کامل موجودند؛ در
       غیر این صورت پیام‌های «جدول یافت نشد» نمایش داده می‌شود.
   ===================================================================== */
SET NOCOUNT ON;

IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید. ابتدا با USE به پایگاه‌داده هدف متصل شوید.';
    RETURN;
END

DECLARE @Tid INT = OBJECT_ID(N'dbo.RequestAttachments', N'U');

CREATE TABLE #Report
(
    Id      INT IDENTITY(1,1) NOT NULL,
    [Item]  NVARCHAR(150) COLLATE DATABASE_DEFAULT NOT NULL,
    [مقدار] NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL,
    [توضیح] NVARCHAR(600) COLLATE DATABASE_DEFAULT NULL
);

IF @Tid IS NULL
BEGIN
    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'وضعیت', N'جدول dbo.RequestAttachments یافت نشد', N'ابتدا اسکریپت ۰۲ را اجرا کنید؛ سایر گزارش‌های این اسکریپت بی‌معنا هستند.');

    SELECT [Item], [مقدار], [توضیح] FROM #Report ORDER BY Id;
    DROP TABLE #Report;
    RETURN;
END

/* ---------- ۱) شمارش کل و مجموع حجم ---------- */
DECLARE @TotalRows  BIGINT = (SELECT COUNT(*) FROM dbo.RequestAttachments);
DECLARE @TotalBytes BIGINT = (SELECT ISNULL(SUM(CAST(a.SizeBytes AS BIGINT)), 0) FROM dbo.RequestAttachments AS a);
DECLARE @AvgBytes   BIGINT = CASE WHEN @TotalRows > 0 THEN @TotalBytes / @TotalRows ELSE 0 END;
DECLARE @MaxUploaded DATETIME2 = (SELECT MAX(a.UploadedAt) FROM dbo.RequestAttachments AS a);

INSERT INTO #Report ([Item], [مقدار], [توضیح])
VALUES (N'تعداد کل پیوست‌ها', CAST(@TotalRows AS NVARCHAR(20)), N'همه ردیف‌های جدول dbo.RequestAttachments.');

INSERT INTO #Report ([Item], [مقدار], [توضیح])
VALUES (N'مجموع حجم پیوست‌ها', CAST(@TotalBytes AS NVARCHAR(20)) + N' بایت (' + CAST(CAST(@TotalBytes / 1048576.0 AS DECIMAL(12,2)) AS NVARCHAR(20)) + N' مگابایت)',
        N'مجموع ستون SizeBytes؛ سقف مصوب هر فایل ۱,۰۴۸,۵۷۶ بایت است (D-10).');

INSERT INTO #Report ([Item], [مقدار], [توضیح])
VALUES (N'میانگین حجم هر پیوست', CAST(@AvgBytes AS NVARCHAR(20)) + N' بایت',
        N'برای برنامه‌ریزی ظرفیت دیسک و پشتیبان مفید است.');

INSERT INTO #Report ([Item], [مقدار], [توضیح])
VALUES (N'تازه‌ترین بارگذاری', ISNULL(CONVERT(NVARCHAR(25), @MaxUploaded, 120), N'—'),
        N'بیشین مقدار UploadedAt به وقت UTC.');

/* ---------- ۲) ردیف‌های یتیم (مالک مفقود) ---------- */
DECLARE @OrphanReq INT = NULL, @OrphanMicro INT = NULL;

IF OBJECT_ID(N'dbo.Requests', N'U') IS NOT NULL
BEGIN
    SELECT @OrphanReq = COUNT(*)
    FROM dbo.RequestAttachments AS a
    WHERE a.RequestId IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.Requests AS r WHERE r.Id = a.RequestId);

    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'ردیف‌های یتیم (RequestId)', CAST(@OrphanReq AS NVARCHAR(10)),
            CASE WHEN @OrphanReq = 0
                 THEN N'هیچ پیوستی به درخواستِ حذف‌شده وصل نیست.'
                 ELSE N'ردیف‌هایی وجود دارند که RequestId آن‌ها در dbo.Requests یافت نمی‌شود — فهرست در نتیجه‌های زیر؛ نیازمند بررسی DBA.' END);
END
ELSE
    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'ردیف‌های یتیم (RequestId)', N'بررسی نشد', N'جدول dbo.Requests موجود نیست — بررسی یتیم‌ها معنا ندارد.');

IF OBJECT_ID(N'dbo.RequestMicros', N'U') IS NOT NULL
BEGIN
    SELECT @OrphanMicro = COUNT(*)
    FROM dbo.RequestAttachments AS a
    WHERE a.MicroId IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.RequestMicros AS m WHERE m.Id = a.MicroId);

    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'ردیف‌های یتیم (MicroId)', CAST(@OrphanMicro AS NVARCHAR(10)),
            CASE WHEN @OrphanMicro = 0
                 THEN N'هیچ پیوستی به ردیفِ حذف‌شده وصل نیست.'
                 ELSE N'ردیف‌هایی وجود دارند که MicroId آن‌ها در dbo.RequestMicros یافت نمی‌شود — فهرست در نتیجه‌های زیر؛ نیازمند بررسی DBA.' END);
END
ELSE
    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'ردیف‌های یتیم (MicroId)', N'بررسی نشد', N'جدول dbo.RequestMicros موجود نیست — بررسی یتیم‌ها معنا ندارد.');

/* ---------- ۳) کانتینر FILESTREAM ---------- */
IF EXISTS (SELECT 1 FROM sys.database_files WHERE type = 2)
BEGIN
    DECLARE @FsName NVARCHAR(128), @FsPath NVARCHAR(400), @FsSizeMB BIGINT;
    SELECT TOP (1) @FsName = name, @FsPath = physical_name, @FsSizeMB = CAST(size AS BIGINT) * 8 / 1024
    FROM sys.database_files WHERE type = 2;

    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'کانتینر FILESTREAM', @FsName + N' → ' + @FsPath, N'مسیر فیزیکی کانتینر BLOB روی NTFS (D-21).');

    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'اندازه منطقی گزارش‌شده کانتینر', CAST(@FsSizeMB AS NVARCHAR(20)) + N' مگابایت',
            N'برای فایل‌های FILESTREAM معمولاً ۰ گزارش می‌شود (رشد پویا و مدیریت‌شده توسط موتور)؛ اندازه واقعی روی دیسک با dir /s در همان مسیر قابل مشاهده است.');

    IF HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW SERVER STATE') = 1
    BEGIN
        DECLARE @FreeGB DECIMAL(12,1) = (SELECT TOP (1) CAST(vs.available_bytes / 1073741824.0 AS DECIMAL(12,1))
                                         FROM sys.database_files AS df
                                         CROSS APPLY sys.dm_os_volume_stats(DB_ID(), df.file_id) AS vs
                                         WHERE df.type = 2);

        INSERT INTO #Report ([Item], [مقدار], [توضیح])
        VALUES (N'فضای آزاد ولوم میزبان کانتینر', CAST(@FreeGB AS NVARCHAR(20)) + N' گیگابایت',
                CASE WHEN @FreeGB >= 10.0
                     THEN N'فضای آزاد کافی است (آستانه هشدار: زیر ۱۰ گیگابایت).'
                     ELSE N'هشدار: فضای آزاد کم است — طبق Runbook، پاک‌سازی/افزودن دیسک برنامه‌ریزی شود.' END);
    END
    ELSE
        INSERT INTO #Report ([Item], [مقدار], [توضیح])
        VALUES (N'فضای آزاد ولوم کانتینر', N'بررسی نشد', N'مجوز VIEW SERVER STATE وجود ندارد — IT به‌صورت دستی کنترل کند.');
END
ELSE
    INSERT INTO #Report ([Item], [مقدار], [توضیح])
    VALUES (N'کانتینر FILESTREAM', N'یافت نشد', N'فایل نوع FILESTREAM در پایگاه‌داده موجود نیست — اسکریپت ۰۲ اجرا نشده یا ناموفق بوده است.');

/* ---------- خروجی گزارش جمع‌بندی ---------- */
SELECT [Item], [مقدار], [توضیح] FROM #Report ORDER BY Id;

DROP TABLE #Report;

/* ---------- ۴) توزیع بر اساس نوع مالک ---------- */
SELECT
    CASE a.OwnerType WHEN 1 THEN N'درخواست/برنامه (OwnerType=1)'
                     WHEN 2 THEN N'خرده‌ریز/ردیف بودجه (OwnerType=2)'
                     ELSE N'نامعتبر' END                       AS [نوع مالک],
    COUNT(*)                                                   AS [تعداد],
    SUM(CAST(a.SizeBytes AS BIGINT))                           AS [مجموع حجم (بایت)]
FROM dbo.RequestAttachments AS a
GROUP BY a.OwnerType
ORDER BY a.OwnerType;

/* ---------- ۵) توزیع بر اساس وضعیت ---------- */
SELECT
    a.Status      AS [وضعیت],
    COUNT(*)      AS [تعداد],
    SUM(CAST(a.SizeBytes AS BIGINT)) AS [مجموع حجم (بایت)]
FROM dbo.RequestAttachments AS a
GROUP BY a.Status
ORDER BY a.Status;

/* ---------- ۶) فهرست ردیف‌های یتیم (حداکثر ۲۰ مورد از هر نوع) ---------- */
IF @OrphanReq IS NOT NULL AND @OrphanReq > 0
BEGIN
    SELECT TOP (20)
           a.Id           AS [شناسه پیوست],
           a.RequestId    AS [شناسه درخواست مفقود],
           a.OriginalName AS [نام فایل],
           a.UploadedAt   AS [زمان بارگذاری (UTC)]
    FROM dbo.RequestAttachments AS a
    WHERE a.RequestId IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.Requests AS r WHERE r.Id = a.RequestId)
    ORDER BY a.Id;
END

IF @OrphanMicro IS NOT NULL AND @OrphanMicro > 0
BEGIN
    SELECT TOP (20)
           a.Id           AS [شناسه پیوست],
           a.MicroId      AS [شناسه ردیف مفقود],
           a.OriginalName AS [نام فایل],
           a.UploadedAt   AS [زمان بارگذاری (UTC)]
    FROM dbo.RequestAttachments AS a
    WHERE a.MicroId IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.RequestMicros AS m WHERE m.Id = a.MicroId)
    ORDER BY a.Id;
END

PRINT N'=== اسکریپت ۰۴ پایان یافت — فقط‌خواندنی؛ هیچ تغییری اعمال نشد. ===';