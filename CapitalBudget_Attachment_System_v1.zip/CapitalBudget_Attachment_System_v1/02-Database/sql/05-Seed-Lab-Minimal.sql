/* =====================================================================
   اسکریپت ۰۵ — داده نمونه حداقلی «فقط برای محیط آزمایشی» (LAB-ONLY)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶
   ---------------------------------------------------------------------
   ★★★ هشدار مهم ★★★
   * مجاز فقط در محیط آزمایشی (CapitalBudgetManagement_Lab) است؛
     «در محیط عملیاتی (CapitalBudgetDB) اجرا نشود».
   * اجرای این اسکریپت روی پایگاه‌داده عملیاتی توسط اسکریپت مسدود می‌شود
     (بررسی صریح نام پایگاه‌داده در ابتدای فایل).
   * با تصمیم D-12 (قطعی کارفرما): «داده نمونه فقط در محیط آزمایشی
     مجاز است» — بنابراین اجرای این اسکریپت هیچ قاعده‌ای را نقض نمی‌کند؛
     در استقرار عملیاتی، فلگ داده نمونه (DB-13) پیش‌فرض غیرفعال است.
   ---------------------------------------------------------------------
   کاری که انجام می‌دهد:
     ۱) اگر جداول پایه (dbo.Users / dbo.Requests / dbo.RequestMicros)
        موجود نباشند، «داربست حداقلیِ مخصوص آزمایش» آن‌ها را می‌سازد.
     ۲) یک کاربر مدیر آزمایشی (Username = N'admin') با هش واقعی
        PBKDF2-SHA256 و MustChangePassword = 1 درج می‌کند.
     ۳) دو درخواست نمونه (PRG-LAB-001 / PRG-LAB-002) و دو ردیف بودجه
        نمونه برای درخواست اول درج می‌کند.
   ---------------------------------------------------------------------
   تذکر معماری:
     * این داربست جایگزین «برنامه کامل ساخت نسخه ۶» نیست؛ در استقرار
       واقعی، برنامه DB-01…DB-13 (سند ۰۶ — نسخه ۶) ملاک است و این
       جداول حداقلی «فقط» برای تست محلی ماژول پیوست‌ها هستند.
   ---------------------------------------------------------------------
   نکات ایمنی:
     * Idempotent: ساخت جداول و درج داده‌ها همگی با «بررسی وجود» گارد
       شده‌اند؛ اجرای مکرر ردیف تکراری نمی‌سازد.
     * هیچ داده‌ای حذف یا بازنویسی نمی‌شود (فقط INSERT در صورت غیبت).
   ---------------------------------------------------------------------
   اعتبارنامه آزمایشی (فقط Lab — هرگز برای عملیاتی استفاده نشود):
     Username  : admin
     Password  : Lab@1405!
     Hash      : PBKDF2$100000$ausjYSaXqfAK9COhlmtYvA==$tv1kNmLNhW4hZ82O87K4J0CCEUEmmIfB0VkRA8B2NzI=
     الگوریتم  : PBKDF2-HMAC-SHA256 با ۱۰۰,۰۰۰ تکرار، نمک تصادفی ۱۶ بایتی (Base64)، خروجی ۳۲ بایتی (Base64)
     (مطابق تصمیم D-01: ذخیره غیرقابل‌بازیابی + تغییر اجباری رمز در اولین ورود)
   ===================================================================== */
SET NOCOUNT ON;

/* ---------- گارد محیط: اجرای غیرمجاز متوقف می‌شود ---------- */
IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید. ابتدا با USE به پایگاه‌داده آزمایشی متصل شوید.';
    SET NOEXEC ON;  /* دسته‌های بعدی نیز اجرا نخواهند شد */
    RETURN;
END
IF DB_NAME() = N'CapitalBudgetDB'
BEGIN
    PRINT N'FAIL: این اسکریپت فقط برای محیط آزمایشی است و روی پایگاه‌داده عملیاتی (CapitalBudgetDB) اجرا نمی‌شود — اجرا متوقف شد (D-12).';
    SET NOEXEC ON;  /* دسته‌های بعدی نیز اجرا نخواهند شد */
    RETURN;
END

PRINT N'=== اسکریپت ۰۵: داده نمونه حداقلی آزمایشی — شروع ===';
PRINT N'پایگاه‌داده جاری: ' + DB_NAME() + N' (فقط LAB-)';
GO

/* ================== گام ۱: داربست حداقلی (فقط اگر جدول موجود نباشد) ================== */
/* در استقرار واقعی، برنامه کامل DB-01…DB-13 (سند ۰۶ نسخه ۶) جایگزین این داربست است. */

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users
    (
        Id                 BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users_Lab PRIMARY KEY,
        Username           NVARCHAR(100) NOT NULL CONSTRAINT UX_Users_Lab_Username UNIQUE,
        PasswordHash       NVARCHAR(200) NOT NULL,                     -- قالب: PBKDF2$<iter>$<salt base64>$<hash base64>
        IsActive           BIT           NOT NULL CONSTRAINT DF_Users_Lab_IsActive DEFAULT (1),
        MustChangePassword BIT           NOT NULL CONSTRAINT DF_Users_Lab_MustChangePassword DEFAULT (1),
        FirstName          NVARCHAR(100) NULL,
        LastName           NVARCHAR(100) NULL
    );
    PRINT N'OK: داربست حداقلی dbo.Users ساخته شد (فقط آزمایشی — برنامه واقعی: DB-04).';
END
ELSE
    PRINT N'اطلاع: dbo.Users از قبل موجود است — ساخت داربست رد شد (جدول واقعی حفظ می‌شود).';

IF OBJECT_ID(N'dbo.Requests', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Requests
    (
        Id              BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Requests_Lab PRIMARY KEY,
        Code            NVARCHAR(50)  NOT NULL CONSTRAINT UX_Requests_Lab_Code UNIQUE,
        Title           NVARCHAR(500) NULL,
        BudKind         NVARCHAR(20)  NULL,          -- capital | current (مطابق کد مرجع)
        Status          NVARCHAR(20)  NULL,          -- در استقرار واقعی: FK به RequestStatuses با ۹ وضعیت
        ApplicantId     BIGINT        NULL CONSTRAINT FK_Requests_Lab_Applicant REFERENCES dbo.Users (Id),
        CommitterId     BIGINT        NULL,
        SeniorManagerId BIGINT        NULL,
        ManagementId    BIGINT        NULL,
        UnitId          BIGINT        NULL,
        CreatedById     BIGINT        NULL
    );
    PRINT N'OK: داربست حداقلی dbo.Requests ساخته شد (فقط آزمایشی — برنامه واقعی: DB-05).';
END
ELSE
    PRINT N'اطلاع: dbo.Requests از قبل موجود است — ساخت داربست رد شد.';

IF OBJECT_ID(N'dbo.RequestMicros', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.RequestMicros
    (
        Id        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_RequestMicros_Lab PRIMARY KEY,
        RequestId BIGINT        NOT NULL CONSTRAINT FK_RequestMicros_Lab_Request REFERENCES dbo.Requests (Id),
        SeqNo     INT           NOT NULL,
        Title     NVARCHAR(500) NULL,
        CONSTRAINT UX_RequestMicros_Lab_ReqSeq UNIQUE (RequestId, SeqNo)
    );
    PRINT N'OK: داربست حداقلی dbo.RequestMicros ساخته شد (فقط آزمایشی — برنامه واقعی: DB-06).';
END
ELSE
    PRINT N'اطلاع: dbo.RequestMicros از قبل موجود است — ساخت داربست رد شد.';

IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
    PRINT N'هشدار: جدول dbo.RequestAttachments هنوز ساخته نشده است — برای تست کامل ماژول پیوست‌ها ابتدا اسکریپت ۰۲ را اجرا کنید.';
GO

/* ================== گام ۲: درج کاربر مدیر آزمایشی ================== */
BEGIN TRY
    IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'admin')
    BEGIN
        INSERT dbo.Users (Username, PasswordHash, IsActive, MustChangePassword, FirstName, LastName)
        VALUES (N'admin',
                N'PBKDF2$100000$ausjYSaXqfAK9COhlmtYvA==$tv1kNmLNhW4hZ82O87K4J0CCEUEmmIfB0VkRA8B2NzI=',
                1, 1, N'مدیر آزمایشی', N'کاربر نمونه اسکریپت ۰۵');
        PRINT N'OK: کاربر آزمایشی N''admin'' ایجاد شد (رمز آزمایشی Lab@1405! — MustChangePassword=1).';
    END
    ELSE
        PRINT N'اطلاع: کاربر N''admin'' از قبل موجود بود — درج تکراری انجام نشد (Idempotent).';
END TRY
BEGIN CATCH
    PRINT N'FAIL: درج کاربر آزمایشی ناموفق بود: ' + ERROR_MESSAGE();
    PRINT N'احتمال: جدول dbo.Users واقعی (برنامه DB-04) ستون‌های متفاوتی دارد — درج دستی با هماهنگی DBA انجام شود.';
END CATCH
GO

/* ================== گام ۳: درج درخواست‌ها و ردیف‌های نمونه ================== */
DECLARE @AdminId BIGINT = (SELECT MIN(Id) FROM dbo.Users WHERE Username = N'admin');
DECLARE @Req1 BIGINT, @Req2 BIGINT;

IF @AdminId IS NULL
    PRINT N'FAIL: کاربر N''admin'' یافت نشد — درج درخواست‌های نمونه رد شد.';
ELSE
BEGIN
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.Requests WHERE Code = N'PRG-LAB-001')
        BEGIN
            INSERT dbo.Requests (Code, Title, BudKind, Status, ApplicantId)
            VALUES (N'PRG-LAB-001', N'درخواست آزمایشی ۱ — بازسازی ساختمان اداری (نمونه)', N'capital', N'draft', @AdminId);
            PRINT N'OK: درخواست نمونه PRG-LAB-001 ایجاد شد.';
        END
        ELSE
            PRINT N'اطلاع: درخواست PRG-LAB-001 از قبل موجود بود.';

        IF NOT EXISTS (SELECT 1 FROM dbo.Requests WHERE Code = N'PRG-LAB-002')
        BEGIN
            INSERT dbo.Requests (Code, Title, BudKind, Status, ApplicantId)
            VALUES (N'PRG-LAB-002', N'درخواست آزمایشی ۲ — تجهیز زیرساخت IT (نمونه)', N'capital', N'draft', @AdminId);
            PRINT N'OK: درخواست نمونه PRG-LAB-002 ایجاد شد.';
        END
        ELSE
            PRINT N'اطلاع: درخواست PRG-LAB-002 از قبل موجود بود.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: درج درخواست‌های نمونه ناموفق بود: ' + ERROR_MESSAGE();
    END CATCH

    SELECT @Req1 = MIN(Id) FROM dbo.Requests WHERE Code = N'PRG-LAB-001';
    SELECT @Req2 = MIN(Id) FROM dbo.Requests WHERE Code = N'PRG-LAB-002';
END

/* ردیف‌های بودجه نمونه — فقط برای درخواست اول (شناسه هر دو با SeqNo یکتا کنترل می‌شود) */
IF @Req1 IS NULL
    PRINT N'اطلاع: درخواست اول یافت نشد — درج ردیف‌های نمونه رد شد.';
ELSE
BEGIN
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.RequestMicros WHERE RequestId = @Req1 AND SeqNo = 1)
        BEGIN
            INSERT dbo.RequestMicros (RequestId, SeqNo, Title)
            VALUES (@Req1, 1, N'ردیف بودجه نمونه ۱ — تجهیزات و ابزار');
            PRINT N'OK: ردیف نمونه ۱ برای درخواست اول ایجاد شد.';
        END
        ELSE
            PRINT N'اطلاع: ردیف نمونه ۱ از قبل موجود بود.';

        IF NOT EXISTS (SELECT 1 FROM dbo.RequestMicros WHERE RequestId = @Req1 AND SeqNo = 2)
        BEGIN
            INSERT dbo.RequestMicros (RequestId, SeqNo, Title)
            VALUES (@Req1, 2, N'ردیف بودجه نمونه ۲ — اجرا و نصب');
            PRINT N'OK: ردیف نمونه ۲ برای درخواست اول ایجاد شد.';
        END
        ELSE
            PRINT N'اطلاع: ردیف نمونه ۲ از قبل موجود بود.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: درج ردیف‌های نمونه ناموفق بود: ' + ERROR_MESSAGE();
    END CATCH
END
GO

/* ================== گام ۴: گزارش خلاصه ================== */
SELECT
    (SELECT COUNT(*) FROM dbo.Users)         AS [تعداد کاربران],
    (SELECT COUNT(*) FROM dbo.Requests)      AS [تعداد درخواست‌ها],
    (SELECT COUNT(*) FROM dbo.RequestMicros) AS [تعداد ردیف‌های بودجه];

SELECT Id, Username, IsActive, MustChangePassword, FirstName, LastName
FROM dbo.Users WHERE Username = N'admin';

SELECT Id, Code, Title, BudKind, Status, ApplicantId
FROM dbo.Requests WHERE Code IN (N'PRG-LAB-001', N'PRG-LAB-002') ORDER BY Id;

PRINT N'=== اسکریپت ۰۵ پایان یافت (فقط LAB) — گام بعدی: اجرای سرویس/API روی این پایگاه‌داده آزمایشی ===';

/* =====================================================================
   پیوست — نمونه (غیرفعال) درج یک پیوست واقعی برای تست دستی:
   ---------------------------------------------------------------------
   توجه: در مثال زیر، Sha256 واقعی محتوای 0x53616D706C652074657874
   («Sample text») برابر است با:
   3a2c5c49db9a35faeca3e211610a07ba996b6a8ef74aee251392c95a5557d95b
   FileGuid/UploadedAt/Status به‌صورت خودکار از پیش‌فرض‌ها پر می‌شوند.
   ---------------------------------------------------------------------
   DECLARE @ReqId BIGINT = (SELECT MIN(Id) FROM dbo.Requests WHERE Code = N'PRG-LAB-001');
   DECLARE @Admin BIGINT = (SELECT MIN(Id) FROM dbo.Users  WHERE Username = N'admin');

   INSERT dbo.RequestAttachments
       (OwnerType, OwnerId, RequestId, OriginalName, DisplayName, Extension,
        ContentType, SizeBytes, Sha256, Status, UploadedById, FileContent)
   VALUES
       (1, @ReqId, @ReqId, N'sample.txt', N'فایل نمونه', N'.txt',
        N'text/plain', 11, N'3a2c5c49db9a35faeca3e211610a07ba996b6a8ef74aee251392c95a5557d95b',
        N'active', @Admin, 0x53616D706C652074657874);
   ===================================================================== */