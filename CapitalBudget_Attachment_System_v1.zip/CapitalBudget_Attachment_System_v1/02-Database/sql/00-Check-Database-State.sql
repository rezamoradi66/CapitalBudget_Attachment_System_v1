/* =====================================================================
   اسکریپت ۰۰ — بررسی وضعیت پایگاه‌داده (فقط‌خواندنی / READ-ONLY)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها (Attachment Management) — سند طراحی ۰۳ نسخه ۶
   ---------------------------------------------------------------------
   هدف:
     ارزیابی وضعیت فعلی پایگاه‌داده جاری «پیش از هرگونه تغییر»؛ شامل:
     نام پایگاه‌داده، سطح سازگاری (Compatibility Level)، Collation، مدل
     بازیابی، حجم، وجود فایل‌گروپ FILESTREAM، وضعیت اشیای مرتبط
     (RequestAttachments / Users / Requests / RequestMicros)، تعداد
     ردیف‌های آن‌ها (در صورت وجود)، زمان آخرین پشتیبان کامل/تفاضلی/لاگ
     (با کنترل مجوز msdb) و نسخه/ویرایش SQL Server.
   ---------------------------------------------------------------------
   نکات ایمنی:
     * این اسکریپت «فقط‌خواندنی» است و هیچ شیء، داده یا تنظیمی را
       تغییر نمی‌دهد (فقط SELECT/PRINT).
     * قابل اجرای مکرر (Idempotent) و کاملاً قابل ممیزی (Auditable) است.
     * در پایگاه‌داده هدف اجرا شود (آزمایشی: CapitalBudgetManagement_Lab).
     * در پایگاه‌داده‌های سیستمی (master/model/msdb/tempdb) متوقف می‌شود.
   ---------------------------------------------------------------------
   نگاشت ستون Status (شکل فارسی‌پسند):
     OK            = سالم / مطابق انتظار
     هشدار (WARN)  = نیازمند توجه؛ مانع ادامه کار نیست
     اطلاع (INFO)  = صرفاً جهت اطلاع‌رسانی
   ===================================================================== */
SET NOCOUNT ON;

DECLARE @DbName   NVARCHAR(128) = DB_NAME();
DECLARE @LastFull DATETIME, @LastDiff DATETIME, @LastLog DATETIME;

/* گارد: جلوگیری از اجرای اشتباه روی پایگاه‌داده‌های سیستمی */
IF @DbName IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در حال حاضر در یک پایگاه‌داده سیستمی هستید. ابتدا با دستور USE به پایگاه‌داده هدف (مثلاً CapitalBudgetManagement_Lab) متصل شوید.';
    RETURN;
END

CREATE TABLE #Report
(
    Id       INT IDENTITY(1,1) NOT NULL,
    [Item]   NVARCHAR(150) COLLATE DATABASE_DEFAULT NOT NULL,
    [مقدار]  NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL,
    [Status] NVARCHAR(30)  COLLATE DATABASE_DEFAULT NOT NULL,
    [توضیح]  NVARCHAR(600) COLLATE DATABASE_DEFAULT NULL
);

/* ---------- ۱) نام پایگاه‌داده و سرور ---------- */
INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'پایگاه‌داده جاری', @DbName, N'OK',
        N'نام پایگاه‌داده‌ای که اسکریپت در آن اجرا شده است؛ باید CapitalBudgetManagement_Lab (آزمایشی) باشد.');

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
SELECT N'سرور (Instance)', @@SERVERNAME, N'اطلاع (INFO)', N'نام نمونه SQL Server میزبان.';

/* ---------- ۲) نسخه و ویرایش SQL Server ---------- */
DECLARE @Version NVARCHAR(200) = CONVERT(NVARCHAR(128), SERVERPROPERTY('ProductVersion'))
                               + N' (' + CONVERT(NVARCHAR(128), SERVERPROPERTY('ProductLevel')) + N')';
DECLARE @Edition NVARCHAR(128) = CONVERT(NVARCHAR(128), SERVERPROPERTY('Edition'));

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'نسخه SQL Server', @Version, N'اطلاع (INFO)',
        N'طراحی بر مبنای SQL Server 2022 انجام شده است؛ نسخه‌های پایین‌تر ممکن است برخی قابلیت‌ها (مثل STRING_AGG) را نداشته باشند.');

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
SELECT N'ویرایش (Edition)', @Edition,
       CASE WHEN @Edition LIKE N'%Standard%' THEN N'OK' ELSE N'هشدار (WARN)' END,
       CASE WHEN @Edition LIKE N'%Standard%'
            THEN N'ویرایش استاندارد مطابق پیش‌نیاز طراحی است؛ FILESTREAM در این ویرایش پشتیبانی می‌شود.'
            ELSE N'ویرایش به‌جز استاندارد است — سازگاری را پیش از ادامه با تیم طراحی/IT بررسی کنید.' END;

/* ---------- ۳) سطح سازگاری پایگاه‌داده ---------- */
DECLARE @Compat INT = (SELECT compatibility_level FROM sys.databases WHERE database_id = DB_ID());

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'سطح سازگاری (Compatibility Level)', CAST(@Compat AS NVARCHAR(10)),
        CASE WHEN @Compat >= 100 THEN N'OK' ELSE N'هشدار (WARN)' END,
        CASE WHEN @Compat >= 100
             THEN N'برای FILESTREAM محدودیت سطح سازگاری وجود ندارد؛ طراحی بر مبنای قابلیت‌های SQL Server 2022 (سطح ۱۶۰) است.'
             ELSE N'سطح سازگاری بسیار پایین است — بازبینی شود.' END);

/* ---------- ۴) Collation ---------- */
DECLARE @Collation NVARCHAR(128) = CONVERT(NVARCHAR(128), DATABASEPROPERTYEX(@DbName, 'Collation'));

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'Collation پایگاه‌داده', @Collation, N'اطلاع (INFO)',
        N'ستون‌های متنی از نوع NVARCHAR هستند و پشتیبانی فارسی مستقل از Collation تضمین می‌شود؛ طبق برنامه ساخت (DB-01) برای ستون‌های متنی فارسی Persian_100_CI_AI در نظر گرفته شده است. یکسان بودن Collation بین محیط آزمایشی و عملیاتی مهم است.');

/* ---------- ۵) مدل بازیابی ---------- */
DECLARE @Recovery NVARCHAR(128) = CONVERT(NVARCHAR(128), DATABASEPROPERTYEX(@DbName, 'Recovery'));

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
SELECT N'مدل بازیابی (Recovery Model)', @Recovery,
       CASE WHEN @Recovery = N'FULL' THEN N'OK' ELSE N'هشدار (WARN)' END,
       CASE WHEN @Recovery = N'FULL'
            THEN N'امکان پشتیبان‌گیری لاگ و بازیابی نقطه‌زمانی فراهم است (برای داده‌های پیوست توصیه می‌شود).'
            ELSE N'برای بازیابی نقطه‌زمانی، مدل FULL توصیه می‌شود؛ در مدل SIMPLE فقط بازیابی تا آخرین پشتیبان کامل/تفاضلی ممکن است.' END;

/* ---------- ۶) حجم کل پایگاه‌داده ---------- */
DECLARE @SizeMB BIGINT = (SELECT ISNULL(SUM(CAST(df.size AS BIGINT)) * 8 / 1024, 0)
                          FROM sys.database_files AS df);

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'حجم منطقی کل پایگاه‌داده', CAST(@SizeMB AS NVARCHAR(20)) + N' مگابایت', N'اطلاع (INFO)',
        N'مجموع اندازه منطقی فایل‌های داده و لاگ (اندازه واقعی کانتینر FILESTREAM در اسکریپت ۰۴ بررسی می‌شود).');

/* ---------- ۷) فایل‌گروپ‌های FILESTREAM موجود ---------- */
DECLARE @FgCount INT = (SELECT COUNT(*) FROM sys.filegroups WHERE type = N'FD');
DECLARE @FgNames NVARCHAR(400) = (SELECT STRING_AGG(name, N', ') FROM sys.filegroups WHERE type = N'FD');

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
SELECT N'فایل‌گروپ FILESTREAM',
       CASE WHEN @FgCount > 0 THEN @FgNames ELSE N'موجود نیست' END,
       CASE WHEN @FgCount > 0 THEN N'OK' ELSE N'هشدار (WARN)' END,
       CASE WHEN @FgCount > 0
            THEN N'فایل‌گروپ(های) FILESTREAM برای ذخیره‌سازی پیوست‌ها موجود است.'
            ELSE N'هنوز فایل‌گروپ FILESTREAM ساخته نشده — اسکریپت ۰۲ آن را ایجاد می‌کند (پیش‌نیاز: فعال‌سازی FILESTREAM در سطح نمونه — اسکریپت ۰۱).' END;

/* ---------- ۸) سطح مؤثر FILESTREAM در نمونه (خلاصه — جزئیات در اسکریپت ۰۱) ---------- */
DECLARE @FsLevel INT = CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT);

INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
VALUES (N'سطح مؤثر FILESTREAM در نمونه', CAST(@FsLevel AS NVARCHAR(10)),
        CASE WHEN @FsLevel > 0 THEN N'OK' ELSE N'هشدار (WARN)' END,
        CASE WHEN @FsLevel > 0
             THEN N'FILESTREAM در سطح نمونه فعال است (۰=غیرفعال، ۱=فقط T-SQL، ۲=کامل T-SQL و Win32) — جزئیات کامل در اسکریپت ۰۱.'
             ELSE N'FILESTREAM در سطح نمونه غیرفعال است؛ پیش از اجرای اسکریپت ۰۲ باید فعال شود (راهنمای گام‌به‌گام در اسکریپت ۰۱).' END);

/* ---------- ۹) وضعیت اشیای مرتبط + تعداد ردیف‌ها ---------- */
/* RequestAttachments */
IF OBJECT_ID(N'dbo.RequestAttachments') IS NOT NULL
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    SELECT N'شیء dbo.RequestAttachments',
           CASE WHEN OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NOT NULL
                THEN N'موجود (جدول) — تعداد ردیف‌ها: ' + CAST(ISNULL((SELECT SUM(CAST(p.rows AS BIGINT))
                        FROM sys.partitions AS p
                        WHERE p.object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND p.index_id IN (0, 1)), 0) AS NVARCHAR(20))
                ELSE N'موجود اما از نوع غیر جدول!' END,
           CASE WHEN OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NOT NULL THEN N'اطلاع (INFO)' ELSE N'هشدار (WARN)' END,
           N'جدول اصلی پیوست‌ها. اگر ساختار کامل نباشد، اسکریپت ۰۲ فقط ستون‌های غایب را اضافه می‌کند.';
ELSE
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'شیء dbo.RequestAttachments', N'غایب', N'اطلاع (INFO)',
            N'جدول پیوست‌ها هنوز ساخته نشده — اسکریپت ۰۲ آن را ایجاد می‌کند.');

/* Users */
IF OBJECT_ID(N'dbo.Users') IS NOT NULL
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    SELECT N'شیء dbo.Users',
           CASE WHEN OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL
                THEN N'موجود (جدول) — تعداد ردیف‌ها: ' + CAST(ISNULL((SELECT SUM(CAST(p.rows AS BIGINT))
                        FROM sys.partitions AS p
                        WHERE p.object_id = OBJECT_ID(N'dbo.Users', N'U') AND p.index_id IN (0, 1)), 0) AS NVARCHAR(20))
                ELSE N'موجود اما از نوع غیر جدول!' END,
           N'اطلاع (INFO)',
           N'جدول کاربران (مبنای FK_Attachments_UploadedBy).';
ELSE
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'شیء dbo.Users', N'غایب', N'اطلاع (INFO)',
            N'جدول کاربران موجود نیست؛ در محیط آزمایشی، اسکریپت ۰۵ داربست حداقلی آن را می‌سازد (FK پیوست‌ها فقط در صورت وجود ساخته می‌شود).');

/* Requests */
IF OBJECT_ID(N'dbo.Requests') IS NOT NULL
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    SELECT N'شیء dbo.Requests',
           CASE WHEN OBJECT_ID(N'dbo.Requests', N'U') IS NOT NULL
                THEN N'موجود (جدول) — تعداد ردیف‌ها: ' + CAST(ISNULL((SELECT SUM(CAST(p.rows AS BIGINT))
                        FROM sys.partitions AS p
                        WHERE p.object_id = OBJECT_ID(N'dbo.Requests', N'U') AND p.index_id IN (0, 1)), 0) AS NVARCHAR(20))
                ELSE N'موجود اما از نوع غیر جدول!' END,
           N'اطلاع (INFO)',
           N'جدول درخواست‌ها/برنامه‌ها (مبنای FK_Attachments_Request).';
ELSE
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'شیء dbo.Requests', N'غایب', N'اطلاع (INFO)',
            N'جدول درخواست‌ها موجود نیست؛ در محیط آزمایشی، اسکریپت ۰۵ داربست حداقلی آن را می‌سازد.');

/* RequestMicros */
IF OBJECT_ID(N'dbo.RequestMicros') IS NOT NULL
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    SELECT N'شیء dbo.RequestMicros',
           CASE WHEN OBJECT_ID(N'dbo.RequestMicros', N'U') IS NOT NULL
                THEN N'موجود (جدول) — تعداد ردیف‌ها: ' + CAST(ISNULL((SELECT SUM(CAST(p.rows AS BIGINT))
                        FROM sys.partitions AS p
                        WHERE p.object_id = OBJECT_ID(N'dbo.RequestMicros', N'U') AND p.index_id IN (0, 1)), 0) AS NVARCHAR(20))
                ELSE N'موجود اما از نوع غیر جدول!' END,
           N'اطلاع (INFO)',
           N'جدول ردیف‌های (خرده‌ریزهای) بودجه (مبنای FK_Attachments_Micro).';
ELSE
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'شیء dbo.RequestMicros', N'غایب', N'اطلاع (INFO)',
            N'جدول ردیف‌های بودجه موجود نیست؛ در محیط آزمایشی، اسکریپت ۰۵ داربست حداقلی آن را می‌سازد.');

/* ---------- ۱۰) آخرین پشتیبان‌ها (با کنترل مجوز msdb) ---------- */
IF HAS_PERMS_BY_NAME(N'msdb.dbo.backupset', N'OBJECT', N'SELECT') = 1
BEGIN
    SELECT @LastFull = MAX(CASE WHEN bs.type = N'D' THEN bs.backup_finish_date END),
           @LastDiff = MAX(CASE WHEN bs.type = N'I' THEN bs.backup_finish_date END),
           @LastLog  = MAX(CASE WHEN bs.type = N'L' THEN bs.backup_finish_date END)
    FROM msdb.dbo.backupset AS bs
    WHERE bs.database_name = @DbName;

    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'آخرین پشتیبان کامل (Full)',
            ISNULL(CONVERT(NVARCHAR(20), @LastFull, 120), N'هیچ‌وقت'),
            CASE WHEN @LastFull IS NULL THEN N'هشدار (WARN)' ELSE N'OK' END,
            N'پشتیبان کامل شامل داده‌های FILESTREAM نیز هست؛ پیش از اجرای اسکریپت ۰۲ یک پشتیبان کامل گرفته شود.');

    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'آخرین پشتیبان تفاضلی (Differential)',
            ISNULL(CONVERT(NVARCHAR(20), @LastDiff, 120), N'هیچ‌وقت'),
            N'اطلاع (INFO)',
            N'اختیاری — تفاضلی نیز داده‌های FILESTREAM را پوشش می‌دهد.');

    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'آخرین پشتیبان لاگ (Log)',
            ISNULL(CONVERT(NVARCHAR(20), @LastLog, 120), N'هیچ‌وقت'),
            CASE WHEN @LastFull IS NOT NULL AND @LastLog IS NULL THEN N'هشدار (WARN)' ELSE N'اطلاع (INFO)' END,
            N'در مدل بازیابی FULL، زنجیره پشتیبان لاگ برای بازیابی نقطه‌زمانی ضروری است.');
END
ELSE
    INSERT INTO #Report ([Item], [مقدار], [Status], [توضیح])
    VALUES (N'آخرین پشتیبان‌ها', N'بررسی نشد', N'اطلاع (INFO)',
            N'دسترسی SELECT روی msdb.dbo.backupset وجود ندارد — زمان آخرین پشتیبان‌ها باید توسط DBA به‌صورت دستی کنترل شود.');

/* ---------- نتیجه نهایی ---------- */
SELECT [Item], [مقدار], [Status], [توضیح] FROM #Report ORDER BY Id;

DROP TABLE #Report;

PRINT N'=== اسکریپت ۰۰ پایان یافت — فقط‌خواندنی؛ هیچ تغییری اعمال نشد. ===';
PRINT N'گام بعدی: اجرای 01-Check-Filestream-Prerequisites.sql';
GO