#!/usr/bin/env node
/* ================================================================
   test_adapter.js — آزمون‌های دودی آداپتور پیوست‌ها (تسک A5)
   ----------------------------------------------------------------
   محیط: Node بدون مرورگر — سراسری‌های ساختگی (window، toast، fetch،
   document، URL) فراهم می‌شود و سورس آداپتور از فایل
   cbm-attachments-adapter.js خوانده و در همین کانتکست اجرا می‌شود.

   آزمون‌ها:
     T1 — حالت غیرفعال: عملیات‌ها بی‌اثر و مقادیر امن (بدون fetch)
     T2 — شناسه‌یابی مالک: ساخت نشانی صحیح + کدگذاری URI کد فارسی
          + نگاشت مستند m.id ↔ SeqNo برای ریزتقاضا
     T3 — جریان دانلود: fetch → blob → createObjectURL → click
     T4 — حذف: false روی 500، true روی 200
     T5 — stripRemoteData: صفر کردن data فقط برای remote/pendingRemote
          و حفظ بقیه + دست‌نخوردگی db اصلی

   خروجی: برچسب فارسی PASS/FAIL برای هر آزمون؛ کد بازگشت ۰ فقط اگر
   همه PASS باشند.
   ================================================================ */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ADAPTER_PATH = path.join(__dirname, 'cbm-attachments-adapter.js');
const SRC = fs.readFileSync(ADAPTER_PATH, 'utf8');

/* ---------- ابزارهای آزمون ---------- */
const results = [];
let failures = 0;

function check(name, cond, detail) {
  if (!cond) throw new Error(detail || 'ادعای آزمون برقرار نشد');
}
function record(tid, label, fn) {
  const toasts = [];
  const prevToast = global.toast;
  global.toast = function (msg, type) { toasts.push({ msg: String(msg), type: String(type || '') }); };
  const done = (ok, e) => {
    global.toast = prevToast;
    if (ok) {
      results.push({ tid, label, ok: true, toasts: toasts.length });
      console.log('PASS  %s — %s', tid, label);
    } else {
      failures++;
      results.push({ tid, label, ok: false });
      console.error('FAIL  %s — %s | خطا: %s', tid, label, (e && e.message) || e);
    }
  };
  try {
    const r = fn(toasts);
    if (r && typeof r.then === 'function') return r.then(() => done(true), (e) => done(false, e));
    done(true);
    return Promise.resolve();
  } catch (e) {
    done(false, e);
    return Promise.resolve();
  }
}

/* بارگذاری نمونه تازه آداپتور با پیکربندی داده‌شده */
function loadAdapter(config) {
  global.CBM_API_CONFIG = config;
  global.CBM_ATT = undefined;
  vm.runInThisContext(SRC, { filename: 'cbm-attachments-adapter.js' });
  const A = global.CBM_ATT;
  if (!A || typeof A.stripRemoteData !== 'function') throw new Error('آداپتور بارگذاری نشد');
  return A;
}

/* پاسخ ساختگی JSON */
function jsonRes(obj, status) {
  const ok = (status || 200) < 400;
  return {
    ok, status: status || 200,
    headers: { get: (h) => (String(h).toLowerCase() === 'content-type' ? 'application/json' : '') },
    json: async () => obj
  };
}

/* ================= T1 — حالت غیرفعال ================= */
function t1() {
  const A = loadAdapter({ enabled: false, baseUrl: '/api' });
  const fetchCalls = [];
  global.fetch = async (url, init) => { fetchCalls.push({ url, init }); return jsonRes({}); };

  check('enabled === false', A.enabled === false);
  const dbObj = { programs: [{ code: 'X', atts: [{ id: 'a', remote: true, data: 'data:text/plain,zz' }] }] };
  check('stripRemoteData در حالت غیرفعال خود db را برمی‌گرداند (بدون کپی)', A.stripRemoteData(dbObj) === dbObj);
  check('trackPending در حالت غیرفعال false می‌دهد', A.trackPending({ id: 'x1' }, { name: 'f.pdf' }) === false);
  check('pending خالی ماند', A.pending.size === 0);
  return Promise.resolve(A.tryUploadNow({ code: 'X', atts: [] })).then((n) => {
    check('tryUploadNow بدون فراخوانی شبکه 0 می‌دهد', n === 0 && fetchCalls.length === 0,
      'n=' + n + ' fetchCalls=' + fetchCalls.length);
    check('isRemote خالص است و مستقل از enabled کار می‌کند', A.isRemote({ remote: true }) === true);
  });
}

/* ================= T2 — شناسه‌یابی مالک ================= */
function t2() {
  const A = loadAdapter({ enabled: true, baseUrl: '/api' });
  const urls = [];
  global.fetch = async (url, init) => { urls.push({ url, init }); return jsonRes({ id: 'SRV-111', micros: [{ id: 77, seqNo: 'R-0001' }] }); };

  global.db = { programs: [{ code: 'برنامه-۱', micros: [{ id: 'R-0001', atts: [] }] }] };

  const enc = encodeURIComponent('برنامه-۱');
  const wantUrl = '/api/v1/requests/by-code/' + enc;
  check('کدگذاری URI کد فارسی درست است', enc === '%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87-%DB%B1', enc);

  return Promise.resolve()
    .then(() => A.resolveOwner('request', { code: 'برنامه-۱' }))
    .then((r1) => {
      check('resolveOwner(request) موفق', r1 && r1.ok === true, JSON.stringify(r1));
      check('نشانی by-code دقیقاً درست است', urls[0] && urls[0].url === wantUrl,
        'got=' + (urls[0] && urls[0].url));
      check('credentials=same-origin', urls[0] && urls[0].init && urls[0].init.credentials === 'same-origin');
      check('ownerCache پر شد', A.ownerCache.get('برنامه-۱') && A.ownerCache.get('برنامه-۱').requestId === 'SRV-111');
      /* فراخوانی دوم نباید fetch جدید بزند (کش) */
      return A.resolveOwner('request', { code: 'برنامه-۱' }).then(() => {
        check('کش مالک: fetch دوم انجام نشد', urls.length === 1, 'urls=' + urls.length);
      });
    })
    .then(() => A.resolveOwner('micro', global.db.programs[0].micros[0]))
    .then((r2) => {
      check('resolveOwner(micro) موفق', r2 && r2.ok === true, JSON.stringify(r2));
      check('نگاشت m.id ↔ SeqNo صحیح (microId=77)', r2 && r2.microId === '77' && r2.requestId === 'SRV-111',
        JSON.stringify(r2));
      check('برای micro از کش استفاده شد (بدون fetch تازه)', urls.length === 1, 'urls=' + urls.length);
    })
    .then(() => A.resolveOwner('request', { code: null }))
    .then((r3) => {
      check('پیش‌نویس بی‌کد → ok:false بدون شبکه', r3 && r3.ok === false && urls.length === 1, JSON.stringify(r3));
    });
}

/* ================= T3 — جریان دانلود ================= */
function t3() {
  const A = loadAdapter({ enabled: true, baseUrl: '/api' });
  const urls = [];
  global.fetch = async (url, init) => {
    urls.push({ url, init });
    return {
      ok: true, status: 200,
      headers: { get: () => 'application/octet-stream' },
      blob: async () => ({ size: 11 })
    };
  };
  const created = [], revoked = [];
  const savedCreate = URL.createObjectURL, savedRevoke = URL.revokeObjectURL;
  URL.createObjectURL = function (blob) { created.push(blob); return 'blob:mock-1'; };
  URL.revokeObjectURL = function (u) { revoked.push(u); };
  const savedDoc = global.document;
  global.document = { body: { appendChild() {} }, documentElement: {} };
  const savedST = global.setTimeout;
  const deferred = [];
  global.setTimeout = function (fn, ms) { deferred.push(fn); return 0; };

  const lnk = { href: '', download: '', clicks: 0, removed: 0, click() { this.clicks++; }, remove() { this.removed++; } };
  const a = { id: 'att-9', serverId: 'SRV-77', name: 'گزارش.pdf' };

  return A.download(a, lnk).then((okRes) => {
    try {
      check('download(true)', okRes === true);
      check('نشانی دانلود درست است', urls[0] && urls[0].url === '/api/v1/attachments/SRV-77', urls[0] && urls[0].url);
      check('credentials=same-origin', urls[0] && urls[0].init.credentials === 'same-origin');
      check('createObjectURL دقیقاً یک‌بار با blob صدا زده شد', created.length === 1);
      check('lnk.href = objectURL', lnk.href === 'blob:mock-1', lnk.href);
      check('lnk.download = نام فایل', lnk.download === 'گزارش.pdf', lnk.download);
      check('click پس از تنظیم href انجام شد', lnk.clicks === 1 && lnk.removed === 1);
      /* پاک‌سازی مؤجل (revokeObjectURL) */
      deferred.forEach((fn) => { try { fn(); } catch (e) {} });
      check('revokeObjectURL روی همان نشانی صدا زده شد', revoked.indexOf('blob:mock-1') !== -1, JSON.stringify(revoked));
    } finally {
      URL.createObjectURL = savedCreate;
      URL.revokeObjectURL = savedRevoke;
      global.document = savedDoc;
      global.setTimeout = savedST;
    }
  });
}

/* ================= T4 — حذف ================= */
function t4(toasts) {
  const A = loadAdapter({ enabled: true, baseUrl: '/api' });
  const urls = [];
  let mode = 500;
  global.fetch = async (url, init) => {
    urls.push({ url, init });
    if (mode === 500) return jsonRes({ title: 'خطای آزمایشی سرور' }, 500);
    return jsonRes({}, 200);
  };
  const a = { id: 'att-1', serverId: 'SRV-5', name: 'a.pdf' };
  A.pending.set('att-1', { name: 'a.pdf' }); /* فایل محلی در انتظار */

  return A.remove(a, {}).then((r1) => {
    check('remove روی 500 → false', r1 === false);
    check('نشانی DELETE درست است', urls[0] && urls[0].url === '/api/v1/attachments/SRV-5' && urls[0].init.method === 'DELETE',
      JSON.stringify(urls[0] || {}));
    check('toast خطای فارسی (شامل پیام ProblemDetails) یک‌بار نمایش داده شد',
      toasts.length === 1 && toasts[0].msg.indexOf('حذف پیوست در سرور ناموفق بود') !== -1 && toasts[0].msg.indexOf('خطای آزمایشی سرور') !== -1,
      JSON.stringify(toasts));
    check('pending پس از شکست حفظ شد', A.pending.has('att-1'));
    mode = 200;
    return A.remove(a, {}).then((r2) => {
      check('remove روی 200 → true', r2 === true);
      check('در موفقیت toast اضافه نشد', toasts.length === 1, JSON.stringify(toasts));
      check('pending پس از موفقیت پاک شد', !A.pending.has('att-1') && A.pending.size === 0);
    });
  });
}

/* ================= T5 — پاک‌سازی برای ذخیره‌سازی ================= */
function t5() {
  const A = loadAdapter({ enabled: true, baseUrl: '/api' });
  global.db = {
    meta: { v: 1 },
    programs: [{
      code: 'P-1', title: 'برنامه آزمایشی',
      atts: [
        { id: 'a1', name: 'remote.pdf', data: 'data:application/pdf,AAAA', remote: true, serverId: 'S1' },
        { id: 'a2', name: 'local.txt', data: 'data:text/plain,hello' },
        { id: 'a3', name: 'pending.docx', data: 'data:x,PPP', pendingRemote: true }
      ],
      micros: [{
        id: 'R-0001', title: 'ریزتقاضا',
        atts: [{ id: 'a4', name: 'm.png', data: 'data:image/png,BBBB', pendingRemote: true }]
      }]
    }]
  };
  const snap = A.stripRemoteData(global.db);
  check('snapshot از db جدا است', snap !== global.db);
  check('db اصلی دست‌نخورده (remote.data حفظ شده)', global.db.programs[0].atts[0].data === 'data:application/pdf,AAAA');
  check('remote → data=null در snapshot', snap.programs[0].atts[0].data === null);
  check('pendingRemote → data=null در snapshot', snap.programs[0].atts[2].data === null && snap.programs[0].micros[0].atts[0].data === null);
  check('پیوست محلی دست‌نخورده (data حفظ)', snap.programs[0].atts[1].data === 'data:text/plain,hello');
  check('پیوست محلی همان مرجع است (کپی کم‌عمق)', snap.programs[0].atts[1] === global.db.programs[0].atts[1]);
  check('فیلدهای دیگر db حفظ شده', snap.programs[0].code === 'P-1' && snap.programs[0].micros[0].title === 'ریزتقاضا' && snap.meta === global.db.meta);
  check('db اصلی: pendingRemote.data حفظ شده', global.db.programs[0].atts[2].data === 'data:x,PPP');
  return Promise.resolve();
}

/* ---------- اجرا ---------- */
global.window = global; /* سراسری ساختگی window */
Promise.resolve()
  .then(() => record('T1', 'حالت غیرفعال — عملیات‌ها بی‌اثر و مقادیر امن (بدون هیچ فراخوانی شبکه)', t1))
  .then(() => { delete global.db; return record('T2', 'شناسه‌یابی مالک — نشانی صحیح + کدگذاری URI کد فارسی + نگاشت m.id↔SeqNo + کش', t2); })
  .then(() => { delete global.db; return record('T3', 'جریان دانلود — blob → createObjectURL → click → revoke', t3); })
  .then(() => { delete global.db; return record('T4', 'حذف — false روی 500 و true روی 200 + مدیریت pending', t4); })
  .then(() => { delete global.db; return record('T5', 'stripRemoteData — صفرکردن data فقط برای remote/pendingRemote + حفظ db اصلی', t5); })
  .then(() => {
    const passed = results.filter(r => r.ok).length;
    console.log('-----------------------------------------------------------');
    console.log('نتیجه نهایی آزمون‌های آداپتور: %s (%d/%d PASS)',
      failures === 0 ? 'PASS' : 'FAIL', passed, results.length);
    process.exitCode = failures === 0 ? 0 : 1;
  })
  .catch((e) => {
    console.error('خطای غیرمنتظره هارنس:', e);
    process.exitCode = 1;
  });
