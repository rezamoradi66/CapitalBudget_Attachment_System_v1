#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================
verify_patch.py — راستی‌آزمایی وصله A5 (پیوست‌ها → REST API)
================================================================
بازرسی‌ها:
  (الف) هر ۸ لنگر وصله در فایل «ورودی» دقیقاً یک‌بار موجود است.
  (ب) نشانگرهای درج‌شده در فایل «وصله‌خورده» با تعداد مورد انتظار حاضرند.
  (ج) تمام بلوک‌های <script> درونی فایل وصله‌خورده با `node --check`
      از نظر نحو جاوااسکریپت معتبرند (استخراج در پوشه موقت).
  (د) آمار تفاوت بایت/خط بین ورودی و خروجی + بازه‌های خط تغییریافته
      + بررسی یکپارچگی: بازتولید وصله در حافظه باید بایت‌به‌بایت با
      خروجی روی دیسک یکی باشد (تضمین deterministic بودن).

خروجی: خلاصه فارسی PASS/FAIL — کد بازگشت ۰ یعنی همه آزمون‌ها PASS.
استاندارد کتابخانه پایتون؛ بدون وابستگی خارجی.
================================================================
"""

import difflib
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import patch_html  # noqa: E402  (لنگرها و موتور وصله از همین بسته خوانده می‌شود)

DEFAULT_SRC = patch_html.DEFAULT_SRC
DEFAULT_OUT = os.path.join(os.path.dirname(DEFAULT_SRC), patch_html.OUT_NAME)

# ------------------- نشانگرهای مورد انتظار -------------------
# ('نشانگر', حالت, مقدار) — حالت 'eq': تعداد دقیق؛ 'min': حداقل
MARKERS = [
    ('/* A5-PATCH(P1)',                      'eq', 1),
    ('/* A5-PATCH(P2)',                      'eq', 2),   # دو نقطه: انشعاب افزودن + تریگر بارگذاری فوری
    ('/* A5-PATCH(P3)',                      'eq', 1),
    ('/* A5-PATCH(P4)',                      'eq', 1),
    ('/* A5-PATCH(P5)',                      'eq', 1),
    ('/* A5-PATCH(P6)',                      'eq', 1),
    ('/* A5-PATCH(P7)',                      'eq', 1),
    ('/* A5-PATCH(P8)',                      'eq', 1),
    ('window.CBM_API_CONFIG = { enabled: false, baseUrl: \'/api\' };', 'eq', 1),
    ('window.CBM_ATT = (function () {',      'min', 1),
    ('window.CBM_ATT && CBM_ATT.enabled',    'eq', 8),   # P2:۲، P3:۱، P4:۱، P5:۱، P6:۱، P7:۱، P8:۱
    ('CBM_ATT.trackPending(__attItem, f);',  'eq', 1),
    ('CBM_ATT.tryUploadNow(o);',             'eq', 1),
    ('CBM_ATT.download(a, lnk);',            'eq', 1),
    ('Promise.resolve(CBM_ATT.remove(a, o))', 'eq', 1),
    ('CBM_ATT.stripRemoteData(db)',          'eq', 1),
    ('CBM_ATT.flushPending();',              'eq', 1),
    ('CBM_ATT.login(username, pass);',       'eq', 1),
    ('CBM_ATT.logout();',                    'eq', 1),
    ('pendingRemote: true',                  'min', 1),
    ("data: null, byId: me.id || ''",        'min', 1),
    ('const __snap =',                       'eq', 1),
    ('const __attDelLocal = () => {',        'eq', 1),
    ("toast('پیوست حذف شد', 'success');",    'eq', 1),   # پیام اصلی حفظ شده
    ("toast('داده‌ها با موفقیت ذخیره شد', 'success');", 'eq', 1),  # پیام اصلی حفظ شده
]

SCRIPT_RE = re.compile(r'<script\b([^>]*)>(.*?)</script>', re.S | re.I)


def line_of_index(text, idx):
    return text.count('\n', 0, idx) + 1


def diff_stats(a_text, b_text):
    """تفاوت خطی + بایتی؛ خروجی: (hunks, added_bytes, removed_bytes)"""
    a_lines = a_text.split('\n')
    b_lines = b_text.split('\n')
    sm = difflib.SequenceMatcher(None, a_lines, b_lines, autojunk=False)
    hunks = []
    added_bytes = removed_bytes = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            continue
        old_rng = (i1 + 1, i2) if i2 > i1 else None
        new_rng = (j1 + 1, j2) if j2 > j1 else None
        first = ''
        if j2 > j1:
            first = b_lines[j1][:110]
        elif i2 > i1:
            first = a_lines[i1][:110]
        hunks.append({'tag': tag, 'old': old_rng, 'new': new_rng, 'first': first})
        if tag in ('replace', 'insert'):
            for ln in b_lines[j1:j2]:
                added_bytes += len(ln.encode('utf-8')) + 1  # +1 برای \n
        if tag in ('replace', 'delete'):
            for ln in a_lines[i1:i2]:
                removed_bytes += len(ln.encode('utf-8')) + 1
    return hunks, added_bytes, removed_bytes


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    src_path = os.path.abspath(argv[0]) if len(argv) > 0 else DEFAULT_SRC
    out_path = os.path.abspath(argv[1]) if len(argv) > 1 else DEFAULT_OUT

    results = []  # (بخش، نام، PASS، جزئیات)

    # ---------- (الف) لنگرها در ورودی ----------
    try:
        with open(src_path, 'r', encoding='utf-8', newline='') as f:
            src = f.read()
    except OSError as e:
        print('✖ ورودی خوانده نشد: %s (%s)' % (src_path, e))
        return 2
    try:
        with open(out_path, 'r', encoding='utf-8', newline='') as f:
            out = f.read()
    except OSError as e:
        print('✖ خروجی وصله‌خورده خوانده نشد: %s (%s)' % (out_path, e))
        return 2

    sec_a = []
    for p in patch_html.PATCHES:
        n = src.count(p['anchor'])
        ok = (n == 1)
        sec_a.append(ok)
        results.append(('الف-لنگرها', '%s یکتا در ورودی' % p['pid'], ok,
                        'تعداد=%d — خط %d' % (n, line_of_index(src, src.index(p['anchor'])) if n else -1)))

    # ---------- (ب) نشانگرها در خروجی ----------
    for marker, mode, want in MARKERS:
        n = out.count(marker)
        ok = (n == want) if mode == 'eq' else (n >= want)
        results.append(('ب-نشانگرها', ('%s == %d' if mode == 'eq' else '%s ≥ %d') % (marker[:52], want),
                        ok, 'تعداد=%d' % n))

    # ---------- (ج) node --check روی همه بلوک‌های اسکریپت درونی ----------
    blocks = [(m.group(1), m.group(2)) for m in SCRIPT_RE.finditer(out)]
    inline = [(attrs, code) for attrs, code in blocks if 'src=' not in (attrs or '')]
    tmpdir = tempfile.mkdtemp(prefix='a5_jscheck_')
    node_ok = True
    node_details = []
    for i, (attrs, code) in enumerate(inline, 1):
        jp = os.path.join(tmpdir, 'inline_script_%d.js' % i)
        with open(jp, 'w', encoding='utf-8', newline='\n') as f:
            f.write(code)
        try:
            r = subprocess.run(['node', '--check', jp], capture_output=True, text=True, timeout=60)
            ok = (r.returncode == 0)
            node_details.append('بلوک %d (%d نویسه): %s' % (i, len(code), 'OK' if ok else 'FAIL — ' + (r.stderr or '').strip()[:200]))
        except FileNotFoundError:
            ok = False
            node_details.append('بلوک %d: node یافت نشد' % i)
        node_ok = node_ok and ok
        results.append(('ج-node --check', 'بلوک درونی شماره %d' % i, ok,
                        node_details[-1]))
    if not inline:
        node_ok = False
        results.append(('ج-node --check', 'بلوک اسکریپت درونی', False, 'هیچ بلوکی یافت نشد'))

    # ---------- (د) آمار تفاوت و یکپارچگی ----------
    hunks, added_b, removed_b = diff_stats(src, out)
    try:
        regenerated, _ = patch_html.apply_patches(src, verbose=False)
        deterministic = (regenerated == out)
    except AssertionError as e:
        deterministic = False
        hunks_det_msg = str(e)
    else:
        hunks_det_msg = ''
    results.append(('د-یکپارچگی', 'بازتولید بایت‌به‌بایت وصله', deterministic,
                    'خروجی دیسک با اعمال مجدد ۸ وصله یکی است' if deterministic else hunks_det_msg))
    utf8_ok = True
    try:
        out.encode('utf-8').decode('utf-8')
    except UnicodeError:
        utf8_ok = False
    results.append(('د-یکپارچگی', 'UTF-8 سالم (رمزگذاری/رمزگشایی)', utf8_ok, '—'))
    persian_ok = ('پیوست حذف شد' in out) and ('نوبت ۲۶ — پیوست فایل' in out) and ('اتصال به سرور پیوست‌ها برقرار نشد' in out)
    results.append(('د-یکپارچگی', 'متن‌های فارسی حساس حفظ شده', persian_ok,
                    'پیام toast حذف + عنوان نوبت ۲۶ + پیام خطای اتصال'))
    script_tag_ok = (out.count('</script>') == src.count('</script>') == 1) and (out.count('<script>') == src.count('<script>') == 1)
    results.append(('د-یکپارچگی', 'تعداد تگ‌های <script> بدون تغییر', script_tag_ok,
                    'قبل=%d بعد=%d' % (src.count('<script>'), out.count('<script>'))))

    # ---------- خلاصه ----------
    total = len(results)
    passed = sum(1 for r in results if r[2])
    print('')
    print('================= راستی‌آزمایی A5 — خلاصه =================')
    cur_sec = None
    for sec, name, ok, det in results:
        if sec != cur_sec:
            print('-- %s --' % sec)
            cur_sec = sec
        print('%s %s | %s' % ('✔ PASS' if ok else '✖ FAIL', name, det))
    print('-----------------------------------------------------------')
    print('آمار تفاوت (د): %d ناحیه تغییر | بایت افزوده ≈ %s | بایت حذف‌شده ≈ %s | نویسه‌های خروجی %s → %s'
          % (len(hunks), format(added_b, ','), format(removed_b, ','), format(len(src), ','), format(len(out), ',')))
    for h in hunks:
        old = ('ورودی %d–%d' % h['old']) if h['old'] else '—'
        new = ('خروجی %d–%d' % h['new']) if h['new'] else '—'
        print('  ناحیه [%s | %s → %s] خط نخست: %s' % (h['tag'], old, new, (h['first'] or '').strip()[:90]))
    print('-----------------------------------------------------------')
    print('نتیجه نهایی: %s (%d/%d آزمون PASS)' % ('✔✔✔ PASS' if passed == total else '✖✖✖ FAIL', passed, total))
    print('فایل ورودی    : %s' % src_path)
    print('فایل وصله‌خورده: %s' % out_path)
    return 0 if passed == total else 1


if __name__ == '__main__':
    sys.exit(main())
