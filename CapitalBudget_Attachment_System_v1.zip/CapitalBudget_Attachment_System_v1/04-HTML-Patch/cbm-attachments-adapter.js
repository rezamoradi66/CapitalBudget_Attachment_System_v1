/* ================================================================
   CBM Attachments Adapter — نسخه ۱٫۰ (تسک A5)
   ----------------------------------------------------------------
   نقش: پل اختیاری بین قابلیت «پیوست فایل» اپ تک‌فایلی و REST API
   (AttachmnetsModule.Api — مسیرهای /api/v1/ و پاسخ ProblemDetails).

   قرارداد فعال‌سازی:
     window.CBM_API_CONFIG = { enabled: true, baseUrl: '/api' };
   پیش‌فرض: enabled:false ⇒ آداپتور کاملاً خنثی است و رفتار فعلی اپ
   (localStorage) صددرصد بدون تغییر می‌ماند.

   نگاشت مالکیت (مستند ۰۱-Planning/Attachment-Architecture.md §۶):
     OwnerType 1 = برنامه/درخواست  →  POST /api/v1/requests/{id}/attachments
     OwnerType 2 = ریزتقاضا        →  POST /api/v1/micros/{id}/attachments
     شناسه‌یابی مالک: برنامه با «کد برنامه» (p.code) از طریق
       GET /api/v1/requests/by-code/{code}
     و ریزتقاضا با نگاشت مستند «m.id ↔ SeqNo» در فهرست micros همان
     پاسخ (seqNo === m.id)؛ سپس POST با شناسه سرور micro.

   اصل ایمنی: هر متد در try/catch است؛ در دسترس‌نبودن سرور هرگز اپ را
   نمی‌شکند. فقط از toast سراسری اپ استفاده می‌شود (در نبود آن ساکت است).
   ================================================================ */
window.CBM_ATT = (function () {
  'use strict';

  /* ---------- پیکربندی ---------- */
  function cfg() {
    try { return (typeof window !== 'undefined' && window.CBM_API_CONFIG) || null; } catch (e) { return null; }
  }
  function isEnabled() {
    try { var c = cfg(); return !!(c && c.enabled); } catch (e) { return false; }
  }
  function apiBase() {
    var c = cfg();
    var b = String((c && c.baseUrl) || '/api');
    return b.replace(/\/+$/, '');
  }
  /* مسیرهای کامل: baseUrl + /v1/...  (مثال: /api → /api/v1/...) */
  function API() { return apiBase() + '/v1'; }

  /* ---------- وضعیت ---------- */
  var pending = new Map();        /* attId → File (فایل محلی در انتظار بارگذاری) */
  var ownerCache = new Map();     /* code → { requestId, micros:[{id, seqNo}], ts } */
  var tries = new Map();          /* attId → تعداد تلاش ناموفق بارگذاری */
  var errToasted = new Set();     /* attId هایی که برایشان یک‌بار خطا toast شده */
  var uploading = new WeakSet();  /* مالک‌های در حال پردازش (جلوگیری از double-flush) */
  var flushing = false;
  var authed = false;             /* صرفاً اطلاعاتی — احراز هویت مبتنی بر Cookie سمت سرور است */

  /* ---------- ابزارها ---------- */
  function rid() {
    return 'req-' + Math.random().toString(36).slice(2, 10) + '-' + Date.now().toString(36);
  }
  function toastSafe(msg, type) {
    try { if (typeof toast === 'function') toast(String(msg), type || 'error'); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db && db.programs) return db; } catch (e) {}
    try { if (typeof window !== 'undefined' && window.db && window.db.programs) return window.db; } catch (e2) {}
    try { if (typeof globalThis !== 'undefined' && globalThis.db && globalThis.db.programs) return globalThis.db; } catch (e3) {}
    return null;
  }
  /* تشخیص نوع مالک: برنامه/درخواست (دارای micros یا history) یا ریزتقاضا */
  function kindOf(o) {
    try {
      if (o && (Array.isArray(o.micros) || Array.isArray(o.history) || ('budKind' in o))) return 'request';
    } catch (e) {}
    return 'micro';
  }
  function attsOf(o) { return (o && Array.isArray(o.atts)) ? o.atts : []; }
  function hasPendingAtt(it) { return !!(it && it.pendingRemote && !it.remote); }

  var HTTP_FA = {
    400: 'درخواست ارسالی نامعتبر است',
    401: 'نشست شما منقضی شده است؛ دوباره وارد شوید',
    403: 'اجازه انجام این عملیات را ندارید',
    404: 'مورد درخواستی در سرور یافت نشد',
    409: 'تداخل در وضعیت رکورد؛ صفحه را نوسازی کنید',
    413: 'حجم فایل بیش از حد مجاز سرور است',
    415: 'نوع فایل مجاز نیست'
  };
  function fallbackMsg(status) {
    return HTTP_FA[status] || ('خطای سرور (کد ' + (status || '—') + ')');
  }
  function problemMsg(res, body) {
    try {
      if (body && typeof body === 'object') {
        if (body.title) return String(body.title);
        if (body.detail) return String(body.detail);
      }
    } catch (e) {}
    return fallbackMsg(res && res.status);
  }

  /* ---------- هسته HTTP ----------
     apiFetch: پوشش fetch با credentials، X-Request-Id برای بارگذاری‌ها،
     خواندن ProblemDetails و نمایش toast فارسی (مگر opts.silent). */
  async function apiFetch(path, opts) {
    opts = opts || {};
    var url = API() + path;
    var headers = Object.assign({}, opts.headers || {});
    if (opts.xRequestId) headers['X-Request-Id'] = opts.xRequestId;
    if (opts.json) headers['Content-Type'] = 'application/json';
    var init = {
      method: opts.method || 'GET',
      credentials: opts.credentials || 'same-origin',
      headers: headers
    };
    if (opts.body !== undefined) init.body = opts.body;
    var res, body = null;
    try { res = await fetch(url, init); }
    catch (netErr) {
      console.warn('[CBM_ATT] network error on', url, netErr);
      var m1 = 'اتصال به سرور پیوست‌ها برقرار نشد';
      if (!opts.silent) toastSafe(m1, 'error');
      return { ok: false, status: 0, error: 'network', message: m1 };
    }
    var ct = '';
    try { ct = (res.headers && res.headers.get) ? (res.headers.get('content-type') || '') : ''; } catch (eH) {}
    if (ct.indexOf('application/json') !== -1) { try { body = await res.json(); } catch (eJ) { body = null; } }
    if (!res.ok) {
      var msg = problemMsg(res, body);
      console.warn('[CBM_ATT] http', res.status, 'on', url, msg);
      if (!opts.silent) toastSafe(msg, 'error');
      return { ok: false, status: res.status, error: 'http', message: msg, problem: body };
    }
    return { ok: true, status: res.status, data: body };
  }

  /* ---------- احراز هویت (غیرمسدودکننده) ---------- */
  async function login(username, password) {
    if (!isEnabled()) return false;
    try {
      var r = await apiFetch('/auth/login', {
        method: 'POST', credentials: 'include', json: true, silent: true,
        body: JSON.stringify({ username: String(username == null ? '' : username), password: String(password == null ? '' : password) })
      });
      if (r.ok) { authed = true; console.info('[CBM_ATT] ورود به سرور پیوست‌ها برقرار شد'); return true; }
      console.warn('[CBM_ATT] login failed:', r.status, r.message);
      toastSafe('اتصال به سرور پیوست‌ها برقرار نشد', 'error');
      return false;
    } catch (e) {
      console.warn('[CBM_ATT] login error', e);
      try { toastSafe('اتصال به سرور پیوست‌ها برقرار نشد', 'error'); } catch (e2) {}
      return false;
    }
  }
  async function logout() {
    if (!isEnabled()) return;
    try { await apiFetch('/auth/logout', { method: 'POST', silent: true }); } catch (e) { console.warn('[CBM_ATT] logout error', e); }
    authed = false;
    ownerCache.clear();
  }

  /* ---------- شناسه‌یابی مالک سمت سرور ---------- */
  function parseMicros(data) {
    try {
      var arr = (data && (data.micros || data.microRequests || data.items)) || [];
      if (!Array.isArray(arr)) return [];
      return arr.map(function (x) {
        var id = x && (x.id != null ? x.id : x.microId);
        /* نگاشت مستند: SeqNo سمت سرور معادل m.id سمت HTML است */
        var seq = x && (x.seqNo != null ? x.seqNo : (x.SeqNo != null ? x.SeqNo : x.seq));
        return { id: (id == null ? null : String(id)), seqNo: (seq == null ? null : String(seq)) };
      }).filter(function (x) { return x.id != null; });
    } catch (e) { return []; }
  }
  function findParentRequest(m) {
    var d = getDB();
    if (!d || !Array.isArray(d.programs)) return null;
    for (var i = 0; i < d.programs.length; i++) {
      var p = d.programs[i];
      if (!p || typeof p !== 'object') continue;
      if (p === m) return p;
      var ms = Array.isArray(p.micros) ? p.micros : [];
      for (var j = 0; j < ms.length; j++) {
        if (ms[j] === m) return p;
        if (m && m.id && ms[j] && ms[j].id === m.id) return p;
      }
    }
    return null;
  }
  /* خروجی: {ok:true, requestId[, microId]} یا {ok:false, reason} */
  async function resolveOwner(kind, ownerObj) {
    try {
      if (!isEnabled()) return { ok: false, reason: 'disabled' };
      if (kind === 'request') {
        var code = ownerObj && ownerObj.code;
        if (!code) return { ok: false, reason: 'no-code' }; /* پیش‌نویسِ بی‌کد — به flush واگذار می‌شود */
        var key = String(code);
        var cached = ownerCache.get(key);
        if (cached) return { ok: true, requestId: cached.requestId };
        var r = await apiFetch('/requests/by-code/' + encodeURIComponent(key), { silent: true });
        if (!r.ok) return { ok: false, reason: 'resolve-failed', status: r.status, message: r.message };
        var ridSrv = r.data && (r.data.id != null ? r.data.id : r.data.requestId);
        if (ridSrv == null) return { ok: false, reason: 'bad-payload' };
        var entry = { requestId: String(ridSrv), micros: parseMicros(r.data), ts: Date.now() };
        ownerCache.set(key, entry);
        return { ok: true, requestId: entry.requestId };
      }
      if (kind === 'micro') {
        var m = ownerObj;
        if (!m || !m.id) return { ok: false, reason: 'no-id' };
        var parent = findParentRequest(m);
        if (!parent) return { ok: false, reason: 'no-parent' };
        var c = ownerCache.get(String(parent.code));
        if (!c) {
          var r2 = await resolveOwner('request', parent);
          if (!r2.ok) return r2;
          c = ownerCache.get(String(parent.code));
        }
        var hit = (c.micros || []).filter(function (x) { return x.seqNo != null && String(x.seqNo) === String(m.id); })[0];
        if (!hit) return { ok: false, reason: 'micro-not-found' };
        return { ok: true, requestId: c.requestId, microId: String(hit.id) };
      }
      return { ok: false, reason: 'bad-kind' };
    } catch (e) {
      console.warn('[CBM_ATT] resolveOwner error', e);
      return { ok: false, reason: 'error' };
    }
  }

  /* ---------- بارگذاری ---------- */
  /* ثبت فایل محلی برای شناسه پیوست (فراخوانی از هوک P2 در attsAddFiles) */
  function trackPending(attItem, file) {
    try {
      if (!isEnabled()) return false;
      if (!attItem || !attItem.id || !file) return false;
      pending.set(String(attItem.id), file);
      return true;
    } catch (e) { console.warn('[CBM_ATT] trackPending error', e); return false; }
  }
  async function tryUploadNow(o) {
    if (!isEnabled()) return 0;
    if (!o || uploading.has(o)) return 0;
    uploading.add(o);
    try { return await uploadOwner(o); }
    catch (e) { console.warn('[CBM_ATT] tryUploadNow error', e); return 0; }
    finally { uploading.delete(o); }
  }
  async function uploadOwner(o) {
    var items = attsOf(o).filter(function (it) {
      return it && it.pendingRemote && !it.remote && it.id && pending.has(String(it.id)) && pending.get(String(it.id));
    });
    if (!items.length) return 0;
    var kind = kindOf(o);
    var own = await resolveOwner(kind, o);
    if (!own || !own.ok) return 0; /* مالک هنوز سمت سرور قابل‌تشخیص نیست → به flush واگذار می‌شود */
    var base = (kind === 'request')
      ? '/requests/' + encodeURIComponent(own.requestId) + '/attachments'
      : '/micros/' + encodeURIComponent(own.microId) + '/attachments';
    var doneCount = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var file = pending.get(String(it.id));
      try {
        var fd = new FormData();
        fd.append('file', file, it.name || (file && file.name) || ('file-' + it.id));
        if (it.name) fd.append('displayName', it.name);
        var r = await apiFetch(base, { method: 'POST', body: fd, xRequestId: rid(), silent: true });
        if (r.ok) {
          it.remote = true;
          it.pendingRemote = false;
          var srv = r.data && (r.data.id != null ? r.data.id : (r.data.attachmentId != null ? r.data.attachmentId : null));
          it.serverId = (srv == null ? it.id : String(srv));
          if (r.data && (r.data.displayName || r.data.fileName)) it.serverName = String(r.data.displayName || r.data.fileName);
          pending.delete(String(it.id));
          tries.delete(String(it.id));
          doneCount++;
        } else if (r.status === 401) {
          authed = false;
          toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error');
          return doneCount; /* توقف تلاش‌های بعدی تا ورود مجدد */
        } else {
          tries.set(String(it.id), (tries.get(String(it.id)) || 0) + 1);
          if (!errToasted.has(String(it.id))) {
            errToasted.add(String(it.id));
            toastSafe('بارگذاری پیوست «' + (it.name || '') + '» در سرور ناموفق بود' + (r.message ? ' — ' + r.message : ''), 'error');
          }
        }
      } catch (eUp) {
        console.warn('[CBM_ATT] upload error', it.id, eUp);
        tries.set(String(it.id), (tries.get(String(it.id)) || 0) + 1);
      }
    }
    return doneCount;
  }
  /* پیمایش کل db: پیوست‌های برنامه (OwnerType 1) و ریزتقاضاها (OwnerType 2) */
  async function flushPending() {
    if (!isEnabled() || flushing) return;
    flushing = true;
    try {
      var d = getDB();
      if (!d || !Array.isArray(d.programs)) return;
      for (var i = 0; i < d.programs.length; i++) {
        var p = d.programs[i];
        if (!p || typeof p !== 'object') continue;
        if (attsOf(p).some(hasPendingAtt)) { try { await uploadOwner(p); } catch (e1) { console.warn('[CBM_ATT] flush prog error', e1); } }
        var ms = Array.isArray(p.micros) ? p.micros : [];
        for (var j = 0; j < ms.length; j++) {
          var m = ms[j];
          if (m && typeof m === 'object' && attsOf(m).some(hasPendingAtt)) { try { await uploadOwner(m); } catch (e2) { console.warn('[CBM_ATT] flush micro error', e2); } }
        }
      }
    } catch (e) {
      console.warn('[CBM_ATT] flush error', e);
    } finally {
      flushing = false;
    }
  }

  /* ---------- دانلود ---------- */
  async function download(a, lnk) {
    try {
      if (!isEnabled()) return false;
      var id = a && (a.serverId || a.id);
      if (!id) { toastSafe('شناسه پیوست برای دانلود یافت نشد', 'error'); return false; }
      var res = await fetch(API() + '/attachments/' + encodeURIComponent(String(id)), { credentials: 'same-origin' });
      if (res.status === 401) { authed = false; toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error'); return false; }
      if (!res.ok) { toastSafe(problemMsg(res, null), 'error'); return false; }
      var blob = await res.blob();
      var url = URL.createObjectURL(blob);
      lnk.href = url;
      lnk.download = a.name || ('file-' + a.id);
      (document.body || document.documentElement).appendChild(lnk);
      lnk.click();
      lnk.remove();
      setTimeout(function () { try { URL.revokeObjectURL(url); } catch (eR) {} }, 4000);
      return true;
    } catch (e) {
      console.warn('[CBM_ATT] download error', e);
      try { toastSafe('دریافت پیوست از سرور ناموفق بود', 'error'); } catch (e2) {}
      return false;
    }
  }

  /* ---------- حذف ---------- */
  /* true = حذف سروری موفق (ادامه حذف محلی مجاز)؛ false = ناموفق (حذف محلی باید رد شود) */
  async function remove(a, o) {
    try {
      if (!isEnabled()) return true;
      var id = a && (a.serverId || a.id);
      if (!id) { toastSafe('شناسه پیوست برای حذف یافت نشد', 'error'); return false; }
      var r = await apiFetch('/attachments/' + encodeURIComponent(String(id)), { method: 'DELETE', silent: true });
      if (r.ok) { pending.delete(String(a.id)); return true; }
      if (r.status === 401) { authed = false; toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error'); }
      else { toastSafe('حذف پیوست در سرور ناموفق بود' + (r.message ? ' — ' + r.message : ''), 'error'); }
      return false;
    } catch (e) {
      console.warn('[CBM_ATT] remove error', e);
      try { toastSafe('حذف پیوست در سرور ناموفق بود', 'error'); } catch (e2) {}
      return false;
    }
  }

  /* ---------- پاک‌سازی برای ذخیره‌سازی محلی ----------
     ورودی db دست‌نخورده می‌ماند؛ خروجی کپی کم‌عمق است که فقط در
     آیتم‌های پیوست remote/pendingRemote مقدار data را null می‌کند. */
  function stripAtt(a) {
    if (a && (a.remote || a.pendingRemote)) {
      var c = Object.assign({}, a);
      c.data = null;
      return c;
    }
    return a;
  }
  function stripRemoteData(d) {
    if (!isEnabled()) return d; /* غیرفعال: بدون هیچ تغییری */
    try {
      if (!d || !Array.isArray(d.programs)) return d;
      var out = Object.assign({}, d);
      out.programs = d.programs.map(function (p) {
        if (!p || typeof p !== 'object') return p;
        var q = Object.assign({}, p);
        if (Array.isArray(p.atts)) q.atts = p.atts.map(stripAtt);
        if (Array.isArray(p.micros)) {
          q.micros = p.micros.map(function (m) {
            if (!m || typeof m !== 'object') return m;
            var mm = Object.assign({}, m);
            if (Array.isArray(m.atts)) mm.atts = m.atts.map(stripAtt);
            return mm;
          });
        }
        return q;
      });
      return out;
    } catch (e) {
      console.warn('[CBM_ATT] stripRemoteData error', e);
      return d;
    }
  }

  function isRemote(a) { try { return !!(a && (a.remote || a.pendingRemote)); } catch (e) { return false; } }

  /* ---------- API عمومی ---------- */
  var APIObj = {
    version: '1.0',
    login: login,
    logout: logout,
    apiFetch: apiFetch,
    resolveOwner: resolveOwner,
    trackPending: trackPending,
    tryUploadNow: tryUploadNow,
    flushPending: flushPending,
    download: download,
    remove: remove,
    stripRemoteData: stripRemoteData,
    sanitizeForSave: stripRemoteData, /* نام مستعار */
    isRemote: isRemote,
    pending: pending,
    ownerCache: ownerCache
  };
  try { Object.defineProperty(APIObj, 'enabled', { get: isEnabled, enumerable: true, configurable: true }); } catch (e) { APIObj.enabled = isEnabled(); }

  return APIObj;
})();
