#!/usr/bin/env node
/* ================================================================
   run_regression_suite.js — آزمون رگرسیون (تسک A5، مکمل)
   ----------------------------------------------------------------
   سوئیت پایدارسازی رسمی v3_1_1 (۳۶ آزمون) را «بدون هیچ تغییری در
   فایل‌های اصلی» روی کد استخراج‌شده از HTML وصله‌خورده اجرا می‌کند:
     ۱) استخراج JS درونی از HTML وصله‌خورده → فایل موقت /tmp
     ۲) جایگزینی فقط «ارجاع فایل» در کپی موقت سوئیت (APP/HTML/vmload)
     ۳) اجرای سوئیت با node — نتیجه باید 36/36 PASS باشد.

   هیچ فایلی از پروژه اصلی نوشته یا اصلاح نمی‌شود.
   ================================================================ */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const EX = '/home/z/my-project/audit_src/extracted';
const PATCHED_HTML = path.join(EX, 'Capital_Budget_Management_Stabilized_v3_1_1.attachments.html');
const SUITE = path.join(EX, 'stabilization_unit_tests_v3_1_1.js');

if (!fs.existsSync(PATCHED_HTML)) { console.error('patched HTML not found: ' + PATCHED_HTML); process.exit(2); }
if (!fs.existsSync(SUITE)) { console.error('suite not found: ' + SUITE); process.exit(2); }

/* ۱) استخراج JS درونی (همان قرارداد extract_app_js_v3_1_1.js) */
const html = fs.readFileSync(PATCHED_HTML, 'utf8');
const s = html.indexOf('<script>');
const e = html.lastIndexOf('</script>');
if (s === -1 || e === -1) { console.error('script tag not found'); process.exit(1); }
const patchedJs = path.join(os.tmpdir(), 'a5_app_v3_1_1_patched.js');
fs.writeFileSync(patchedJs, html.slice(s + 8, e));

/* ۲) کپی موقت سوئیت با ارجاع‌های جایگزین‌شده */
let src = fs.readFileSync(SUITE, 'utf8');
const vmloadAbs = JSON.stringify(path.join(EX, 'vmload_v3_1_1.js'));
const appAbs = JSON.stringify(patchedJs);
const htmlAbs = JSON.stringify(PATCHED_HTML);
const r1 = src.replace("require('./vmload_v3_1_1.js')", 'require(' + vmloadAbs + ')');
const r2 = r1.replace("path.join(__dirname, 'app_v3_1_1.js')", appAbs);
const r3 = r2.replace("path.join(__dirname, 'Capital_Budget_Management_Stabilized_v3_1_1.html')", htmlAbs);
if (r3 === src) { console.error('no references replaced — suite format changed?'); process.exit(2); }
const tmpSuite = path.join(os.tmpdir(), 'a5_stabilization_suite_runner.js');
fs.writeFileSync(tmpSuite, r3);

/* ۳) اجرا */
console.log('── سوئیت پایدارسازی v3_1_1 روی کد استخراج‌شده از HTML وصله‌خورده ──');
try {
  execFileSync(process.execPath, [tmpSuite], { stdio: 'inherit' });
  process.exitCode = 0;
} catch (err) {
  process.exitCode = err.status || 1;
} finally {
  try { fs.unlinkSync(tmpSuite); } catch (e) {}
  try { fs.unlinkSync(patchedJs); } catch (e) {}
}
