# دستورالعمل پیکربندی FILESTREAM — SQL Server 2022 (اجرای اختصاصی IT)

> ⚠️ این دستورالعمل فقط در پنجره نگهداری و با پشتیبان کامل قبلی اجرا شود. هیچ گامی در این بسته به‌صورت خودکار روی سرور اجرا نشده است.

## گام ۱ — بررسی وضعیت فعلی (بدون تغییر)

```powershell
# SSMS یا sqlcmd — اسکریپت‌های 00 و 01 پوشه 02-Database/sql
sqlcmd -S . -i 00-Check-Database-State.sql
sqlcmd -S . -i 01-Check-Filestream-Prerequisites.sql
```
خروجی باید فهرست PASS/FAIL/WARN بدهد. اگر `FilestreamEffectiveLevel = 0` باشد، گام ۲ لازم است.

## گام ۲ — فعال‌سازی در سطح Windows و Instance

1. **SQL Server Configuration Manager** ← SQL Server Services ← روی سرویس SQL Server (MSSQLSERVER) راست‌کلیک ← Properties ← تب **FILESTREAM**:
   - ✔ Enable FILESTREAM for Transact-SQL access
   - ✔ Enable FILESTREAM for file I/O streaming access (نام Share: پیش‌فرض `MSSQLSERVER`)
   - ✖ «Allow remote clients access» را **فعال نکنید** (اصل حداقل دسترسی — دسترسی فقط از خود سرور/API)
2. سرویس SQL Server را **Restart** کنید (در پنجره نگهداری).
3. سطح دسترسی T-SQL را فعال کنید:
```sql
EXEC sp_configure 'filestream access level', 2; RECONFIGURE;
-- بررسی: SELECT CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT);  → باید 2 باشد
```

## گام ۳ — دیسک و مسیر

- پوشه پایه مثال: `D:\CBM\FS` (دیسک جدا از OS و فایل‌های داده — تصمیم نهایی مسیر با IT؛ اسکریپت ساخت با پارامتر `$(FSPath)` پارامتری است).
- **نکته مهم:** خودِ پوشه را از قبل نسازید — SQL Server آن را می‌سازد؛ پوشه والد باید وجود داشته باشد.
- برآورد فضا: سقف فعلی ۱MB×۱۰ فایل برای هر برنامه/ردیف (D-10)؛ برآورد واقعی پس از اعلام حجم/تعداد سالانه کارفرما (سؤال‌های باز D-21 سند ۰۸).

## گام ۴ — اجرای ساخت

```powershell
sqlcmd -S . -d CapitalBudgetManagement_Lab -v FSPath="D:\CBM\FS" -i 02-Create-Attachment-Structure.sql
sqlcmd -S . -d CapitalBudgetManagement_Lab -i 03-Verify-Attachment-Structure.sql   # باید همه PASS باشد
```

## گام ۵ — اعتبارسنجی دسترسی از API

- App Pool API فقط باید به FILESTREAM container دسترسی NTFS Read/Write داشته باشد (نه هیچ مسیر دیگر).
- آزمون: یک فایل آزمایشی بارگذاری و دانلود کنید (TC-ATT-032 از Runbook آزمون Lab).
- در صورت خطای دسترسی SqlFileStream: حالت `FilestreamViaSql` جایگزین پیکربندی است (همان ستون FILESTREAM، انتقال بایت از مسیر T-SQL — برای فایل‌های ≤۱MB تفاوت عملی ندارد).

## گام ۶ — کنترل‌های امنیتی پس از فعال‌سازی

| کنترل | روش | انتظار |
|---|---|---|
| عدم افشای Share | از یک کلاینت دیگر: `\\server\MSSQLSERVER` | در دسترس نباشد (فقط Local) |
| عدم دسترسی مستقیم کاربران | هیچ Virtual Directory/Static File به مسیر FILESTREAM نباشد | — |
| پوشش پشتیبان | Full Backup شامل FILESTREAM — اسکریپت‌های Backup-Restore-Strategy | VERIFYONLY موفق |
