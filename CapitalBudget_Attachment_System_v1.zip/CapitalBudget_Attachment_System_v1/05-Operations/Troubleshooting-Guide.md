# راهنمای عیب‌یابی — ماژول پیوست‌ها

| # | علامت | علت محتمل | اقدام |
|---|---|---|---|
| ۱ | `/health` 503 یا عدم پاسخ | ANCM نصب نیست / Hosting Bundle قدیمی | نصب Hosting Bundle 10.0؛ Event Log → ASP.NET Core |
| ۲ | `500.19` هنگام شروع | web.config خراب / نقش Locked Sections | بازبینی web.config؛ نصب کامل IIS (Feature: Application Development) |
| ۳ | `STARTUP GUARD` در لاگ: «InMemory فقط برای توسعه» | `Attachments:BinaryStore=InMemory` در Production | مقدار `Filestream` یا `FilestreamViaSql` |
| ۴ | بارگذاری → 500 + لاگ «SqlFileStream … Access Denied» | NTFS روی FILESTREAM container برای App Pool تنظیم نیست | مجوز Read/Write به حساب App Pool؛ یا موقتاً `FilestreamViaSql` |
| ۵ | ساخت ساختار → FAIL «FilestreamEffectiveLevel = 0» | فعال‌سازی سطح Instance انجام نشده | گام‌های ۱–۳ راهنمای FILESTREAM-Configuration-Guide |
| ۶ | ورود → 401 `LOGIN-LOCKED` ناخواسته | ۵ تلاش ناموفق (D-02) | ۱۵ دقیقه صبر یا ردیف `LoginLockouts` توسط DBA حذف شود (با ثبت رویداد) |
| ۷ | ورود → 401 مداوم با رمز درست | حساب `IsActive=0` یا `MustChangePassword` | کنترل کاربر؛ مسیر تغییر رمز اجباری |
| ۸ | دانلود → 404 برای فایل موجود | خارج از محدوده دید کاربر (fail-closed) | بررسی نقش/مالکیت — این رفتار صحیح است |
| ۹ | بارگذاری → 415 `FILE-CONTENT-MISMATCH` | پسوند جعلی/فایل خراب | فایل واقعی را بررسی کنید — رفتار صحیح |
| ۱۰ | بارگذاری → 413/422 | سقف ۱MB / فایل خالی / سقف ۱۰ فایل (D-10) | طبق سیاست مصوب؛ تغییر سقف نیازمند تصمیم کارفرما (Open-Issues §۲) |
| ۱۱ | خطای `RATE-LIMITED` | بیش از ۱۰ ورود در دقیقه از یک IP | صبر؛ تنظیم `Attachments:LoginRateLimitPerMinute` در صورت نیاز |
| ۱۲ | بعد از Restore فایل‌ها خراب | بازیابی FILESTREAM به مسیر موجود/ناقص | طبق Backup-Restore-Strategy §۳؛ پوشه مقصد نباید از قبل موجود باشد؛ آزمون SHA-256 |
| ۱۳ | لاگ رشد بی‌رویه | سطح لاگ | MinimumLevel در Program.cs؛ نگهداری ۳۰ روز فایل |
| ۱۴ | رابط HTML پیوست را آپلود نمی‌کند | حالت اتصال خاموش / نشست API منقضی | `CBM_API_CONFIG.enabled` و ورود مجدد؛ پیام‌های فارسی آداپتور |

## لاگ‌ها و رویدادها

- لاگ فنی: `logs/app-YYYYMMDD.log` (Serilog) — بدون محتوای فایل و بدون مسیر فیزیکی.
- رویدادهای امنیتی: جدول `dbo.SecurityEvents` (EventType شامل `attachment_*`, `login_*`, `password_changed`) — گزارش ماهانه توصیه می‌شود.
- سلامت دیتابیس پیوست‌ها: `02-Database/sql/04-Health-Check.sql`.
