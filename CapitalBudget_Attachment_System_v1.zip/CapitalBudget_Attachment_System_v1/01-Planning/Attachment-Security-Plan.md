# Attachment-Security-Plan — برنامه امنیت سامانه پیوست‌ها

## ۱. تطبیق کنترل‌های الزامی مأموریت (بند ۷) با پیاده‌سازی

| # | کنترل الزامی | پیاده‌سازی واقعی | محل کد/پیکربندی |
|---|---|---|---|
| ۱ | احراز هویت سمت سرور | Cookie Authentication + نشست سمت سرور (انقضای ۳۰ دقیقه لغزشی — D-03؛ ابطال در خروج)؛ قفل ورود ۵ تلاش → ۱۵ دقیقه به‌ازای نام کاربری + Rate Limit مستقل IP (D-02)؛ سیاست رمز ≥۸ + فهرست رمز رایج + PBKDF2 با Salt (D-01) | `AuthController`، `SessionStore`، `LoginLockouts` (جدول مصوب)، `Pbkdf2PasswordHasher` |
| ۲ | مجوز هر پیوست | `PermissionService` — مشاهده/دانلود = محدوده دید معادل `visiblePrograms` (خط ۱۸۳۷)؛ افزودن/حذف = معادل `canEditProgram` (خط ۱۸۸۳) — همه بر داده سمت سرور | `Core/Application/PermissionService.cs` |
| ۳ | جلوگیری از دسترسی به پیوست مالکیت غیرمجاز | هر درخواست: حل مالک → محاسبه scope →fail-closed (403/404)؛ آزمون‌های اختصاصی TC-SEC-ATT-003 | `AttachmentsController` + آزمون‌ها |
| ۴ | اعتبارسنجی پسوند + محتوای واقعی | پسوند ∈ فهرست عین کد مرجع (ATT_ACCEPT — خط ۷۸۸) **و** امضای باینری (magic number): PDF/PNG/JPEG/GIF/WEBP/ZIP(و DOCX/XLSX/PPTX)/RAR/7Z/OLE2(و DOC/XLS/PPT قدیم)/متن؛ ناهم‌خوانی → 415 | `FileTypeDetector.cs` — جدول امضاها |
| ۵ | محدودیت حجم | ۱MB (۱٬۰۴۸٬۵۷۶ بایت — عین کد خط ۷۸۷، D-10) در اعتبارسنجی multipart + قید CHECK دیتابیس `CHECK (SizeBytes BETWEEN 1 AND 1048576)` | `AttachmentService` + اسکریپت SQL |
| ۶ | نام داخلی امن | نام واقعی ذخیره‌سازی = `FileGuid ROWGUIDCOL` تولیدی SQL Server؛ نام کاربر فقط متادیتا (`OriginalName`/`DisplayName`) پس از نرمال‌سازی (حذف مسیر، نویسه‌های کنترلی، طول ۲۶۰) | `FileNameSanitizer.cs` |
| ۷ | جلوگیری از Path Traversal | هیچ ورودی رشته‌ای مسیر نیست؛ دو سناریوی حملۀ آزمون‌شده (../ و نام‌های ویندوزی) در آزمون واحد | `FileNameSanitizerTests` |
| ۸ | جلوگیری از اجرای فایل | دانلود با `Content-Type` سفیدلیستی + `Content-Disposition: attachment` + `X-Content-Type-Options: nosniff`؛ HTML/SVG/اسکریپت در فهرست مجاز نیستند؛ میزبانی FILESTREAM خارج از هر مسیر وب | `DownloadResult` + هدرها |
| ۹ | جلوگیری از دسترسی مستقیم به مسیر FILESTREAM | اشتراک SMB مخصوص FILESTREAM فقط برای SQL Server؛ هیچ Virtual Directory در IIS به آن؛ دسترسی بایت‌ها فقط از داخل API با تراکنش؛ مسیر فیزیکی **هرگز** در پاسخ API نمی‌آید | معماری + `FILESTREAM-Configuration-Guide.md` |
| ۱۰ | مدیریت امن خطا | Middleware متمرکز → ProblemDetails RFC 7807 با پیام فارسی و `errorCode` پایدار؛ جزئیات فنی/استک هرگز به کلاینت؛ لاگ کامل سمت سرور | `ExceptionHandlingMiddleware` |
| ۱۱ | ثبت رویدادهای حساس | `attachment_upload/download/delete/denied/login_success/failed/lockout` در `SecurityEvents` (append-only) با IP/UserAgent — بدون محتوا | `SecurityEventService` |
| ۱۲ | بدون محتوای فایل/اطلاعات حساس در Log | قاعده کد: فقط شناسه/نام منطقی/اندازه/کد خطا؛ Serilog فیلتر؛ Test TC-SEC-ATT-012 | کد + آزمون |
| ۱۳ | کنترل هم‌زمانی و بارگذاری ناقص | تراکنش واحد متادیتا+بایت (rollback کامل)؛ `X-Request-Id` برای Idempotency (قرارداد مصوب سند ۰۵ §۱)؛ قطع اتصال حین آپلود = تراکنش ناتمام → هیچ رکورد ناسازگاری نمی‌ماند | `AttachmentService.UploadAsync` |
| ۱۴ | خطر فایل‌های مخرب/Office | **هیچ زیرساخت اسکنی اعلام/در دسترس نیست — هیچ ادعای اسکنی نمی‌شود**؛ کاهش سطح ریسک: فهرست پسوند سفید، امضای باینری، عدم اجرا، وضعیت `Status='quarantined'` به‌عنوان نقطه اتصال آینده اسکن | Open-Issues (اقدام IT) |
| ۱۵ | حداقل دسترسی حساب‌ها | App Pool اختصاصی (بدون پروفایل، بدون مدیر)؛ دسترسی NTFS فقط به FILESTREAM container؛ حساب SQL = Windows Auth با حداقل مجوز دیتابیس (بدون sysadmin) — دستورالعمل دقیق | `IIS-Deployment-Guide.md` §۵ |

## ۲. مستندات تهدید — خلاصه ریسک‌های اختصاصی پیوست

| تهدید | سناریو | کنترل | باقی‌مانده |
|---|---|---|---|
| دورزدن مجوز با حدس شناسه | دانلود `/attachments/123` برنامه دیگر | Scope سمت سرور روی هر درخواست + 404 به‌جای افشای وجود | — |
| آپلود Web-Shell/HTML | فایل .aspx/.html با پسوند جعلی | سفیدلیست پسوند + امضای باینری + عدم اجرا + nosniff | — |
| ZIP Bomb / XML | زیپ حجیم/Office مخرب | سقف ۱MB سخت (CHECK DB)؛ بازکردن فایل‌ها سمت سرور انجام نمی‌شود | اسکن AV موجود نیست (Open-Issues) |
| CSRF روی عملیات پیوست | فرم خارجی با Cookie کاربر | SameSite=Lax + POST/DELETE فقط JSON/multipart + (اختیاری: هدر سفارشی) | — |
| افشای مسیر سرور | پیام خطا/متادیتا | پیام‌های فارسی ثابت؛ متادیتای پاسخ فقط فیلدهای مصوب | — |
| نشست ربوده‌شده | کوکی سرقت‌شده | HttpOnly + Secure (HTTPS داخلی) + انقضای ۳۰ دقیقه + ابطال خروج | گواهی سازمانی — فرض ثبت‌شده v6 |
| Brute-force ورود | تلاش رمز | قفل ۱۵ دقیقه حساب + Rate Limit IP + کپچا طبق تنظیمات + رویدادها | — |

## ۳. حساب‌ها و مجوزها (اصل حداقل دسترسی)

| حساب | کاربرد | مجوز لازم | مجوز ممنوع |
|---|---|---|---|
| `IIS AppPool\CBMAttachments` | اجرای API | Read/Write روی FILESTREAM container فقط؛ Read وب‌کانفیگ | مدیر محلی؛ دسترسی به مسیرهای دیگر |
| Login SQL حساب سرویس (Windows Auth) | اتصال API→SQL | `SELECT/INSERT/UPDATE/DELETE` روی `dbo.RequestAttachments`، `SELECT` جداول مرجع/کاربران، `INSERT/SELECT` `SecurityEvents`، `SELECT/UPDATE` `LoginLockouts` | `sysadmin`، `db_owner`، DDL |
| DBA | اجرای اسکریپت‌ها | کنترل‌شده و ثبت‌شده | — |

## ۴. محرمانگی‌ها

- هیچ Connection String/رمزی در سورس یا فایل‌های تحویلی نیست — همه از Environment Variable (D-09).
- فایل نمونه `appsettings.Production.json` فقط کلیدهای بی‌خطر دارد.
- لاگ‌ها: بدون رمز/توکن/محتوای فایل — با آزمون TC-SEC-ATT-012 کنترل می‌شود.
